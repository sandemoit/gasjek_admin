-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: localhost    Database: gasjek
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_activation_attempts`
--

DROP TABLE IF EXISTS `auth_activation_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_activation_attempts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(255) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `token` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_activation_attempts`
--

LOCK TABLES `auth_activation_attempts` WRITE;
/*!40000 ALTER TABLE `auth_activation_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_activation_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_groups`
--

DROP TABLE IF EXISTS `auth_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_groups` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_groups`
--

LOCK TABLES `auth_groups` WRITE;
/*!40000 ALTER TABLE `auth_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_groups_permissions`
--

DROP TABLE IF EXISTS `auth_groups_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_groups_permissions` (
  `group_id` int unsigned NOT NULL DEFAULT '0',
  `permission_id` int unsigned NOT NULL DEFAULT '0',
  KEY `auth_groups_permissions_permission_id_foreign` (`permission_id`),
  KEY `group_id_permission_id` (`group_id`,`permission_id`),
  CONSTRAINT `auth_groups_permissions_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `auth_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `auth_groups_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `auth_permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_groups_permissions`
--

LOCK TABLES `auth_groups_permissions` WRITE;
/*!40000 ALTER TABLE `auth_groups_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_groups_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_groups_users`
--

DROP TABLE IF EXISTS `auth_groups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_groups_users` (
  `group_id` int unsigned NOT NULL DEFAULT '0',
  `user_id` int unsigned NOT NULL DEFAULT '0',
  KEY `auth_groups_users_user_id_foreign` (`user_id`),
  KEY `group_id_user_id` (`group_id`,`user_id`),
  CONSTRAINT `auth_groups_users_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `auth_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `auth_groups_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_groups_users`
--

LOCK TABLES `auth_groups_users` WRITE;
/*!40000 ALTER TABLE `auth_groups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_groups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_logins`
--

DROP TABLE IF EXISTS `auth_logins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_logins` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `user_id` int unsigned DEFAULT NULL,
  `date` datetime NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `email` (`email`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=356 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_logins`
--

LOCK TABLES `auth_logins` WRITE;
/*!40000 ALTER TABLE `auth_logins` DISABLE KEYS */;
INSERT INTO `auth_logins` VALUES (1,'127.0.0.1','putri@gmail.com',2,'2023-01-17 09:16:08',0),(2,'127.0.0.1','putri@gmail.com',2,'2023-01-17 09:16:14',0),(3,'127.0.0.1','putri@gmail.com',2,'2023-01-17 09:19:58',0),(4,'127.0.0.1','freeaja87@gmail.com',3,'2023-01-17 09:20:13',0),(5,'127.0.0.1','putri@gmail.com',2,'2023-01-17 09:22:08',0),(6,'127.0.0.1','putri@gmail.com',2,'2023-01-17 09:22:09',0),(7,'127.0.0.1','putri@gmail.com',2,'2023-01-17 09:22:09',0),(8,'127.0.0.1','putri@gmail.com',2,'2023-01-17 09:22:10',0),(9,'127.0.0.1','putri@gmail.com',2,'2023-01-17 09:22:10',0),(10,'127.0.0.1','putri@gmail.com',2,'2023-01-17 09:22:11',0),(11,'127.0.0.1','putri@gmail.com',2,'2023-01-17 09:22:14',0),(12,'127.0.0.1','freeaja87@gmail.com',3,'2023-01-17 09:22:25',0),(13,'127.0.0.1','freeaja8q7@gmail.com',4,'2023-01-17 09:22:48',1),(14,'127.0.0.1','freeaja87@gmail.com',3,'2023-01-17 09:39:44',0),(15,'127.0.0.1','freeaja8q7@gmail.com',4,'2023-01-17 09:41:20',1),(16,'127.0.0.1','freeaja8q7@gmail.com',4,'2023-01-17 10:36:26',1),(17,'127.0.0.1','putri@gmail.com',5,'2023-01-17 10:48:05',1),(18,'127.0.0.1','putri@gmail.com',5,'2023-01-17 10:54:52',1),(19,'127.0.0.1','putri@gmail.com',5,'2023-01-17 10:56:08',1),(20,'127.0.0.1','putri@gmail.com',5,'2023-01-17 10:56:16',1),(21,'127.0.0.1','putri@gmail.com',5,'2023-01-17 11:05:21',1),(22,'127.0.0.1','putri@gmail.com',5,'2023-01-17 11:06:53',1),(23,'127.0.0.1','putri@gmail.com',5,'2023-01-17 11:53:34',1),(24,'127.0.0.1','putri@gmail.com',5,'2023-01-17 11:53:39',1),(25,'127.0.0.1','putri@gmail.com',5,'2023-01-17 19:55:27',1),(26,'127.0.0.1','putri@gmail.com',5,'2023-01-17 21:00:47',1),(27,'127.0.0.1','putri@gmail.com',NULL,'2023-01-17 21:13:22',0),(28,'127.0.0.1','putri@gmail.com',5,'2023-01-17 21:13:32',1),(29,'127.0.0.1','putri@gmail.com',5,'2023-01-18 03:48:50',1),(30,'127.0.0.1','putri@gmail.com',5,'2023-01-18 04:59:47',1),(31,'127.0.0.1','putri@gmail.com',5,'2023-01-18 10:20:59',1),(32,'127.0.0.1','putri@gmail.com',5,'2023-01-18 10:24:05',1),(33,'127.0.0.1','admin@gmail.com',6,'2024-03-25 02:33:41',1),(34,'127.0.0.1','admin@gmail.com',6,'2024-03-25 09:12:30',1),(35,'192.168.100.8','admin@gmail.com',6,'2024-03-25 22:12:40',1),(36,'192.168.100.8','admin@gmail.com',6,'2024-03-26 07:22:25',1),(37,'192.168.100.8','admin@gmail.com',6,'2024-03-26 10:47:04',1),(38,'192.168.100.8','admin@gmail.com',6,'2024-03-27 00:59:50',1),(39,'127.0.0.1','admin@gmail.com',6,'2024-03-27 01:23:24',1),(40,'192.168.100.8','admin@gmail.com',6,'2024-03-27 03:04:44',1),(41,'127.0.0.1','admin@gmail.com',6,'2024-03-27 14:35:19',1),(42,'127.0.0.1','admin@gmail.com',NULL,'2024-03-27 08:29:38',0),(43,'127.0.0.1','admin@gmail.com',6,'2024-03-27 08:29:44',1),(44,'36.77.79.206','admin@gmail.com',NULL,'2024-03-27 11:02:09',0),(45,'36.77.79.206','admin@gmail.com',6,'2024-03-27 11:02:16',1),(46,'114.125.230.86','admin@gmail.com',6,'2024-03-27 11:08:58',1),(47,'36.77.79.206','admin@gmail.com',NULL,'2024-03-27 11:10:25',0),(48,'36.77.79.206','admin@gmail.com',6,'2024-03-27 11:10:33',1),(49,'36.77.79.206','admin@gmail.com',6,'2024-03-27 11:52:33',1),(50,'36.77.79.206','admin@gmail.com',NULL,'2024-03-27 12:00:12',0),(51,'36.77.79.206','admin@gmail.com',NULL,'2024-03-27 12:00:17',0),(52,'36.77.79.206','admin@gmail.com',6,'2024-03-27 12:00:27',1),(53,'114.125.230.96','admin@gmail.com',6,'2024-03-27 20:35:58',1),(54,'125.167.59.47','admin@gmail.com',6,'2024-03-27 21:40:04',1),(55,'125.167.50.154','admin@gmail.com',6,'2024-03-28 01:41:51',1),(56,'182.1.229.93','admin@gmail.com',6,'2024-03-28 02:35:54',1),(57,'118.96.188.157','admin@gmail.com',NULL,'2024-03-28 10:27:03',0),(58,'118.96.188.157','admin@gmail.com',6,'2024-03-28 10:27:12',1),(59,'118.96.188.157','admin@gmail.com',6,'2024-03-28 10:30:56',1),(60,'114.125.233.174','admin@gmail.com',6,'2024-03-28 11:06:23',1),(61,'118.96.188.157','admin@gmail.com',6,'2024-03-28 18:00:05',1),(62,'114.125.233.174','admin@gmail.com',6,'2024-03-28 20:12:47',1),(63,'180.241.209.253','admin@gmail.com',6,'2024-03-28 23:45:51',1),(64,'114.125.233.174','admin@gmail.com',6,'2024-03-29 06:30:01',1),(65,'114.125.233.174','admin@gmail.com',6,'2024-03-29 09:32:32',1),(66,'103.169.198.11','admin@gmail.com',6,'2024-03-29 09:56:49',1),(67,'36.65.39.65','admin@gmail.com',6,'2024-03-29 12:57:02',1),(68,'114.125.233.174','admin@gmail.com',6,'2024-03-29 20:32:33',1),(69,'36.65.39.65','admin@gmail.com',6,'2024-03-30 00:19:37',1),(70,'114.125.235.147','admin@gmail.com',6,'2024-03-30 06:33:09',1),(71,'180.254.167.90','admin@gmail.com',NULL,'2024-03-30 09:43:29',0),(72,'180.254.167.90','admin@gmail.com',6,'2024-03-30 09:43:39',1),(73,'180.254.167.90','admin@gmail.com',6,'2024-03-30 11:11:56',1),(74,'114.79.5.143','admin@gmail.com',6,'2024-03-30 21:47:31',1),(75,'182.1.236.92','admin@gmail.com',6,'2024-03-31 03:08:43',1),(76,'180.245.212.225','admin@gmail.com',6,'2024-03-31 03:17:28',1),(77,'182.1.236.116','admin@gmail.com',6,'2024-03-31 06:35:52',1),(78,'182.1.234.120','admin@gmail.com',6,'2024-03-31 09:38:05',1),(79,'182.1.234.120','admin@gmail.com',6,'2024-03-31 19:53:58',1),(80,'125.167.48.142','ahmadramadhon2002@gmail.com',7,'2024-03-31 22:37:33',1),(81,'125.167.48.142','admin@gmail.com',6,'2024-04-01 00:09:16',1),(82,'125.167.48.142','ahmadramadhon2002@gmail.com',7,'2024-04-01 00:58:21',1),(83,'182.1.234.120','admin@gmail.com',6,'2024-04-01 05:58:44',1),(84,'182.1.228.214','admin@gmail.com',6,'2024-04-01 09:58:59',1),(85,'182.1.228.214','admin@gmail.com',6,'2024-04-01 23:45:56',1),(86,'36.77.141.128','admin@gmail.com',6,'2024-04-02 03:10:25',1),(87,'182.1.228.214','admin@gmail.com',6,'2024-04-02 03:13:46',1),(88,'182.1.228.214','rahmat@gmail.com',8,'2024-04-02 04:26:56',1),(89,'182.1.228.214','rahmat@gmail.com',8,'2024-04-02 04:37:06',1),(90,'182.1.236.83','rahmat@gmail.com',8,'2024-04-02 22:37:49',1),(91,'36.77.141.128','admin@gmail.com',6,'2024-04-03 01:28:16',1),(92,'182.1.236.119','rahmat@gmail.com',8,'2024-04-03 03:54:47',1),(93,'182.1.236.83','rahmat@gmail.com',8,'2024-04-03 07:23:47',1),(94,'114.125.228.238','rahmat@gmail.com',8,'2024-04-03 21:18:57',1),(95,'114.125.228.238','rahmat@gmail.com',8,'2024-04-04 02:14:23',1),(96,'114.125.247.230','rahmat@gmail.com',8,'2024-04-04 04:43:54',1),(97,'182.1.228.240','rahmat@gmail.com',8,'2024-04-04 21:18:01',1),(98,'182.1.231.99','rahmat@gmail.com',8,'2024-04-05 23:12:45',1),(99,'182.1.231.123','rahmat@gmail.com',8,'2024-04-06 02:59:21',1),(100,'125.167.56.5','admin@gmail.com',6,'2024-04-09 06:03:25',1),(101,'182.1.228.255','rahmat@gmail.com',8,'2024-04-09 06:04:13',1),(102,'125.167.57.226','admin@gmail.com',NULL,'2024-04-09 10:10:51',0),(103,'125.167.57.226','admin@gmail.com',NULL,'2024-04-09 10:10:55',0),(104,'125.167.57.226','admin@gmail.com',NULL,'2024-04-09 10:10:58',0),(105,'125.167.57.226','admin@gmail.com',6,'2024-04-09 10:11:16',1),(106,'182.1.228.255','rahmat@gmail.com',8,'2024-04-09 21:38:35',1),(107,'182.1.237.64','rahmat@gmail.com',8,'2024-04-10 08:35:45',1),(108,'182.1.237.76','rahmat@gmail.com',8,'2024-04-11 09:25:56',1),(109,'182.1.237.76','rahmat@gmail.com',8,'2024-04-11 20:52:09',1),(110,'180.244.191.14','sandimaulidika@gmail.com',NULL,'2024-04-11 21:49:06',0),(111,'180.244.191.14','admin@gmail.com',6,'2024-04-11 21:49:13',1),(112,'180.244.191.14','admin@gmail.com',6,'2024-04-12 00:51:57',1),(113,'180.244.191.14','admin@gmail.com',NULL,'2024-04-12 00:58:08',0),(114,'180.244.191.14','admin@gmail.com',6,'2024-04-12 00:58:17',1),(115,'125.167.57.237','admin@gmail.com',6,'2024-04-12 10:28:40',1),(116,'125.167.51.53','admin@gmail.com',6,'2024-04-14 22:56:02',1),(117,'182.1.237.118','rahmat@gmail.com',8,'2024-04-16 21:23:45',1),(118,'182.1.237.118','rahmat@gmail.com',8,'2024-04-17 06:52:57',1),(119,'182.1.237.118','rahmat@gmail.com',8,'2024-04-17 09:10:02',1),(120,'182.1.237.118','rahmat@gmail.com',8,'2024-04-17 20:18:32',1),(121,'182.1.237.118','rahmat@gmail.com',8,'2024-04-18 20:17:18',1),(122,'125.167.50.31','admin@gmail.com',NULL,'2024-04-19 02:21:27',0),(123,'125.167.50.31','admin@gmail.com',6,'2024-04-19 02:21:33',1),(124,'182.1.237.118','rahmat@gmail.com',8,'2024-04-19 04:59:11',1),(125,'182.1.237.118','rahmat@gmail.com',8,'2024-04-19 07:05:00',1),(126,'182.1.231.112','rahmat@gmail.com',8,'2024-04-19 20:27:16',1),(127,'182.1.231.112','rahmat@gmail.com',8,'2024-04-19 22:53:10',1),(128,'182.1.231.112','rahmat@gmail.com',8,'2024-04-20 02:53:23',1),(129,'180.245.109.58','admin@gmail.com',6,'2024-04-21 23:13:18',1),(130,'182.1.228.93','admin@gmail.com',6,'2024-04-22 02:05:45',1),(131,'182.1.237.86','rahmat@gmail.com',8,'2024-04-24 01:54:49',1),(132,'182.1.232.169','rahmat@gmail.com',8,'2024-04-24 06:59:46',1),(133,'182.1.232.169','rahmat@gmail.com',8,'2024-04-24 22:22:46',1),(134,'125.167.49.185','admin@gmail.com',6,'2024-04-25 02:35:35',1),(135,'182.1.232.169','rahmat@gmail.com',8,'2024-04-26 05:31:55',1),(136,'182.1.231.149','rahmat@gmail.com',8,'2024-04-29 23:42:48',1),(137,'125.167.48.70','admin@gmail.com',6,'2024-04-30 03:08:50',1),(138,'180.254.162.121','admin@gmail.com',6,'2024-04-30 08:05:26',1),(139,'182.1.229.33','rahmat@gmail.com',8,'2024-05-01 19:17:35',1),(140,'182.1.229.33','rahmat@gmail.com',8,'2024-05-03 02:16:50',1),(141,'103.105.27.101','muhammadalfan131207@gmail.com',NULL,'2024-05-04 16:09:11',0),(142,'103.105.27.101','muhammadalfan131207@gmail.com',NULL,'2024-05-04 16:09:46',0),(143,'103.105.27.101','rahmatb@gmail.com',NULL,'2024-05-04 16:24:01',0),(144,'114.125.230.59','rahmat@gmail.com',8,'2024-05-09 07:34:19',1),(145,'114.125.230.59','rahmat@gmail.com',8,'2024-05-09 10:55:03',1),(146,'182.1.234.37','rahmat@gmail.com',8,'2024-05-09 19:10:30',1),(147,'182.1.234.49','rahmat@gmail.com',8,'2024-05-09 23:21:45',1),(148,'182.1.234.61','rahmat@gmail.com',8,'2024-05-10 07:45:27',1),(149,'182.1.228.231','rahmat@gmail.com',8,'2024-05-10 23:23:25',1),(150,'182.1.229.77','rahmat@gmail.com',8,'2024-05-12 21:50:26',1),(151,'182.1.229.89','rahmat@gmail.com',8,'2024-05-13 02:40:44',1),(152,'114.125.252.191','rahmat@gmail.com',8,'2024-05-15 22:56:51',1),(153,'114.125.246.158','rahmat@gmail.com',8,'2024-05-19 05:36:10',1),(154,'182.1.237.57','rahmat@gmail.com',8,'2024-05-19 20:38:36',1),(155,'125.167.51.46','admin@gmail.com',NULL,'2024-05-20 02:18:50',0),(156,'125.167.51.46','admin@gmail.com',6,'2024-05-20 02:19:05',1),(157,'125.167.51.46','admin@gmail.com',NULL,'2024-05-20 03:28:10',0),(158,'125.167.51.46','admin@gmail.com',6,'2024-05-20 03:28:27',1),(159,'180.254.161.25','admin@gmail.com',NULL,'2024-05-22 10:11:35',0),(160,'180.254.161.25','admin@gmail.com',6,'2024-05-22 10:11:44',1),(161,'182.1.236.228','rahmat@gmail.com',8,'2024-05-22 10:25:17',1),(162,'125.167.51.47','admin@gmail.com',6,'2024-05-23 02:13:26',1),(163,'125.167.51.47','admin@gmail.com',6,'2024-05-23 04:05:58',1),(164,'182.1.229.69','rahmat@gmail.com',8,'2024-05-23 11:22:03',1),(165,'180.254.161.137','admin@gmail.com',6,'2024-05-23 12:22:36',1),(166,'180.254.161.137','admin@gmail.com',6,'2024-05-23 12:23:14',1),(167,'114.125.229.53','rahmat@gmail.com',8,'2024-05-24 04:20:07',1),(168,'180.244.147.233','admin@gmail.com',6,'2024-05-24 11:09:30',1),(169,'114.125.229.53','rahmat@gmail.com',8,'2024-05-24 21:11:05',1),(170,'125.167.57.80','admin@gmail.com',6,'2024-05-26 23:18:09',1),(171,'180.254.169.171','admin@gmail.com',6,'2024-05-27 02:29:46',1),(172,'180.254.169.171','admin@gmail.com',6,'2024-05-27 06:14:09',1),(173,'125.167.58.168','admin@gmail.com',6,'2024-05-28 06:32:41',1),(174,'36.65.33.117','admin@gmail.com',6,'2024-05-28 11:15:25',1),(175,'114.125.237.126','admin@gmail.com',6,'2024-05-30 09:43:36',1),(176,'180.254.175.213','admin@gmail.com',6,'2024-05-30 23:23:45',1),(177,'180.254.175.213','admin@gmail.com',6,'2024-05-31 06:22:23',1),(178,'182.1.232.73','Rahmatdev09@gmail.com',9,'2024-05-31 06:24:19',1),(179,'180.242.43.192','admin@gmail.com',6,'2024-06-01 00:02:42',1),(180,'182.1.232.73','Rahmatdev09@gmail.com',9,'2024-06-01 00:39:13',1),(181,'182.1.232.73','Rahmatdev09@gmail.com',9,'2024-06-01 09:31:23',1),(182,'182.1.232.73','Rahmatdev09@gmail.com',9,'2024-06-01 09:31:23',1),(183,'182.1.232.73','Rahmatdev09@gmail.com',9,'2024-06-01 11:39:54',1),(184,'182.1.232.73','Rahmatdev09@gmail.com',9,'2024-06-01 20:11:15',1),(185,'182.1.232.73','Rahmatdev09@gmail.com',9,'2024-06-02 00:16:15',1),(186,'210.210.131.186','admin@gmail.com',6,'2024-06-02 00:33:53',1),(187,'180.254.160.52','admin@gmail.com',6,'2024-06-02 07:18:28',1),(188,'182.1.232.73','Rahmatdev09@gmail.com',9,'2024-06-02 09:26:34',1),(189,'182.1.232.73','Rahmatdev09@gmail.com',9,'2024-06-02 11:36:28',1),(190,'182.1.232.73','Rahmatdev09@gmail.com',9,'2024-06-02 17:55:19',1),(191,'101.128.104.248','admin@gmail.com',6,'2024-06-03 02:46:33',1),(192,'114.10.99.193','admin@gmail.com',6,'2024-06-03 02:50:14',1),(193,'182.1.232.73','Rahmatdev09@gmail.com',9,'2024-06-03 07:02:17',1),(194,'36.77.131.101','admin@gmail.com',6,'2024-06-03 11:18:29',1),(195,'182.1.232.73','Rahmatdev09@gmail.com',9,'2024-06-03 14:55:35',1),(196,'114.10.98.135','admin@gmail.com',6,'2024-06-04 00:14:52',1),(197,'125.167.57.199','admin@gmail.com',6,'2024-06-05 02:20:59',1),(198,'125.167.57.199','admin@gmail.com',6,'2024-06-05 03:54:39',1),(199,'125.167.57.199','admin@gmail.com',6,'2024-06-05 04:19:28',1),(200,'180.254.174.211','admin@gmail.com',6,'2024-06-05 22:49:34',1),(201,'114.125.251.12','Rahmatdev09@gmail.com',9,'2024-06-05 22:49:49',1),(202,'172.71.81.70','admin@gmail.com',6,'2024-06-06 00:11:46',1),(203,'114.125.251.12','Rahmatdev09@gmail.com',9,'2024-06-06 03:31:45',1),(204,'172.70.188.156','rahmatdev09@gmail.com',NULL,'2024-06-06 03:32:02',0),(205,'172.70.188.157','Rahmatdev09@gmail.com',9,'2024-06-06 03:32:16',1),(206,'172.70.147.31','Rahmatdev09@gmail.com',9,'2024-06-06 06:09:49',1),(207,'172.70.147.75','admin@gmail.com',6,'2024-06-06 10:31:06',1),(208,'172.70.143.95','Rahmatdev09@gmail.com',9,'2024-06-06 20:44:00',1),(209,'162.158.106.177','admin@gmail.com',6,'2024-06-07 00:01:50',1),(210,'172.71.152.35','admin@gmail.com',6,'2024-06-07 02:17:05',1),(211,'172.70.188.76','Rahmatdev09@gmail.com',9,'2024-06-07 02:55:45',1),(212,'172.68.242.121','admin@gmail.com',6,'2024-06-07 10:23:25',1),(213,'162.158.190.8','admin@gmail.com',6,'2024-06-09 04:31:00',1),(214,'162.158.170.184','admin@gmail.com',6,'2024-06-09 08:15:45',1),(215,'162.158.170.185','admin@gmail.com',6,'2024-06-09 08:15:47',1),(216,'172.71.81.69','admin@gmail.com',6,'2024-06-09 10:40:05',1),(217,'162.158.189.92','Rahmatdev09@gmail.com',9,'2024-06-10 00:02:43',1),(218,'162.158.162.20','Rahmatdev09@gmail.com',9,'2024-06-10 23:40:52',1),(219,'172.69.166.109','Rahmatdev09@gmail.com',9,'2024-06-11 06:36:49',1),(220,'172.70.92.199','admin@gmail.com',6,'2024-06-11 06:38:51',1),(221,'162.158.189.32','admin@gmail.com',6,'2024-06-11 11:18:18',1),(222,'162.158.162.145','Rahmatdev09@gmail.com',9,'2024-06-11 20:01:10',1),(223,'162.158.106.35','Rahmatdev09@gmail.com',9,'2024-06-12 06:26:21',1),(224,'172.70.188.109','admin@gmail.com',6,'2024-06-12 09:26:36',1),(225,'172.71.82.115','admin@gmail.com',6,'2024-06-12 22:33:51',1),(226,'108.162.226.140','Rahmatdev09@gmail.com',9,'2024-06-12 22:38:48',1),(227,'162.158.107.37','admin@gmail.com',6,'2024-06-13 03:12:13',1),(228,'172.71.82.114','admin@gmail.com',6,'2024-06-13 04:49:31',1),(229,'172.71.81.70','admin@gmail.com',6,'2024-06-13 07:27:20',1),(230,'162.158.189.103','Rahmatdev09@gmail.com',9,'2024-06-13 11:53:30',1),(231,'172.71.152.15','Rahmatdev09@gmail.com',9,'2024-06-13 22:05:46',1),(232,'172.70.143.185','admin@gmail.com',6,'2024-06-13 23:13:35',1),(233,'172.70.188.184','admin@gmail.com',6,'2024-06-14 09:35:28',1),(234,'162.158.189.237','Rahmatdev09@gmail.com',9,'2024-06-14 09:36:00',1),(235,'162.158.162.16','admin@gmail.com',6,'2024-06-14 11:20:48',1),(236,'162.158.170.111','Rahmatdev09@gmail.com',9,'2024-06-15 03:39:57',1),(237,'172.68.242.121','admin@gmail.com',6,'2024-06-16 22:31:40',1),(238,'172.68.242.120','admin@gmail.com',6,'2024-06-16 22:31:41',1),(239,'108.162.227.64','Rahmatdev09@gmail.com',9,'2024-06-18 00:27:09',1),(240,'172.70.147.78','admin@gmail.com',6,'2024-06-18 14:54:21',1),(241,'108.162.226.117','Rahmatdev09@gmail.com',9,'2024-06-18 21:01:51',1),(242,'172.68.242.121','admin@gmail.com',6,'2024-06-19 00:22:07',1),(243,'162.158.163.227','Rahmatdev09@gmail.com',9,'2024-06-19 10:29:02',1),(244,'172.70.188.109','Rahmatdev09@gmail.com',9,'2024-06-19 19:25:13',1),(245,'162.158.106.114','admin@gmail.com',6,'2024-06-20 18:37:42',1),(246,'108.162.227.34','admin@gmail.com',6,'2024-06-20 20:36:54',1),(247,'108.162.226.191','Rahmatdev09@gmail.com',9,'2024-06-21 10:10:37',1),(248,'162.158.162.22','Rahmatdev09@gmail.com',9,'2024-06-22 18:14:53',1),(249,'172.70.143.30','Rahmatdev09@gmail.com',9,'2024-06-23 19:01:40',1),(250,'172.68.242.120','rahmatdev09@gmail.com',NULL,'2024-06-24 04:46:33',0),(251,'172.68.242.120','rahmatdev09@gmail.com',NULL,'2024-06-24 04:46:39',0),(252,'172.68.242.120','Rahmatdev09@gmail.com',9,'2024-06-24 04:46:55',1),(253,'162.158.107.30','admin@gmail.com',6,'2024-06-26 14:46:05',1),(254,'172.68.242.120','Rahmatdev09@gmail.com',9,'2024-06-28 21:24:45',1),(255,'172.71.152.55','rahmatdev09@gmail.com',NULL,'2024-07-01 08:40:42',0),(256,'172.70.188.76','Rahmatdev09@gmail.com',9,'2024-07-01 08:45:51',1),(257,'172.71.152.11','Rahmatdev09@gmail.com',NULL,'2024-07-01 14:07:32',0),(258,'172.71.152.12','Rahmatdev09@gmail.com',9,'2024-07-01 14:07:53',1),(259,'162.158.189.5','admin@gmail.com',6,'2024-07-01 14:22:04',1),(260,'162.158.162.214','admin@gmail.com',6,'2024-07-02 14:11:18',1),(261,'162.158.107.44','admin@gmail.com',6,'2024-07-02 14:12:39',1),(262,'172.71.81.69','rahmatdev09@gmail.com',NULL,'2024-07-02 15:24:35',0),(263,'172.71.81.70','Rahmatdev09@gmail.com',9,'2024-07-02 15:24:47',1),(264,'172.71.82.115','admin@gmail.com',6,'2024-07-02 19:03:33',1),(265,'162.158.189.5','Rahmatdev09@gmail.com',9,'2024-07-02 20:42:40',1),(266,'108.162.226.140','Rahmatdev09@gmail.com',9,'2024-07-03 09:00:39',1),(267,'162.158.107.22','admin@gmail.com',6,'2024-07-03 10:09:41',1),(268,'172.70.143.165','admin@gmail.com',6,'2024-07-03 10:11:09',1),(269,'172.71.81.70','Rahmatdev09@gmail.com',9,'2024-07-03 12:09:28',1),(270,'172.70.143.127','Rahmatdev09@gmail.com',9,'2024-07-03 20:25:51',1),(271,'162.158.106.109','admin@gmail.com',6,'2024-07-03 20:50:28',1),(272,'162.158.106.77','admin@gmail.com',6,'2024-07-03 22:03:11',1),(273,'108.162.227.97','Rahmatdev09@gmail.com',9,'2024-07-04 11:26:15',1),(274,'172.70.143.204','admin@gmail.com',6,'2024-07-04 19:36:35',1),(275,'162.158.189.191','Rahmatdev09@gmail.com',9,'2024-07-04 20:10:10',1),(276,'108.162.226.108','admin@gmail.com',6,'2024-07-04 22:08:40',1),(277,'172.70.147.120','Rahmatdev09@gmail.com',9,'2024-07-06 10:19:29',1),(278,'162.158.162.20','Rahmatdev09@gmail.com',9,'2024-07-08 06:20:53',1),(279,'172.70.147.121','Rahmatdev09@gmail.com',9,'2024-07-08 19:01:56',1),(280,'162.158.190.115','admin@gmail.com',6,'2024-07-08 20:36:21',1),(281,'172.68.242.120','Rahmatdev09@gmail.com',9,'2024-07-09 10:31:15',1),(282,'172.70.188.157','Rahmatdev09@gmail.com',9,'2024-07-09 17:43:07',1),(283,'172.70.92.152','Rahmatdev09@gmail.com',9,'2024-07-12 08:38:48',1),(284,'108.162.226.71','Rahmatdev09@gmail.com',9,'2024-07-12 19:46:39',1),(285,'172.70.92.161','admin@gmail.com',6,'2024-07-12 23:29:31',1),(286,'172.70.142.184','Rahmatdev09@gmail.com',9,'2024-07-13 22:56:13',1),(287,'172.71.154.254','Rahmatdev09@gmail.com',9,'2024-07-14 08:39:53',1),(288,'172.69.23.152','Rahmatdev09@gmail.com',9,'2024-07-14 18:12:03',1),(289,'172.69.23.152','Rahmatdev09@gmail.com',9,'2024-07-14 18:12:24',1),(290,'172.69.23.152','Rahmatdev09@gmail.com',9,'2024-07-14 18:12:46',1),(291,'162.158.189.190','Rahmatdev09@gmail.com',9,'2024-07-15 00:20:39',1),(292,'172.71.152.12','Rahmatdev09@gmail.com',9,'2024-07-15 23:52:02',1),(293,'172.70.189.61','admin@gmail.com',6,'2024-07-16 00:45:52',1),(294,'172.71.158.127','admin@gmail.com',6,'2024-07-16 16:48:22',1),(295,'172.71.155.14','admin@gmail.com',6,'2024-07-16 16:55:39',1),(296,'172.71.152.11','admin@gmail.com',6,'2024-07-16 20:43:21',1),(297,'172.70.147.167','admin@gmail.com',6,'2024-07-16 22:46:31',1),(298,'162.158.106.185','admin@gmail.com',6,'2024-07-16 23:56:21',1),(299,'172.70.147.196','Rahmatdev09@gmail.com',9,'2024-07-17 00:01:37',1),(300,'172.68.242.121','Rahmatdev09@gmail.com',9,'2024-07-17 11:13:45',1),(301,'172.70.142.64','admin@gmail.com',6,'2024-07-17 15:15:55',1),(302,'172.70.142.126','admin@gmail.com',6,'2024-07-17 17:46:19',1),(303,'172.69.134.82','admin@gmail.com',6,'2024-07-17 19:51:07',1),(304,'162.158.162.195','admin@gmail.com',6,'2024-07-18 12:45:58',1),(305,'172.71.81.218','admin@gmail.com',6,'2024-07-18 12:46:08',1),(306,'162.158.189.4','admin@gmail.com',6,'2024-07-18 15:05:01',1),(307,'172.71.154.251','admin@gmail.com',6,'2024-07-19 12:34:35',1),(308,'172.69.166.19','admin@gmail.com',NULL,'2024-07-19 16:12:16',0),(309,'172.71.82.115','admin@gmail.com',NULL,'2024-07-19 16:13:55',0),(310,'172.70.92.226','gasjek4@gmail.com',NULL,'2024-07-19 16:14:26',0),(311,'172.70.142.53','admin@gmail.com',6,'2024-07-19 16:24:30',1),(312,'162.158.162.17','Rahmatdev09@gmail.com',9,'2024-07-19 16:49:44',1),(313,'172.70.92.227','admin@gmail.com',6,'2024-07-19 21:51:51',1),(314,'162.158.106.20','admin@gmail.com',6,'2024-07-20 10:46:05',1),(315,'162.158.190.57','Rahmatdev09@gmail.com',9,'2024-07-20 11:47:34',1),(316,'162.158.106.205','admin@gmail.com',6,'2024-07-20 13:23:05',1),(317,'172.71.81.217','admin@gmail.com',6,'2024-07-20 17:20:33',1),(318,'172.70.147.7','admin@gmail.com',6,'2024-07-20 22:18:07',1),(319,'172.71.154.75','Rahmatdev09@gmail.com',9,'2024-07-21 09:09:08',1),(320,'172.71.154.147','admin@gmail.com',6,'2024-07-21 13:52:21',1),(321,'172.70.92.227','admin@gmail.com',6,'2024-07-21 17:56:14',1),(322,'172.70.142.22','admin@gmail.com',6,'2024-07-21 19:57:21',1),(323,'172.70.143.96','admin@gmail.com',6,'2024-07-21 20:13:15',1),(324,'172.70.142.22','admin@gmail.com',6,'2024-07-21 21:43:12',1),(325,'172.71.158.148','admin@gmail.com',6,'2024-07-22 10:18:46',1),(326,'162.158.189.102','admin@gmail.com',6,'2024-07-22 14:21:27',1),(327,'162.158.170.94','Rahmatdev09@gmail.com',9,'2024-07-22 14:32:45',1),(328,'108.162.226.109','admin@gmail.com',6,'2024-07-22 16:11:54',1),(329,'172.69.165.66','admin@gmail.com',6,'2024-07-22 19:11:28',1),(330,'172.70.143.62','Rahmatdev09@gmail.com',9,'2024-07-22 19:56:37',1),(331,'162.158.170.78','admin@gmail.com',6,'2024-07-22 20:55:55',1),(332,'172.71.152.12','admin@gmail.com',NULL,'2024-07-23 10:21:19',0),(333,'172.71.152.12','admin@gmail.com',NULL,'2024-07-23 10:21:26',0),(334,'172.71.152.11','admin@gmail.com',6,'2024-07-23 10:21:35',1),(335,'108.162.226.28','admin@gmail.com',6,'2024-07-23 11:35:16',1),(336,'162.158.106.192','Rahmatdev09@gmail.com',9,'2024-07-23 12:20:41',1),(337,'172.71.81.70','admin@gmail.com',6,'2024-07-23 16:06:44',1),(338,'162.158.106.34','Rahmatdev09@gmail.com',9,'2024-07-23 16:20:49',1),(339,'162.158.107.22','admin@gmail.com',6,'2024-07-23 16:26:42',1),(340,'162.158.163.212','admin@gmail.com',NULL,'2024-07-23 19:47:43',0),(341,'162.158.163.212','admin@gmail.com',6,'2024-07-23 19:47:53',1),(342,'172.68.242.120','Rahmatdev09@gmail.com',9,'2024-07-23 20:13:15',1),(343,'162.158.106.185','admin@gmail.com',6,'2024-07-23 20:46:25',1),(344,'162.158.106.200','admin@gmail.com',6,'2024-07-23 21:37:59',1),(345,'172.71.152.36','admin@gmail.com',6,'2024-07-23 23:21:59',1),(346,'162.158.163.247','Rahmatdev09@gmail.com',9,'2024-07-23 23:22:03',1),(347,'172.70.147.193','Rahmatdev09@gmail.com',9,'2024-07-24 06:26:49',1),(348,'172.70.143.30','admin@gmail.com',6,'2024-07-24 08:27:14',1),(349,'172.71.82.115','rahmatdev09@gmail.com',NULL,'2024-07-24 08:55:42',0),(350,'172.71.82.115','rahmatdev09@gmail.com',NULL,'2024-07-24 08:55:43',0),(351,'172.71.82.115','rahmatdev09@gmail.com',NULL,'2024-07-24 08:55:54',0),(352,'172.71.82.115','Rahmatdev09@gmail.com',9,'2024-07-24 08:56:07',1),(353,'162.158.171.24','admin@gmail.com',6,'2024-07-24 09:43:56',1),(354,'172.68.242.120','admin@gmail.com',6,'2024-07-24 09:59:34',1),(355,'162.158.106.114','admin@gmail.com',6,'2024-07-24 10:13:45',1);
/*!40000 ALTER TABLE `auth_logins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permissions`
--

DROP TABLE IF EXISTS `auth_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permissions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permissions`
--

LOCK TABLES `auth_permissions` WRITE;
/*!40000 ALTER TABLE `auth_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_reset_attempts`
--

DROP TABLE IF EXISTS `auth_reset_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_reset_attempts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `token` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_reset_attempts`
--

LOCK TABLES `auth_reset_attempts` WRITE;
/*!40000 ALTER TABLE `auth_reset_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_reset_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_tokens`
--

DROP TABLE IF EXISTS `auth_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_tokens` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `selector` varchar(255) NOT NULL,
  `hashedValidator` varchar(255) NOT NULL,
  `user_id` int unsigned NOT NULL,
  `expires` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `auth_tokens_user_id_foreign` (`user_id`),
  KEY `selector` (`selector`),
  CONSTRAINT `auth_tokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_tokens`
--

LOCK TABLES `auth_tokens` WRITE;
/*!40000 ALTER TABLE `auth_tokens` DISABLE KEYS */;
INSERT INTO `auth_tokens` VALUES (12,'afc3affbda9a057a133f4bc5','b173127de54e461a55c7f7e5b1b52949d8baae5078d0aa96f6f713614aadb7c2',6,'2024-08-22 23:21:59');
/*!40000 ALTER TABLE `auth_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_users_permissions`
--

DROP TABLE IF EXISTS `auth_users_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_users_permissions` (
  `user_id` int unsigned NOT NULL DEFAULT '0',
  `permission_id` int unsigned NOT NULL DEFAULT '0',
  KEY `auth_users_permissions_permission_id_foreign` (`permission_id`),
  KEY `user_id_permission_id` (`user_id`,`permission_id`),
  CONSTRAINT `auth_users_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `auth_permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `auth_users_permissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_users_permissions`
--

LOCK TABLES `auth_users_permissions` WRITE;
/*!40000 ALTER TABLE `auth_users_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_users_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int NOT NULL,
  `batch` int unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2017-11-20-223112','Myth\\Auth\\Database\\Migrations\\CreateAuthTables','default','Myth\\Auth',1673956276,1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_admin`
--

DROP TABLE IF EXISTS `tb_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_admin` (
  `id_admin` int NOT NULL AUTO_INCREMENT,
  `username_admin` varchar(1000) NOT NULL,
  `email_admin` varchar(255) NOT NULL,
  `password_admin` varchar(255) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_admin`
--

LOCK TABLES `tb_admin` WRITE;
/*!40000 ALTER TABLE `tb_admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_application`
--

DROP TABLE IF EXISTS `tb_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_application` (
  `id_application` int NOT NULL AUTO_INCREMENT,
  `admin_phone` varchar(225) NOT NULL,
  `app_name` varchar(225) NOT NULL,
  `waktu_operasional` int NOT NULL,
  `key_message` text NOT NULL,
  PRIMARY KEY (`id_application`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_application`
--

LOCK TABLES `tb_application` WRITE;
/*!40000 ALTER TABLE `tb_application` DISABLE KEYS */;
INSERT INTO `tb_application` VALUES (1,'6285896617773','GASJek',22,'key=AAAAsEFfA94:APA91bEWcdw5T9V5stayg_MZqPPJPhz2VbbuvRujVCU8OJg4t1hauqodHK_k_RgqS_B9dCnDNEX-ZXrS69RCrSr7ipSj5CiF6EZ4jodIVuHKb3B2Ajjr1fNSRv4ejomIHQ6UXF69kmgF');
/*!40000 ALTER TABLE `tb_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_balance`
--

DROP TABLE IF EXISTS `tb_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_balance` (
  `id_transaction` int NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `balance` int NOT NULL,
  `type_payment` varchar(255) NOT NULL,
  `date` varchar(1000) NOT NULL,
  `status_payment` enum('pending','success') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `id_user` int NOT NULL,
  `method_payment` varchar(100) NOT NULL,
  `role` varchar(225) NOT NULL,
  PRIMARY KEY (`id_transaction`)
) ENGINE=InnoDB AUTO_INCREMENT=1009734726 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_balance`
--

LOCK TABLES `tb_balance` WRITE;
/*!40000 ALTER TABLE `tb_balance` DISABLE KEYS */;
INSERT INTO `tb_balance` VALUES (635,'M Ragil fajariansyah',500,'expenditure','24-07-2024 11:03:15','success',47,'admin','driver'),(750,'VEMAS RAMADHON ',500,'expenditure','24-07-2024 11:46:24','success',38,'admin','driver'),(755,'M Ragil fajariansyah',500,'expenditure','24-07-2024 11:24:18','success',47,'admin','driver'),(18460,'Abdul Azis',40000,'top_up','2024-07-24 10:20:49','success',42,'admin','driver'),(42782,'Ikhsan maulana ',40000,'top_up','2024-07-24 11:11:14','success',45,'admin','driver'),(51470,'Ahmad Restullah',40000,'top_up','2024-07-24 10:21:19','success',43,'admin','driver'),(55757,'M Ragil fajariansyah',40000,'top_up','2024-07-24 10:20:35','success',47,'admin','driver'),(59549,'VEMAS RAMADHON ',40000,'top_up','2024-07-24 10:21:00','success',38,'admin','driver'),(70295,'gustiranggapratama',40000,'top_up','2024-07-24 10:21:32','success',48,'admin','driver'),(86487,'RIAN RIZKI PRATAMA ',40000,'top_up','2024-07-24 10:21:09','success',39,'admin','driver'),(106324924,'Ahmad Azhari',10000,'top_up','24-07-2024 11:06:07','pending',49,'admin','driver'),(1009734724,'Ahmad April',52500,'top_up','2024-07-24 11:54:24','pending',139,'gopay','user'),(1009734725,'Ahmad April',52500,'top_up','2024-07-24 11:54:33','pending',139,'gopay','user');
/*!40000 ALTER TABLE `tb_balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_banner`
--

DROP TABLE IF EXISTS `tb_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_banner` (
  `id_banner` int NOT NULL AUTO_INCREMENT,
  `position_banner` int NOT NULL,
  `url_image_banner` varchar(255) NOT NULL,
  PRIMARY KEY (`id_banner`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_banner`
--

LOCK TABLES `tb_banner` WRITE;
/*!40000 ALTER TABLE `tb_banner` DISABLE KEYS */;
INSERT INTO `tb_banner` VALUES (14,1,'Please.png'),(15,2,'GASFood 200x80cm.png'),(16,3,'GASRide.png'),(17,4,'GASSend.png');
/*!40000 ALTER TABLE `tb_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_driver`
--

DROP TABLE IF EXISTS `tb_driver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_driver` (
  `id_driver` int NOT NULL AUTO_INCREMENT,
  `username_rider` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email_rider` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `date_register` datetime DEFAULT NULL,
  `balance_rider` int NOT NULL,
  `image_rider` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `vehicle_name` varchar(225) COLLATE utf8mb4_general_ci NOT NULL,
  `password_rider` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `type_vehicle` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `is_status` enum('waiting','accept','block','cancel') COLLATE utf8mb4_general_ci NOT NULL,
  `location` varchar(225) COLLATE utf8mb4_general_ci NOT NULL,
  `police_number` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `is_active` enum('false','true') COLLATE utf8mb4_general_ci NOT NULL,
  `fcm_token` text COLLATE utf8mb4_general_ci NOT NULL,
  `rider_latitude` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `rider_longitude` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone_rider` varchar(225) COLLATE utf8mb4_general_ci NOT NULL,
  `rating_driver` int NOT NULL,
  PRIMARY KEY (`id_driver`),
  UNIQUE KEY `email_rider` (`email_rider`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_driver`
--

LOCK TABLES `tb_driver` WRITE;
/*!40000 ALTER TABLE `tb_driver` DISABLE KEYS */;
INSERT INTO `tb_driver` VALUES (32,'Gasjek Bie','gasjek4@gmail.com','2024-06-13 07:27:03',0,'Gasjek Bie-2024-07-21-11:53.jpg','BEAT FI','$2y$10$8zuYy2fJ1BcIsKyJSD5NbezOq93ReMuDs2WiijyuoOHU5SErCrecm','ride','accept','Gelumbang','BG 1382 DA','true','d07Z4ZQ0QHKsxXMf2hQfyO:APA91bH7Xo2O7k1Jtn8fAQhvtH70AWkxdW0VMzAHu2b3Q81DMD90EdQbufQrU-hGjsc5GB2cSBiZ33w06Eh_YpftROvq6pX3dIWuGBSfsdeNVGW71mzUNnoQTc7PC3tcYgcnj-RS9DhK','-3.2399826','104.4353491','085896617773',5),(35,'Tester','testingdriver@gmail.com','2024-07-01 14:21:42',0,'tester - 9884.jpg','Beat','$2y$10$FUBkMnzKZWRAiaz.AnBT3..9dcWbMoLQ0aUxhpjG9fT//lRX8CXDC','ride','accept','Gelumbang','BG 1123 TA','false','','-6.1537','106.9167','087801751654',5),(37,'Ahmad Romadhon','ahmadramadhon2000@gmail.com','2024-07-17 15:21:38',0,'ahmadromadhon - 9201.jpg','HONDA','$2y$10$pveOP9CkcVhAbl6iR1Auj.YhDmbu0/H3HMv16T3LArpw7wAsPg7cW','ride','accept','Gelumbang','BG 1090 MV','false','ecGuJpv8Sd-bJzaWY42ZNx:APA91bFZAqplleWeXUfN8e1F-X5pn8mqfq48QmF6BXPn18BoAniFHQGRg39SRVWKi-q7SOT3fzOTnT4zmjjjj-aX_eulInT2uGKdXtsKccvUPLlEPtvsPX5Vj84vv-a80-VKZbcLQ-gh','-3.2361314','104.4403345','085658310826',5),(38,'VEMAS RAMADHON ','vemasramadhonbe@gmail.com','2024-07-20 13:27:03',38585,'VEMAS RAMADHON -2024-07-23-22:21.jpg','Beat','$2y$10$sWjqTylW3wgsJE917658a.XJeZzZfGZ/I/jPVYzFpYDw8hotQOYoC','ride','accept','Gelumbang','BG 8431 CU','false','eqJVEYw6SnuqB7S9FtUi0f:APA91bGb5Dt2JNFq0He3XHbfC1eep5gZ7datH1VSudmsuHWvHWRDiV8Fv4hwKWua5Qy9HQbQEhdK7VD7SdOZS_gEANBw15656QjF0eTS7UuHXtfvuBKVvxxCwCND5WLDHFobMwEeu4l2','-3.3050633','104.3977133','085157252298',5),(39,'RIAN RIZKI PRATAMA ','riom28418@gmail.com','2024-07-20 13:28:57',40000,'RIAN RIZKI PRATAMA -2024-07-20-17:04.jpg','Beat','$2y$10$hylJD.QgBMIYcs.kDqcaEuKQDX5A8T0Bo/OyfulO4cY8GoLQhDd8.','ride','accept','Gelumbang','BG 5598 DAL','true','cKnz_Bz-TZGF7pbdijmuVH:APA91bHX51ZE6pvxeDa4SP4oJsRk1sirt74B6fisp0vM7ez_b3PabBzbNX0pRcWknKPM0dcD4eXkBvG0DLErOW_e-Os1VYgWvg29gMs0YM5OBkG3gXBhu35hOH5cOzTTspYJdl0Has0M','-3.3050573','104.3976677','083146481184',5),(40,'Dirly Dwi ananda','Dirly Dwi ananda','2024-07-21 21:04:17',0,'dirlydwiananda - 6415.jpg','Beat','$2y$10$KLhO5H/VNfjDFOC3fG4tcuZtWBvf2lZBXM3dP1DZSPKAOlIbKb0R6','ride','block','Gelumbang','beat','false','dIhTH7yUQHKDkt6FlnIQKu:APA91bFDiISOCj0BIQf3qyO3FpNLN6PFZkEUfbDAs7rmtrQODgKlFxVr7iZ5hBOlXLIO7Yc7R8x8PL7JugiTsLwJm-0PuiqcKbsvRp_WTVHjRIwJ81jTCJ0UltSxOcViWvaMJrRdF8GT',NULL,NULL,'083130774422',5),(41,'ilham Maulana','hammaulana103@gmail.com','2024-07-21 21:09:31',0,'ilham Maulana-2024-07-21-22:13.jpg','Vega','$2y$10$DaElBnAKWgztOzsebN27V.7gaZQvMiYkhhHTcmYS4hsj/ZBZ2NWPe','ride','accept','Gelumbang','BG 3576 DD','false','dIhTH7yUQHKDkt6FlnIQKu:APA91bFDiISOCj0BIQf3qyO3FpNLN6PFZkEUfbDAs7rmtrQODgKlFxVr7iZ5hBOlXLIO7Yc7R8x8PL7JugiTsLwJm-0PuiqcKbsvRp_WTVHjRIwJ81jTCJ0UltSxOcViWvaMJrRdF8GT','-3.2319663','104.4418116','083172939018',5),(42,'Abdul Azis','abdulazis161218@gmail.com','2024-07-21 21:10:58',40000,'Abdul Azis-2024-07-21-22:15.jpg','Honda Adv','$2y$10$odCbd4aRgBPVzEjZhZBziOJphGGOHQzOvwQ4/9TxRJVevA9JO90JO','ride','accept','Gelumbang','BG 3520 DAT','false','euFZoAoPSIqpcU3EiXh_H7:APA91bFEUig0PmXgtOxMsLhl9Q1R7WBertnkUlNpFG5lReb-ULvG5qVD-Q4f3ss2LoS9uHLC_CWfSoElTNMZJGnSiA8jWRSn4ghfEQvjOtslYTi5Qb4xovJi8mUIqC9QEtHMvdG4xLah','-3.2345588','104.4421828','083178910285',5),(43,'Ahmad Restullah','restullah270403@gmail.com','2024-07-21 21:30:34',40000,'Ahmad Restullah-2024-07-21-22:13.jpg','Beat','$2y$10$VrifeDmLPfXETOY1b.7C1.vEfLyPbTBMp6zQF//cLoUr78XyzDlmG','ride','accept','Gelumbang','B 270603 AH','false','e1GBdXkCQISiXVPk_vE15k:APA91bFXjHogEZjgFI3WXSYT6tLX_aOecCIEB1myo6bxhfGZ7XBQWAEpvlBwylYfkEJ8YltgeTn2j8sLZ9iD1WX_X3swSnSBUHc-MzGd7T7_gaXv_IAvpHT5PoxwqQ8WO4aRQmxAfWF5','-3.2328084','104.4448552','083169549960',5),(44,'wawan','rahmat280701@gmail.com','2024-07-21 21:49:32',0,'wawan-2024-07-21-21:57.jpg','Beat','$2y$10$F91QiEC1e5QvIdlu0kL48.cNW3atCrP4Zgu8o3h9JFEsbO1H2hmUa','ride','accept','Gelumbang','BG 5699 DAL','false','cPNuv_aAQQefn61DNppWGE:APA91bFVAT8wAcgSS4mwM5cY0bSOk7bUOydLBLcf8RQ-o26vsRUpmM0HDVVIn9Wo55AtCwerSfKeIUrn8nX0F3HPwpboWrAxj0Z7N7kupmuztv7qWswfh2er317yutp8pY7WfnveN85O','-3.2212791','104.4830666','088286838311',5),(45,'Ikhsan maulana ','exselrobert@gmail.com','2024-07-21 23:26:58',40000,'Ikhsan maulana -2024-07-23-21:56.jpg','Revo Fit','$2y$10$sfcmtQa3h3WJHOOzfcBlK.iG9RiiHciPQSmh/ig1.Q0GodBpW8tVG','ride','accept','Gelumbang','BG 2903 DC','true','eRuD80dyQLq5m5lT_rPtOG:APA91bHcSvXxSxAgbAklZuxcjUdAjkLwMCHYl4hBmSFC65JRPrkGCAkpSrktgjI_jdiorGV2rRMTaXJRSF4j40QyBycwoflWNYyOMYhLYfY6IQPC7nL2I6_mC17DGw07U7hIDxrp7Ckj','-3.2330633','104.4466017','088268385846',5),(46,'muhamad dianur ','mdianursajake58@gmail.com','2024-07-23 13:19:58',0,'muhamaddianur - 7871.jpg','Revo','$2y$10$KbPzZBDH4EvdFrZMkNO3guE2ocfreifCSRBGcEjIxobsb7iVdOXHK','ride','waiting','Ogan Ilir','B 6328 EOj','false','cj4rwp6uQVajBLwrUvnQCd:APA91bF2nXbxgJix_q-ET8hSc7B2I5jCwZXv7XExPx2ZWVoKYVdNli25sxi309ufN1Ual6lGlReO2uVibe6DSPDSy0vu7Zn_txssijHvt9z8a5pwznQFlInAtulcCfIubboXaZzEWQ1t','-6.337439','106.8328302','0853831615400',0),(47,'M Ragil fajariansyah','Rusnellyyanto@gmail.com','2024-07-23 20:40:46',38000,'M Ragil fajariansyah-2024-07-24-08:13.jpg','Revo','$2y$10$QvxWV4RiRXf8zZOPaCDH5O.Rzr/W0CtbCL/K0MdrDEo9JcNTmT2sC','ride','accept','Gelumbang','BG6959DC','true','e2DuNh8jQxiavX8CZKagIG:APA91bF2keZ0_TKPUfvKVRoPoFxerIE5EbY29M-p2KnIVHFswugGU9KcX9QhnVTvIecwRsEa7QzSF4MMZihhTuddskKGBtuuMob2bFL-CsJtP2gqy3ozR49VWqLWVxndJsjJPkFvFKKt','-3.2636802','104.4678965','085788867559',0),(48,'gustiranggapratama','gustirangga115@gmail.com','2024-07-23 20:42:30',40000,'gustiranggapratama-2024-07-24-11:12.jpg','Vario','$2y$10$8uKNHp46zPmgmSANS0NjOeab43AJg1Q0gAMyUiqclOblgOJwGBFf.','ride','accept','Gelumbang','2387','true','eLy691nLStmvY9UuVoJRaW:APA91bEgt8sFN9rIi5JgqXXbA8ibZPE7abjxR3KK5MJ6d-dqedDkBOgYgALBpaGKEuJiq5BOz1I0tOetk-K-VZqoeEnPW23QA3YLWUy0DYVqaNukM1lNpQTtPB1wa5aF9djkBT2sVFvx','-3.2323149','104.4419038','083164808836',0),(49,'Ahmad Azhari','ahmad.azhari980901@gmail.com','2024-07-24 11:01:00',0,'ahmadazhari - 8631.jpg','Honda beat','$2y$10$DPVRnl9VmuAvmh1N.xd3B.3QDvV7tPKYNHdO/OvP6bQfq8bEKwwHu','ride','waiting','Gelumbang','BG 3716 AAM','false','cLJ6tUZeSgCI6TH7z7zh0k:APA91bHJY_e3HWeN_ijQ-2zEkd_I50zruqSqXKY-w5LTHz3oE96686INKP2uAPgizIDYHmDlH24TpJ0eUaxEc0mUGUxZJiNo3AEDEqQP7O7PRsFrSZolCJRjkM3i4dX9VBExGma5DzoS','-2.9347765','104.7883274','083172952033',0);
/*!40000 ALTER TABLE `tb_driver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_feature`
--

DROP TABLE IF EXISTS `tb_feature`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_feature` (
  `id_fitur` int NOT NULL AUTO_INCREMENT,
  `feature_name` varchar(3000) NOT NULL,
  `feature_description` varchar(3000) NOT NULL,
  `feature_status` varchar(3000) NOT NULL,
  `feature_image` varchar(3000) NOT NULL,
  PRIMARY KEY (`id_fitur`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_feature`
--

LOCK TABLES `tb_feature` WRITE;
/*!40000 ALTER TABLE `tb_feature` DISABLE KEYS */;
INSERT INTO `tb_feature` VALUES (1,'Kin Send','Kin Send merupakan fitur kirim barang, seperti berkas dan lain lain','active','<svg xmlns=\"http://www.w3.org/255/svg\" id=\"vector\" width=\"50\" height=\"50\" viewBox=\"0 0 24 24\" class=\"icon_fitur\">                                             <path d=\"M19,7c0,-1.1 -0.9,-2 -2,-2h-3v2h3v2.65L13.52,14H10V9H6c-2.21,0 -4,1.79 -4,4v3h2c0,1.66 1.34,3 3,3s3,-1.34 3,-3h4.48L19,10.35V7zM4,14v-1c0,-1.1 0.9,-2 2,-2h2v3H4zM7,17c-0.55,0 -1,-0.45 -1,-1h2C8,16.55 7.55,17 7,17z\" id=\"path_0\"></path><path fill=\"@android:color/white\" d=\"M5,6h5v2h-5z\" id=\"path_1\"></path><path fill=\"@android:color/white\" d=\"M19,13c-1.66,0 -3,1.34 -3,3s1.34,3 3,3s3,-1.34 3,-3S20.66,13 19,13zM19,17c-0.55,0 -1,-0.45 -1,-1s0.45,-1 1,-1s1,0.45 1,1S19.55,17 19,17z\" id=\"path_2\"></path>                                         </svg>'),(2,'Saldo','Fitur saldo merupakan fitur','active','<svg xmlns=\"http://www.w3.org/255/svg\" viewBox=\"0 0 24 24\" width=\"50\" height=\"50\" class=\"icon_fitur\">                                             <g data-name=\"Layer 2\">                                                 <g data-name=\"credit-card\">                                                     <rect width=\"24\" height=\"24\" opacity=\"0\"></rect>                                                     <path d=\"M19 5H5a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3V8a3 3 0 0 0-3-3zM4 8a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v1H4zm16 8a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-5h16z\"></path><path d=\"M7 15h4a1 1 0 0 0 0-2H7a1 1 0 0 0 0 2z\"></path>                                                     <path d=\"M15 15h2a1 1 0 0 0 0-2h-2a1 1 0 0 0 0 2z\"></path>                                                 </g>                                             </g>                                         </svg>'),(3,'Kin Store','Kin Store merupakan fitur dimana driver dapat menukar poin yang didapatkan setelah menyelesaikan pesanan dengan beberapa barang yang tersedia','not_active','  <svg xmlns=\"http://www.w3.org/255/svg\" viewBox=\"0 0 24 24\" class=\"icon_fitur\">                                             <g data-name=\"Layer 2\">                                                 <g data-name=\"shopping-bag\">                                                     <rect width=\"24\" height=\"24\" opacity=\"0\"/>                                                     <path d=\"M20.12 6.71l-2.83-2.83A3 3 0 0 0 15.17 3H8.83a3 3 0 0 0-2.12.88L3.88 6.71A3 3 0 0 0 3 8.83V18a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V8.83a3 3 0 0 0-.88-2.12zm-12-1.42A1.05 1.05 0 0 1 8.83 5h6.34a1.05 1.05 0 0 1 .71.29L17.59 7H6.41zM18 19H6a1 1 0 0 1-1-1V9h14v9a1 1 0 0 1-1 1z\"/>                                                     <path d=\"M15 11a1 1 0 0 0-1 1 2 2 0 0 1-4 0 1 1 0 0 0-2 0 4 4 0 0 0 8 0 1 1 0 0 0-1-1z\"/>                                                 </g>                                             </g>                                         </svg>');
/*!40000 ALTER TABLE `tb_feature` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_food`
--

DROP TABLE IF EXISTS `tb_food`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_food` (
  `id_food` int NOT NULL AUTO_INCREMENT,
  `id_restaurant` int NOT NULL,
  `food_name` varchar(255) NOT NULL,
  `food_price` int NOT NULL,
  `food_quantity` int NOT NULL,
  `food_image` varchar(255) NOT NULL,
  `food_desc` text NOT NULL,
  `food_category` varchar(3000) NOT NULL,
  PRIMARY KEY (`id_food`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_food`
--

LOCK TABLES `tb_food` WRITE;
/*!40000 ALTER TABLE `tb_food` DISABLE KEYS */;
INSERT INTO `tb_food` VALUES (17,37,'Seblak Komplit',10000,100,'Seblak Komplit - 8105.jpg','Terdapat level 0-5','drink'),(21,37,'Seblak Level 2',20000,10,'Seblak Komplit - 8105.jpg','Makanan nya dak enak','drink'),(22,51,'Es Balap',10000,10,'Es Balap - 5349.jpg','Kopi + aren + susu','drink'),(23,50,'Mie Jebew',10000,20,'Mie Jebew - 647.jpg','Bisa Level 0 - 5','food'),(24,50,'Ayam Geprek',13000,20,'Ayam Geprek - 8097.jpg','Pedas, Gurih , Enak','food'),(25,50,'Ayam Samyang',15000,20,'Ayam Samyang - 6911.jpg','Pedas, Manis, Gurih','food'),(26,50,'Indomie Tumis',10000,20,'Indomie Tumis - 1649.jpg','Pakai telor','food'),(29,50,'Toping Seblak (Cikua)',2000,50,'Seblak Prasmanan  - 8703.jpg','cikua ','food'),(30,50,'Toping Seblak (Dunpling isi keju / ayam)',2000,50,'Dumpling - 9439.jpg','Dunpling isi keju / ayam','food'),(35,50,'Toping Seblak (Otak - Otaks)',1000,50,'Seblak prasmanan - 7315.jpg','Otak-otak','food'),(36,50,'Toping Seblak (Otak - Otak)',1000,50,'Seblak prasmanan - 4737.jpg','Otak-otak','food'),(38,56,'Rendang',10000,9999,'rendang - indonesia1_1.jpg','Ini rendang','food'),(39,56,'Pindang Patin',13000,20000,'62cf613cad9a8_1.jpeg','ini patin','food'),(40,58,'Rendang',10000,9999,'rendang - indonesia1_2.jpg','Ini rendang','food'),(41,58,'Pindang Patin',12000,9999,'62cf613cad9a8_2.jpeg','ini patin','food'),(42,58,'Sapi',20000,99999,'62cf613cad9a8_3.jpeg','adawewqe','food'),(43,58,'kerbau',20000,999,'rendang - indonesia1_3.jpg','awdasda','food'),(44,58,'seblak',20000,9999,'rendang - indonesia1_4.jpg','adasd','food'),(52,60,'Bakso Ayam',5000,999,'5ed5f39c7d8fe.jpg','Berkuah enak sekali','food'),(53,61,'Seblak cuanki',10000,999,'Seblak cuanki - 7493.jpg','Tersedia level 1-5','food'),(54,61,'Pistel Ayam Jeletot',5000,10,'Pistel Ayam Jeletot - 2880.jpg','1 porsi isi 3 pcs','food'),(55,61,'Es kul kul buah semangka',2000,15,'Es kul kul buah semangka - 9723.jpg','Tanpa toping','drink'),(56,61,'Es kul kul buah anggur',3000,10,'Es kul kul buah anggur - 338.jpg','Tanpa toping','drink'),(57,61,'Es kul kul buah naga',3000,10,'Es kul kul buah naga - 862.jpg','Tanpa toping','drink'),(58,61,'Es kul kul buah melon',2000,15,'Es kul kul buah melon - 5966.jpg','Tanpa toping','drink'),(59,61,'Es Kul kul buah nangka',3000,20,'Es Kul kul buah nangka - 4487.jpg','Tanpa toping','drink'),(60,61,'Baso Aci Original',16000,999,'Baso Aci Original - 9956.jpg','Pedas','food'),(61,63,'Mie Pangsit',13000,999,'Mie Pangsit - 416.jpg','Mie pangsit','food'),(62,63,'ES Kacang Merah',8000,99,'es kacangerah - 7807.jpg','es kacang merah','drink'),(63,63,'es sup buah',6000,99,'es sup buah - 6029.jpg','es sup buah','drink'),(64,63,'es campur',5000,99,'es campur - 6981.jpg','es campur','drink'),(65,67,'Model Biasa',5000,999,'Model Biasa - 6175.jpg','Model Biasa','food'),(66,68,'Nugget',1000,100,'Nugget - 7640.jpg','dapat saos','food'),(67,68,'Bakso Tahu',2000,100,'bakso tahu - 5499.jpg','bisa pakai saos','food'),(68,61,'Es kul kul buah mangga',3000,999,'Es kul kul buah mangga - 9488.jpg','Tanpa toping','drink'),(69,61,'Es Buko Pandan',5000,999,'Es Buko Pandan - 8390.jpg','percup','drink'),(70,69,'Ayam bakar Dada',23000,999,'Ayam bakar Dada - 1532.jpg','Ayam bakar saos bbq, nasi es+ es teh','food'),(72,69,'Seblak komplit',22000,999,'Seblak komplit - 1045.jpg','Seblak, dengan berbagai toping','food'),(74,69,'Paket Exprezz 1',18000,999,'Exprezz 1 - 5630.jpg','Ayam Sayap / Paha bawah+Saos Sachet+Nasi+es teh','food'),(75,69,'Paket Exprezz 2',20000,999,'Exprezz 2 - 5695.jpg','Ayam Dada / Paha atas+saos sachet + nasi + es teh','food'),(76,69,'Paket Ayam Geprek',23000,999,'Ayam Geprek - 9502.jpg','Dada / Paha Atas , Sambel Bawang+nasi+es teh','food'),(77,69,'Paket Ayam Empuk',24000,999,'Ayam Empuk - 3024.jpg','Ayam Fresto, digoreng, Sambal Bawang, nasi, es teh','food'),(78,69,'Paket Ayam Selimut ',25000,999,'Ayam Selimut  - 6177.jpg','Ayam Fresto, Dibaluri Telur digoreng, Sambel Bawang, nasi, es teh','food'),(79,69,'Mie Geprek',15000,999,'Mie Geprek - 9599.jpg','Mie tumisan cabe, telur ceplok, kerupuk','food'),(80,69,'Paket Ayam Dadar',25000,999,'Ayam Dadar - 2629.jpg','Ayam suir di dadar dengan telur,saos fire, nasi, es teh','food'),(81,69,'Nugget Ayam',10000,999,'Nugget Ayam - 6517.jpg','6 Pcs + saos ','food'),(82,69,'French Fries',10000,999,'French Fries - 9534.jpg','kentang goreng + saos','food'),(85,69,'Bezt Alacarte',10000,999,'Bezt Alacarte - 2636.jpg','Ayam ori saja, Sayap/paha bawah + saos ','food'),(86,69,'Coconut jelly milktea',17000,999,'Coconut jelly milktea - 9754.jpg','Minuman , susu , dan toping jelly','drink'),(87,58,'ncjc',8653,686,'ncjc - 8007.jpg','cjcj','food'),(88,58,'ncjc',8653,686,'ncjc - 9240.jpg','cjcj','food'),(90,77,'Pangsit Goreng',1000,100,'Pangsit Goreng - 8126.jpg','Panas','food'),(91,77,'Bakso',5000,100,'Bakso - 5246.jpg','bisa req pedas','food'),(92,77,'Mie Ayam',5000,100,'download.jpeg','Topping ayam','food'),(93,77,'Mie Ayam Bakso',5000,100,'Screenshot 2024-07-23 at 19.53.28.png','Topping ayam + bakso','food'),(94,78,'Bakso Lemak',5000,999,'demo.jpg','Enak nian','food'),(95,80,'pecel lele',16000,999,'pecel lele - 2831.jpg','pecel lele','food'),(96,58,'ufuf',85757,885,'ufuf - 2768.jpg','hcuf','food'),(101,61,'Seblak Chikuwa',10000,999,'Seblak Chikuwa - 3964.jpg','seporsi','food'),(102,61,'Seblak Ceker ',10000,999,'Seblak Ceker  - 7948.jpg','seporsi','food'),(103,58,'jzhz',845,864,'jzhz - 7630.jpg','jshzh','food'),(104,58,'jzhz',845,864,'jzhz - 7630.jpg','jshzh','food'),(105,58,'jzhz',845,864,'jzhz - 7630.jpg','jshzh','food'),(106,68,'Seblak',10000,100,'WhatsApp Image 2024-07-23 at 22.58.24.jpeg','Level 1-3','food'),(107,68,'Mie Baper',10000,100,'WhatsApp Image 2024-07-23 at 22.59.26.jpeg','Level 1-3','food'),(108,81,'agar-agar ',1000,100,'agar-agar  - 1964.jpg','rasa pandan','food'),(109,62,'Bakso Super',15000,1,'Bakso Super - 3649.jpg','1 pcs bakso super 5 pcs bakso kecil','food'),(110,62,'Bakso Super',15000,1,'Bakso Super - 5029.jpg','1 pcs bakso super 5 pcs bakso kecil','food'),(111,62,'Mie ayam bakso',10000,1,'Mie ayam bakso - 544.jpg','1 pcs mie ayam 5 pentol kecil','food'),(112,62,'Bakso Komplit',15000,1,'Bakso Komplit - 3431.jpg','1 pcs bakso urat 1 pcs bakso telur 5 pcs bakso kecil','food'),(113,82,'nasi ayam geprek',10000,100,'nasi ayam geprek - 3837.jpg','lengkap smo nasi, ayam sambal geprek, sama lalapan ','food');
/*!40000 ALTER TABLE `tb_food` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_map`
--

DROP TABLE IF EXISTS `tb_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_map` (
  `1km` int NOT NULL,
  `2km` int NOT NULL,
  `dua_koma_tujuh_km` int NOT NULL,
  `3km` int NOT NULL,
  `tiga_setengah_km` int NOT NULL,
  `4km` int NOT NULL,
  `minimum_balance` int NOT NULL,
  `api_key_user` varchar(225) NOT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_map`
--

LOCK TABLES `tb_map` WRITE;
/*!40000 ALTER TABLE `tb_map` DISABLE KEYS */;
INSERT INTO `tb_map` VALUES (3500,5000,6000,7000,8000,9000,2000,'dzQyMzI=',1);
/*!40000 ALTER TABLE `tb_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_mitra`
--

DROP TABLE IF EXISTS `tb_mitra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_mitra` (
  `id_mitra` int NOT NULL AUTO_INCREMENT,
  `user_phone_mitra` varchar(225) NOT NULL,
  `user_email_mitra` varchar(225) NOT NULL,
  `user_password_mitra` varchar(225) NOT NULL,
  `status` enum('pending','success','deleted','cancel') NOT NULL,
  `balance_mitra` int NOT NULL,
  `fcm_token` text,
  `date_register` datetime DEFAULT NULL,
  PRIMARY KEY (`id_mitra`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_mitra`
--

LOCK TABLES `tb_mitra` WRITE;
/*!40000 ALTER TABLE `tb_mitra` DISABLE KEYS */;
INSERT INTO `tb_mitra` VALUES (49,'085758042137','monalisa.recruitment@gmail.com','$2y$10$Tkp/AKnFRnudFZYJPVyQTejDxVYnMEpZHVGUHPwQcQ1q9Xf53RQre','success',0,'fjPj_vC3R6q0cQimXqhWaI:APA91bFMmgH6_V46zfH4k-GD69NR2bYDy8dFwiAea-htAtX9n_iRNlgTpXgnqCc5Jdh9hDVeDM-dlFaTnlv06gTe-51Pd6ePKDSbYmw_UVzfWpu_lYdqbfcOYmAgjUv1Tvfb1pkNrHUR','2024-06-28 14:53:59'),(51,'082269630597','maraffi314@gmail.com','$2y$10$YWZWbL/QDtJPRZLlyY3/x.00A/mlCJ7EI9XK9ngYcghllDJSBfih2','pending',0,NULL,'2024-07-03 09:58:48'),(52,'085788034855','wulandarinova229@gmail.com','$2y$10$qtBViyiNlcr8rVBDO8.3GuHOhXqJRgJYWaXjA3ptahp3Kjv5GFij.','success',0,'cbFzI4JqQCWcuPETl9ke5v:APA91bFAy0MeqPCEpTEHmcOq_wS6QCJoU7Dmky0MYSGY9Qk3sKwrEi5eTADrbP9_EbaW4C4doPUF5-T4K65faD25gHTWuXOC_a7Tx4K16YfwvlDrh9yAX4e1YK7_nwNlSZC7i6vONTRf','2024-07-03 21:02:33'),(56,'087801751343','testermitra@gmail.com','$2y$10$FUBkMnzKZWRAiaz.AnBT3..9dcWbMoLQ0aUxhpjG9fT//lRX8CXDC','success',0,'fFAZhXt1Tvu6OO7_wfTSIV:APA91bFhLUWbq-Np7DQwIFq33LUVoMKiIFziexyHUnOCoAi0cGof1Y2dfyF7bG0jgv6PFOAx7uqg1FzysqMU8J2sAP1dqSAB8g_G9HnIFt2Ac0MWFFqajdU4kVbHz8C4WDqU4I3_RGfv','2024-07-04 22:02:24'),(59,'085319587693','nurbaity.go@gmail.com','$2y$10$1yN51ifX6f2sFtPzFgngX.sPdijh6.layc5XWRzHK.Mxr1NsyhkiS','success',0,'ffBYqGluTBenaCPJpbiRNm:APA91bEcswzgBAveJri74GWyhlF7_CmGc0_KOnp2EfI5sDHGGup09D-av6ew8SRZY27Z_Y_mXWJEpYAbyBSTfYDjxuAeMaH8ASJ3tymA7BP4Ws-dR4H61eYCJh07cfT0FaXAJrY21s92','2024-07-19 13:43:52'),(60,'082179986194','okisriwahyuni962000@gmail.com','$2y$10$I2hxto.TSVGHnwkb5.p6MOxrZ8mflfrWPpP8So0zB4akrmOK8TRcG','success',0,'es1y7HZUSWi4eNIcMHugue:APA91bEe1kN6J2GNNlCp-h2rb1zY-n_2Uic0rrOuZ2pptoqg75-YmPaV-IgCrd9YmfHbr4vuhh_jhZN_LsVqZvyoGplNrEwaPKqjBi067uosoSoaAqAxukNPfmBRjkbqYJQgTSll_lIn','2024-07-19 14:32:20'),(61,'082186352796','lmualimin57@gmail.com','$2y$10$Pcr683VtbL8NN.oh6BTHneLcM8jsAoVOvMbD1MYFLQm3lV1vzEGMa','success',0,'cHud8iAXSVK8O78jVDWG_L:APA91bGXUaEJu5XIs5WpnzevyysvFJZPZ1hl35pZBs8_cCWjyfMGutP7C65xgGt0Qa8LBiDLgDzW2E30QgfxVr0BlgSBBWyyhkdPToFs8pPXyBEhpJlKz-607pFOskBxx2FnJRBcpL9B','2024-07-19 16:00:38'),(65,'085384581691','arfiwulandari283@gmail.com','$2y$10$Tkp/AKnFRnudFZYJPVyQTejDxVYnMEpZHVGUHPwQcQ1q9Xf53RQre','success',0,'fD0D4rDwQ9OH6wM8Yr-lPb:APA91bGQQQQh3UYrIn94_gwkc03l6Grym7fOIFBmVqOTS814Qs4z5HwZZlD_BGwji6aQsQl_lGQL_Ax8v8By5VHhijCTQl33Kwk1mye-9TG6tINuacT_1jLRp3MsXfbbvtMmaz5C75fh','2024-07-19 17:48:45'),(66,'088269034267','noviyantidwi908@gmail.com','$2y$10$5CeCXpq08Jcc6eMrgzJ/4eKuUqBAEtOUm7pZlqepvniGNu9GWS31K','success',0,'dWlxX-2GTJam-GE4h1efD-:APA91bEyYyFPtY6b4URFEw7HkKH5EyeuZSJBl8pmIzd56Kj5CRX_whKTLy2tiKWtyM2CGvT6Q3CKLl1pXbWNS2wYyA2225IUm3C5oq9t7Jz6cNy6GZnSVyzZeVyLp234UKmnyv5ksTxX','2024-07-19 22:11:33'),(67,'082180394827','arinavirahman04@gmail.com','$2y$10$rQ9d7jIKhAkK0Io6I6f3VuiI9bxtUkWTT6owvMn9k2Vw3sxDtsTiK','success',0,'dq_NZmHrS_-bDD-4qUIK4Y:APA91bERF5o9VTdXT71Ll3Vpr3QoZKFEVsFGQF3wLMbmOFQJSYeghMZm3_xe9RN49cF8K1tiXqz-BOQCxX29X9H9oOdq1r9JyU72Gd8eK8W2rvWiilRwz8XPZWGdOXa-lDSLVC7g25n6','2024-07-20 10:55:14'),(68,'octaliamonika9@gmail.com','octaliamonika9@gmail.com','$2y$10$B8b9odjBYRwjKt8ebgaqWuqGowzIVk7tNSWpiMUWp2LcUcZjbUq9O','pending',0,NULL,'2024-07-20 14:17:14'),(74,'085267377490','bariareni45@gmail.com','$2y$10$cUPYbvQochJghZH4VD6p4uhYQURnz5M33kYinu97Rn72MYeCUZK82','success',0,'fgW-EVnCQjGFwT5aPtrVHu:APA91bF5rq9P_prGAA9gM-wkFiDpMPiY4b5wl450i54XT2T4UcebIV0Vl8hO8--jtLe1bU037joqa6XKyTcA9LmSQLdejYtb7x9pf0Va_TkoC0FmcaKcN3C5sRm3DhZM-dZxgrmNBFxh','2024-07-23 16:06:08'),(77,'081367593401','rizki220122@gmail.com','$2y$10$1hE0LagscS9AgLEj.GRKn.rTuhee1xnGLps7sxht1o.ybwlVhJws2','success',0,'dZXkl0FkRV-usAcRnfLvew:APA91bGBeTw4qRxEbLJY9qd1ULCNXR1m1b8h8Fdz22eN1K7j1BbDFYdmrrOBrAIWEi_tvGP5PWzH3QTO7fgULaprZ5o6MuRosyijFT7Y8ZtGU71P97GXKjYburzKz5O-agR0R19CwWj2','2024-07-23 21:41:02'),(78,'081377523373','jayantiekayana@gmail.com','$2y$10$H3SSx3694vr9rlP8GWEfdOnLZ0H57kAEKevKg.ycjXYAMj8JcIAT2','success',0,'dOyRSw7LRHmovqrlIRHtkB:APA91bGP7GWmXWNTi7iQrc34g3i8dlrkoXv5pGuextpQxr4akJxxmjlYngJJYXvrW1Vfm866F7u6Fepztf6fkY46H54Q3R0jkRhKDpVFKMs568QxO8hpZoYkfTQFX2VbyyN7h8DkVyRl','2024-07-24 09:59:09'),(79,'082380585495','hidayatiy15@gmail.com','$2y$10$YN6C9MtTREGovBNwrAHIau7f4uA5lmDJbcL.fp972mz9OiPlfElQS','success',0,'euTE-jNiQEOWJN5t7mBbKL:APA91bF_c28D0QxAzrd5h1PuAYTCqwhHhQXTew1V5NlYGPLzjTfeKKn-y0xF5RS0PfAIu_S3BUWrvGplIpMJkk_SDtmpIYWQVNZFGwMklq_M9ciRHbkyyAUbFdAPslNRDuzZyQ0t-jfs','2024-07-24 11:36:37');
/*!40000 ALTER TABLE `tb_mitra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_pengguna`
--

DROP TABLE IF EXISTS `tb_pengguna`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_pengguna` (
  `id_pengguna` int NOT NULL AUTO_INCREMENT,
  `email_pengguna` varchar(255) NOT NULL,
  `nomor_pengguna` varchar(255) NOT NULL,
  `saldo_pengguna` int NOT NULL,
  `password_pengguna` varchar(255) NOT NULL,
  `gambar_pengguna` varchar(255) NOT NULL,
  `fcm_token` varchar(255) NOT NULL,
  `nama_pengguna` varchar(255) NOT NULL,
  `is_verify` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_pengguna`),
  UNIQUE KEY `email_pengguna` (`email_pengguna`)
) ENGINE=InnoDB AUTO_INCREMENT=268 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_pengguna`
--

LOCK TABLES `tb_pengguna` WRITE;
/*!40000 ALTER TABLE `tb_pengguna` DISABLE KEYS */;
INSERT INTO `tb_pengguna` VALUES (65,'testinguser2@gmail.com','088276273301',0,'$2y$10$FUBkMnzKZWRAiaz.AnBT3..9dcWbMoLQ0aUxhpjG9fT//lRX8CXDC','rahmatullah - 2024-06-19-21:20.jpg','d5H9Wl1uQ9KdNK0TKC8Ql4:APA91bFB5fxwKFFpzhazlokARphidDOWqvjaq5Wl2ke4ABiu-qqiszhfJen-QIe-i75pH1frZMzjw_VucYNIGRCp9TPgqxt-C-o0n3hLhdXZt0nxesy0D-fee1yGskDxS_RqKqSmE26K','Natasya',1),(68,'sandimaulidika@gmail.com','085380945896',0,'$2y$10$OMuTH.FsglbXuL0oJSkvwekgntvPg3MvO.9igb6jvLQ52KM9nwegS','Sandi Maulidika - 2024-07-16-17:19.jpg','dGgOUFdmTLKUazNZnQTdIq:APA91bFfcGv5Y9Eq3R2gCrhoT1y0eRb97haTq4R4BDddYCKrxeEhqV_hBNpgi-9PFeIgpE9V7xsFj2fRu85APrhQOngABmUwsfEacmGuG6H4HnWIaWjxNi39h58jQP-Cp8Vlp7bIKRts','Sandi Maulidika',1),(72,'dzaskiamutiara@gmail.com','088276513830',0,'$2y$10$DGEBj4gGhy6RDsKBrlH2rONoMwyfLeKKhJWKlU9YXgNK5frfHAgda','Dzaskia Mutiara Fitri-2024-07-16-21:12.jpg','c69g77RsTdmGY4C9sI1vTE:APA91bG9FfpQ6Ob4_yRpVUDjJs6cHSCPojMNG8EBpTsKvBRra-IvI0RjTV_aK-ueRAiamVO1ePQU2z9nKmFIOc4xV9TdKob91Ljb6wsQzK7Mn9SvIttJqWzHF2_9yc5bx0LwwTizQRs6','Dzaskia Mutiara Fitri',1),(73,'dinargiantara12@gmail.com','085768736896',0,'$2y$10$XND/.CxZPIMVfOXuubOGqeC8Wtb14IhZsYspQl8RFIlt9h4AOXtYW','Dinar Ardi Giantara-2024-07-17-07:45.jpg','ce4r6Gn1Sz6w8ozQY3KrWo:APA91bEfSRDKICI634xW_ORHjPSz_5QgN91hmc8RE2sCO9GHYnIThMz_newrQoNvNQUeSJypDUvRCgIy9xNZSkiqlq0xrhA8ql6Mv4F73jhNooTw00ZH1V2ZIJ8yfSb5kS8kndMxjSKd','Dinar Ardi Giantara',1),(74,'nadinprabu92@gmail.com','085709854434',0,'$2y$10$IVdXzHxbXrwHkWVf/mw4Nea7D1sakL9voRADa69UkzRf5e4mrjwbq','nadin meilika-2024-07-17-09:25.jpg','dV5brfM3QGqL9jPjvp9iYB:APA91bHPWu5WmfUpy7iKRLA1cHMWtKxpLN19hbJUTD8d1d8woN3f3_tKpueHXkyr3gvowizb2eYlqQKULryJTkctTcohtvwXl0L-QT929bm8zbPHmmi_FuTzDS0OEJECWrUMg_42nbWO','nadin meilika',1),(75,'ahmadramadhon2002@gmail.com','082282495716',0,'$2y$10$PT/Sx/dZWQYou87ZKfF.EOey1O19m2BCkCsIH68mo.YBixutyccNW','Ahmad Romadhon - 2024-07-20-15:07.jpg','dVQ1YpLmQu2k5IuLMAScOE:APA91bHH89AzRo0lyC6jOrQdkExRUS2mqbpKPg8-c5jAlfMxt0ueulSkGdudIdeQBh3QOhyS1F1AsuDL8zqbXxIQu5X489B9TP9Dgu7vB8FfGHSVZIhsr353UmAy_xsPnmA-piEKm45l','Ahmad Romadhon',1),(76,'yolandanurul94@gmail.com','082186023963',0,'$2y$10$tov5VV9f8LhAtImpGmyF/.RN0oY8oPuPfV5Sd9mWnkR.Wot4O4l2K','Yolanda Nurul-2024-07-17-14:55.jpg','d4hU33A8Rc22SJOeacylLi:APA91bHcejlZEMNdQsjOVhZTAKTm12TNT6HYIuUl185Irz9hsYROaBqPwTC8OprVaaonLjlMsBguwjKXjSgMRyqkeahBqIKT5roI0-l__XtXu47DN1BSuO_YlfxEuVupUKbH5GAXXZwa','Yolanda Nurul',1),(77,'rara97362@gmail.com','082247062600',0,'$2y$10$8ndbS26o5tJPzZ9J9CpeYeN.Hrw6Uf22MNSvEB0ZC8yehH0YUAQHu','Rara-2024-07-17-15:29.jpg','fC43A0BPSTiOuCOgeHikQ6:APA91bEk5PiwxT9gYcU9MB-T50A6KNYblFgJWLMadDxzbMII4unfMFc9lmxDgBxKDup5H6tIz4W_3Ic9T1KWONEQcI_RGd2b3IZCNC8Oihzp4WLSDFKttN19NOaNKp8cEZ0INzVzgvj5','Rara',1),(78,'atmajayaarya39@gmail.com','083165901663',0,'$2y$10$j4ZyYsdnf9tcrK2bsbYsg.M5MCvseowe8yug/MJz4Q73mktg3Kxsy','ARYA ATMAJAYA-2024-07-17-18:03.jpg','e1h_7NkUSWm1tN0JLQ_j-V:APA91bGcOV2ZkCv0780GcEsu-8cmtEfBudWXQu2wDyNnb2UEyn_rqK05TBsk9GyeyQX4aC0dUkkM_pd-83cG832QychF7XsPgzDxzUetojs2p_Si5lfwLIW5_DRFfxSvMyCcxO_ISM-l','ARYA ATMAJAYA',1),(79,'jualltrivv@gmail.com','081539382045',0,'$2y$10$v380FBInL17PmlJagfdLXOnN4OmYVK/HZBfLMvd6c2/bleqKG.St.','RIZKY-2024-07-17-18:17.jpg','fX2SIkQ2S6Or0UhoozjBP6:APA91bE34Y9NDzO8BDqox2oBWEnLN1iXPF-8eTUWXOVWw0B9xwxqpYIl4REEgwlTs0cfPavO-ync4TJ7cZYFsaJzr9IvFmSWgfoMH6kMSiAiP_m-NORU2O4txPTQFjHWldU7RpybSNfB','RIZKY',1),(81,'tumbalakun20232023@gmail.com','82250691113',0,'$2y$10$OglMhGLNn/hbKWdHC347wO4ERHw4TnBrD0XWUZmZRoEUZ0RER/8dS','MIS LAN-2024-07-17-18:22.jpg','chLNrjqaQkK0z8M9ir2D6b:APA91bH_oPRk0TS7cgAVptUUQTh8_VJIQmEeoGLS1foQHxb1JV7vtQjjR23_Mg0DZI2ux4vRoSRv7RvdcXTTmoDwf7PAbppctTjuNknEXgJJNed1jFClfO4Z1jJ-0GWt5djpImf2U0P0','MIS LAN',1),(82,'trifiaagusmi@gmail.com','083809323242',0,'$2y$10$1.NKuznCGCXmVGkqntPUJe3ynRm1Az2A1lRgu1E/Vtkc93cXOlROe','fiaa-2024-07-17-19:27.jpg','d0sU-vkCToalvDEooJb656:APA91bG-gFFmFoVAdzD5_2tgWOjuJEmH4iOxoifLp3Xyryt649TL-twF7O_jP0m47uBr0oLgPngtRx6um6VzfZoHtpqGVluWTm-ukmXEv5A23LGNMLFiWpeKbih-BbxNqEHpMYZVvaST','fiaa',1),(83,'adelliad946@gmail.com','085266027648',0,'$2y$10$eqjb2RHQWuwRsZBKTrN4s.QVCA3rAuApLJgQZoL90pSzPQ1Y1HiF2','Adellia-2024-07-18-20:39.jpg','f8Yl_VP6QJOrdpB7g5Y9uq:APA91bH8elceeG7DOyhwmTm0vLcx2R8v1sey2VcBVHc6xZjIAIn1h_SH8pxWQGQFnV3kaPjc33id9SlEiFIj15Pp7IxOzHQrXpEiPuozyBS3ASuW8CqsKhS3vAYdfAywxTkkj5HTglkZ','Adellia',1),(84,'ridwantaher200206@gmail.com','85768538478',0,'$2y$10$8blhnutIkX0.ZeNAH/8tjOrzfHpHIwRxoMV8jBOQwE7oYLMKZwG1K','Ridwan Taher-2024-07-18-20:54.jpg','d419V80tRYeXnSj_D2vHG4:APA91bGTK2UPw7jDkGbvzrLwX0rLKdekWcbHDnDlqA4EozcVJDctxFv1H-cvK2o-hTJGAh68MULo99O0Eyb7WVky-4SFNks7AVe11eZtj-OEJnTqUtwJ3X2cJvqDOWlp122ccwYRxqXf','Ridwan Taher',1),(85,'safitriyuniar60@gmail.com','082278586906',0,'$2y$10$h6L64y2u1IzKvLpoYQa/0eIOxfkPV3ewQejAQN.g9L3EGMu11xvtW','Yuniar Safitri -2024-07-18-20:57.jpg','dW_GfF2VSy2vX6sawYRkIN:APA91bEJngA_TZM0bnUImBHwomr8Oyz-pbvpun6iGFqcM3V9kTmSroLbMuqIiOoFsWYJTEENy_9BFLgEF7pqyKZF8RKH3ougi74Hk-q4ybbI1lJ7jQNEUqEDGWvF3rc60tMwK_kvvSGA','Yuniar Safitri ',1),(86,'fajariansyahragil@gmail.com','085788867559',0,'$2y$10$1oWVZv204S1HRpYj/KljuuND3Xd38Tux6Q.P3ZJsRF6DMYr2Lct4G','Ragil Fajariansyah-2024-07-18-23:17.jpg','co1C-7J-R3e0wx87GL5WMS:APA91bEZrHzyk8uqJF3MSLz6uXqI4yGIjsfLpzbWGrTW-YpvUWgMSsfF7sAEYWZKElaTwatcAf2S_kL5lz1TAZ8gqi-k_OydQNFMDH7c9kCDYFjewaWsy89Z_J--BMwJ0nWP6izUxf-x','Ragil Fajariansyah',1),(88,'niaanggraeni900@gmail.com','081367430801',0,'$2y$10$YxnZ/11LklPwFTTy869KA.aozQHaazuvyLXzp5rgVWHxbBqUk2CJm','nia anggraeni - 2024-07-19-01:37.jpg','dat59tqQTP2FX0C8s6GQaD:APA91bF_XTNTeDpJukfWdjoTqfWNjAooUnMdZk1b0NKl9RB1mXfV5HZNPmMh0X9bpJuYr0RqCxKFrRfGFZ4yGBE2TaXrD3TZL6uhh6H1Y9DPFdrDOMs9Ml_QK9wM5wbkZLZx5taralEy','nia anggraeni',1),(90,'deddysumarno4@gmail.com','089635807370',0,'$2y$10$xjJmauVWRi1vQzZdwKI1xuEFm65To707rTf1wZ/45N.KcInEbYpbi','deddy-2024-07-19-12:00.jpg','fjfKinOIQZWvnhEHx6mNVF:APA91bEjLKgW7GgS4n6ZBAe3hYzniEjuPRJ_RAyTgbwfO4h0LVm71YQ2AOZhldBVyVYc9XVw4Qyb7Pum-SraONKyjiAoHCI2MWxm9CLHyK7C6siLjcNo7WcqyMLZeG14sUBeKOMllweq','deddy',1),(91,'permonofamily@gmail.com','082269636020',0,'$2y$10$tgYSP8NhrLH4c46sgxjVve7VzcIcTWdgTKuGze5QaTQgcaMSOGYe2','Ozy-2024-07-19-15:36.jpg','fNufZrAET5apCOxhLKR2zu:APA91bHxwAA7JUuU5YQFMlqTqOZyXfGEER7FriFXOPRCMBBu8Zh8mO0ijFN0U6XSju9uC_ufH-tRpO8S-oRBZbHf1CE83f-je9bBWuQLFZkMgK8VssfR05ft-ZFA6Wwr2Fn5bCYpUF56','Ozy',1),(93,'maharandisepta@gmail.com','088286616930',0,'$2y$10$oYxr8J8NRdUChwcqCv6v6.Nv8nO1gTvZECJS5694nbN8FARbPunVe','SEPTA MAHARANDI-2024-07-19-22:51.jpg','c9poXWVKQXmedV2kEZIMVP:APA91bGYewwdgTFlzDVYBDh2axXDwMsC-tzJ-dI2_SgGo7Eji9TkosfmDpH_tGsagmcoKGMrEQ4lRruBxrC-a--IPito-FiSagZtNkM0n3NxnThxpJEptzkPgaune014ZZNNF8yockQ_','SEPTA MAHARANDI',1),(94,'dedhysupardi15@gmail.com','082279295978',0,'$2y$10$RYrS/x4XVSQ7st4RZxd3WuStFndT9E7XYBS6TQXyRSoMohEpaHVka','dedy supardi-2024-07-19-22:58.jpg','dUHqQNxES_C1cD5sLAfm4m:APA91bGu5yeF6ai8RkSqEnjL6LifyG7aAETd3lOuo8dVJOAQPprXWTvFYZxJUYZPZM9reyH20AHLGg7UXEQ7noTyg_q1M4rOmQXmqb7kizezmfJN0VgzNL7PK_2v36QsG-bHNRj3ykel','dedy s',1),(95,'088276001877h@gmail.com','085700847199',0,'$2y$10$qXAxO9QNRv4JrGb8Tgceou4tKmIzs6.wLd5XhCRK/SwGX3EcEQkvK','Muhammad Hidayat Ilham-2024-07-19-23:09.jpg','fhp6YOtMTci_c4WiTohnGL:APA91bFwYFO15iAq8fJ_OjvKpqYVgaYCvakG9HCWXzU9PHJvzRCWCDFTa7Ktda6nHFmG7u-8mlFPOTAXBdHy0GgpiwxaJCGM4inZ4F2IKWUHfzQUSwh48n584bIYxQKtPAne5i-97kLR','Muhammad Hidayat Ilham',1),(96,'mutiaraajeng63@gmail.com','088274205697',0,'$2y$10$P7iNkmD5eCGJ5gqqB0vJfuBJg8TZ6HtdOxEsYrLrqG71w8Z72MLX2','mutiara ajeng -2024-07-20-21:51.jpg','cjcl5AN5TXybLEkuvK-vZe:APA91bFy6vQ_4wFy0l6x3rxGt70vcdB_NxsaRfBNkF9u9h27fjp7yuw8wTQfukCVUiEQkjyzGZHvT_ScTqBkgbBm6DL6YiOkP7TkyDaiMVDsofeFlZF_ZdT6ARR0kR40VxSl9NmH37sy','mutiara ajeng ',1),(97,'wajihannazifah25@gmail.com','081532959796',0,'$2y$10$Bzh6L0kiPy4FQpt3blS2ZevtMDMS/XHhoGY0M.hTX3D8fXX7lb9V.','ZIFA-2024-07-20-21:54.jpg','e86b7qzYTESMihuz1YgRm7:APA91bExJ2xSTJEoHPAbxa4BJHvGhL-YDi_sT9908r0_k05Xt7A8fQ6ZqEv8nZspg52_NTguf6r6rxvhKzhdJ9_Tr77EUfqd7YPEIMpPTHRA7eH-SIrjUlpumDId21Mdeq5jnbb2g_VW','ZIFA',1),(99,'parhan0208@gmail.com','083844788865',0,'$2y$10$rJoJo5D2I/eUHABSSS1.EO3aHAa4vS/xHQJtD8CLIjiLLNrAcUBoy','parhan jago-2024-07-21-20:48.jpg','foR3VA55QDyX7Wto8A-PN-:APA91bEEAOE2CLhTGX1cdE5jvvV0E6oP4GF1ArlM9hMfVVVFrFBObdzlEmDlmpS9UrN2UdAjNC9W3pxQkBAIyDZX58tMj70FZBFSIT20iSGoFyM6YznfNweDf7ycx2YPBb5ec8s4fhxI','parhan jago',1),(100,'ddirly05@gmail.com','082281294601',0,'$2y$10$XPdW827xzGpfv5s.e0KbmeQ6doM6tYmJ7nuzAENeGUVcwyRltmR/e','Dirly Dwi ananda-2024-07-21-20:51.jpg','fXwdTWj7QHGYKN5Vnt6zio:APA91bEaRkxDVNT53ZXmxXbnEpxckmudm3pUildNzUebdNntmzv3OAfZQ8T0UMmJPeb15UZyWe77-J2j-Ptv68p5YutHw9KZ6wEdHiaiJg-7Zkuodq_kx_mLjtmhXEV2W0d3T8oVigvU','Dirly Dwi ananda',1),(101,'refangga20020913@gmail.com','085179620902',0,'$2y$10$9/HRQhmofFdwY3cCojid.ePrAp2sdZDZUcruPig6bJKUrvjz8Gtou','zaho-2024-07-22-09:03.jpg','fRp5S998Qtim1g8dCyeJTZ:APA91bGFlFsOhANtDHdW_wcnWqQ4QcgbeEP41uFasVjdQP27FujdmBlyDrKMXBajniTi4tlNenerl56sWGknXG4yl1nivJxDOc5SfrpHeM1VampRWldvaElRRyezu8qZVLqc9sSrX1-_','angga',1),(102,'danuartiyo@gmail.com','085279235854',0,'$2y$10$LZKEAaZIporEcASpno5qJO/ALuzwRENfOh32ew4ws782MQArahMju','danu-2024-07-22-09:03.jpg','erBiM-QeQkeobbcDJPH6l4:APA91bGkJT9Y9pITHdyfbLfPzCfdMuK-bjerzi-U5NN3WB_-MKUAVZuGSYvR1DNIZnbGvPSIU5nbJLF0e_qFywcn3BeV0CsJ4Hss913p0QRxKW3Sk0QpZN9IbycnXR_ZsUshNdFcijqk','danu',1),(103,'mudamuda2503@gmail.com','085789458563',0,'$2y$10$1oluRS3WbogbjPMPDZKtX.oip/94BDZj4wf5/kCB5..fu6JE3jGIm','Nabil -2024-07-22-11:06.jpg','cv4gbRQlRTe0WBoJH7QXxB:APA91bHj2CIY3s9ps8KSy95rUDltFTva6otk19N_5ESOvI1IEeAayP1CPSPW7R8ZRSmsi5d7Mr5BbZfFKskvgqtopyiAYlcmNLLosBqOuZIp3-ttV5kkTi4ME5riQL4-Xv0-Ddk9iLtr','Nabil ',1),(104,'agungbang008@gmail.com','085382500572',0,'$2y$10$Q/SGTOXdl.lYzigjkYM8PeAm/BMq5/oxoAzvw0WcncTl8P7v4gn.a','Agung Setiawan -2024-07-22-15:35.jpg','eyccYeSSTKCpjxB0p5HWry:APA91bG8qBwg7BT3Zfe-F48j3n8Mnt7Hv3yBiFMzXhXTGLxFb7gl-x9J6k86iKv3dRRwUrsfMl_11Ye0OjPKNGW_Y8CXjLi1ZaKDl5xMT40UiDiceEgVM-djZSYfZuHiuZAVOb_LacrI','Agung Setiawan ',1),(106,'rachmadfauzan106@gmail.com','082180758647',0,'$2y$10$uKUsjRorzCUaeyyjTdiXAeir4cQ7MmH5QM8daXDtCtJpDoNS6qI1m','Fauzan-2024-07-22-16:04.jpg','eBSRwxV8RC2b2X_k9IhBu1:APA91bGjm7KX59jHXvI9ox3kSom6TU6tyhd9udIoWjwj_EFAd9ajfUAiH1jpLhVkrZWA-T6vpBw4kzx9Xv8SMLjAYLyKf48EryOb8hsCtJOKerhG4RNE0ZAsE0dW1-oMLirCBfjcCI_z','Fauzan',1),(107,'miko28872@gmail.com','083169894995',0,'$2y$10$GVYWzwJUqQNdtud3EgrcMuMxYZMRxVIB3gbUgc3obgVMhRGkrdFUO','Kurnadi-2024-07-22-20:18.jpg','ezPYRbpSS8qG5-hjH800DC:APA91bHFdmIQ_Tagrff_gX3WCy5lgNyRT3xYtPBLflOUaX2zkeFyS-b8k4B3pD_lMzHRXZNUYWdGliw0i80lED_OeKnCyIeHDhJ4SbCJZ4NneMcEB_IhYXZLEZS_uGt9iHXlxQGoqD39','Kurnadi',1),(108,'nandozia87@gmail.com','085267445323',0,'$2y$10$dhO34u.16PqPVSbUfVVTZO0kZRzmXFLpKHA9iygbwk2AVvHKmjxiy','Epo nasri -2024-07-22-21:01.jpg','d8KFG96pQxKv3wNwdorEuT:APA91bHeZraw9p-v6G6aYkvGA1xOwRLMkrh046MzImPtvn7I2Q0UgtnCnQ_iaeWRF7iVB0CESk_rIDFycc1_5g8ab4ZXuhZY281gexSrOmFgy5pkxdfCwZn1WXkemz0_4WIo90xF6VTF','Epo nasri ',1),(109,'syabanhaidarali9@gmail.com','087845122590',0,'$2y$10$D1vu/XGjAilxdVyUBpoEVOmbxpaMpDZPIIjvYgOBWon54mF5osm1u','syaban -2024-07-23-05:57.jpg','dnin4L0hQ4GRhp7I6hAEoY:APA91bGFldQTZjeirMK-KFi4mbxyLsNohXRoRXwVvbD7bHEPjyVqo1DA9TVOB7LmSgj9kDmwHu-C15E6N50CKcwrlewtuJU6K9tmJlmW_MlAXDXcn7pS-eaU5h8tU1HWFj5yW1JlRDys','syaban ',1),(111,'rezipranata65@gmail.com','083844383343',0,'$2y$10$u5waTnPSPv/yUCyVjomeue3/z4Iw06XeXPqYgK.mmdnExNYIJ9fCW','rezi-2024-07-23-08:29.jpg','cHfIjaBqQbmetNXAWj0T7v:APA91bGrq6ypO2hTtj8AZ5I_9w0tlnRR2tAVMF2yJbi-OUnYQGGXu6LXE9pW17pvj7Dx3PFYu26ZGoJXxqjCVZ87kxvN1piqzczVLI108dqFOjM-4x_hjWMAOIlansZn4NFt7UiV3mES','rezi',1),(112,'mdianursajake@gmail.com','085718740554',0,'$2y$10$.ke4xzqIlnWezrJlLnHevOyvVcRS9tl7IOUGelprfIiSEcbD6wOpW','muhamad dianur -2024-07-23-12:23.jpg','dDlvCIKQQG2kTwhYClo09O:APA91bGSBKI-wMj5pBIiXtjesh189vk35_hXgBZG2AQ-mcvIbfPZ-p1L5wDPvwZQP2E5PIEZgRi0Sezpr39EQS6jKT0FZasY0CtCtT6XUnMINbMupImxhLPBB8lYFLgff6NOuTiMWRSJ','muhamad dianur ',1),(113,'mdianursaja@gmail.com','083831615400',0,'$2y$10$gRvy7.CwnZJkpy2kdUpG8u8EjAWaNOalq4LHVes5/snUBzFwtWXHK','muhamad dianur -2024-07-23-12:25.jpg','dDlvCIKQQG2kTwhYClo09O:APA91bGSBKI-wMj5pBIiXtjesh189vk35_hXgBZG2AQ-mcvIbfPZ-p1L5wDPvwZQP2E5PIEZgRi0Sezpr39EQS6jKT0FZasY0CtCtT6XUnMINbMupImxhLPBB8lYFLgff6NOuTiMWRSJ','muhamad dianur ',1),(114,'hanifmaqilhafizhan131020@gmail.com','083157982546',0,'$2y$10$GXIJX.Rl3wbUrh7wT9Rru.AlvT0B.r3C85Nfo7v/vHraoXacKg/De','vinda sepliwanti-2024-07-23-16:02.jpg','fW5U163RQtmwFiJcoUtx1Q:APA91bH8VCT_tItzixFq7TGaqLioKGEnkaTSLwDey8E4j0OrqhyB_0rrwFRmm7gt42ye1IJ775IDa8baPyxWeFmtL4ezxEqRF9jj2RNXy9PBF18sl4-QnoWcV3Bbb4ndmvbaykDhy4H-','vinda sepliwanti',1),(115,'tiaranabila529@gmail.com','083802120980',0,'$2y$10$hi5AA/WL.ww22yMd.Jv11.54hG/zQah2KJDSXxYObU8ZvqOJvjG7K','nabila tiara-2024-07-23-16:03.jpg','e315UZ8UQpCGkYSsgZLwu-:APA91bGzxmlyTQKE99t0MHsFVuky2UHzipoANWvKc0Oke-lM4rlQk2BG2JVkPR4BZbniorkJdXGD_J2ckFoDFitiQV0Xj8OWYBUzuo8Y753IZ85T9wiExnnx1G8VDzCM5jThmkDp3LPo','nabila tiara',1),(116,'lusipurwanti49@gmail.com','082371512520',0,'$2y$10$IyFUd2vnMvRX2Oo/b7DNY.MYTbMWCNULm2M.BFseuT.rfboz3JsNy','LUSI PURWANTI-2024-07-23-16:03.jpg','dTy-8lM4TJumHWaZsUmaSQ:APA91bGvlfLL4rfbjGR_Ltw2rGsv5Qor9fJjqr6CjyHlfob_0YVME9MLAT_zn8ZwFUp0vVPOEbc-yHqodiT_U6jQeYh9iWsDq1UcybDrevA0gDRMTq1P3eK06YKwHlnG_O5cCKnMyv9t','LUSI PURWANTI',1),(117,'putriapriyanti005@gmail.com','88276524237',0,'$2y$10$.gegpNdmMir0iiGKmNkkx.qimDPYnFgzCwVgqzSFiaVS6cZE7Qv2G','putri aprianti1996-2024-07-23-16:13.jpg','cVQlruNrTaSsYyzCELyaih:APA91bGPEXAclt_NPcq6hGbJaXRIfErlkbYhmEqPF221ftXUcWy6S_MXVlhRXRbcWO5m0sniIlgqYtG4uy7MjnUVYBg_H3xBOddsIqJb1CAYF7lKmV6xUcAZJHadKp-kw1j9FskFhTKx','putri aprianti1996',1),(118,'dwinndaaa@gmail.com','085357528713',0,'$2y$10$6Pfbxv8DMAbtuxTbM0mFeORL8jm/262xxcXt51oLw2QvEZhA/6L36','Umi D Ananda - 2024-07-23-21:58.jpg','dh0urgYrRFqrieso1I1UJc:APA91bG8oE6k3k6TL7Kvf4emy97Iu1983fvnPSSbFnHz5O7sxvUNpFjhW2Cgdbe-FLNDwfmixjIVKeMnw401Zok44BnEYlK9_il_qw_Fz-INlkJppUTf2p2sL8gjw6ppsxz4KvP2CgIi','Umi D Ananda',1),(119,'intanvm055@gmail.com','088269177621',0,'$2y$10$Y0osoLRF2WG1d6MpC2xlquqQ15Jkxw0aTqK7BTcF9dBMoiWpGViie','intan -2024-07-23-22:34.jpg','cGgNMNhPQmi4MTI3SofuMw:APA91bEk_AFFk7NmfUoKzLWMDpuV_p8TZPNcET93i_8zxoVqQK5uS9K2zVSn10_-CSdIn89m36kyNeyCct8Ez-ZOscrgW6boaw57-js3bVVNeKcZro_KA-Hl7ReIFFph0xBFEK3r1rgp','intan ',1),(120,'shintadwikurniati01@gmail.com','081996002501',0,'$2y$10$T2Pl6FuVjiyJGwF9XQRUtOx0RRwohXamKjWvM1U7felbuECbXs6TO','shinta dwi kurniati-2024-07-23-22:34.jpg','fkTEwiZ8SGGzCBo2jZcchj:APA91bHhgbAhD8Xt8i5Qill6eXezZDZXdeEoOnYg6mmdgEbMNWcQ4vQg8IxdLEL7YUfUzVRnTt6cDKM9IVbnBPyuz3vqIQhROSAFsZ11sliI2a8YaBQQDAIayCnH-zlnxn5y6F0YsODx','shinta dwi kurniati',1),(121,'intanviolinm@gmail.com','083177209502',0,'$2y$10$WMVJNDOPQJ91SVuEp9PeRemrnxH24QPjDt3PKMESzjKlpkARmg5G2','intan -2024-07-23-22:35.jpg','cGgNMNhPQmi4MTI3SofuMw:APA91bEk_AFFk7NmfUoKzLWMDpuV_p8TZPNcET93i_8zxoVqQK5uS9K2zVSn10_-CSdIn89m36kyNeyCct8Ez-ZOscrgW6boaw57-js3bVVNeKcZro_KA-Hl7ReIFFph0xBFEK3r1rgp','intan ',1),(122,'yolandamarlina55@gmail.com','085658817011',0,'$2y$10$iYuXkELPhPcNedcco59VoOIqVPTVZBMGktDlAUrqsv./41eHQiAve','lyly-2024-07-23-23:07.jpg','d1ec2JNUSEqrdDUwmyHT2R:APA91bGNxvypYtCrDNHfENh43t5a3LMhymxv5dKUtOenN-yWFukXnV_NhfrdfexuYa5_jX56x0CAWIXT-5GiciqwrTyOmelx22Hxfz58-5x7Q1RjbfpCyoknO2obvSyy7VeFGubQVQy4','lyly',1),(123,'fentimonica99@gmail.com','085709681799',0,'$2y$10$jliwpeEIj4RNA0g5ZMzCW.scR3tYRBl1GOk0SjyjLDXw8cd7aEKyy','Monic-2024-07-24-06:19.jpg','cjnj8lO2RnGhNgHsA0b2YH:APA91bG1_P2No0dQmC8A5nfqAjinrmOsEcJz0qRGe_VZ-yv1kdAPp2jmn-gDp4opMUrHRyCtUQkxybKWHwYDhXJsxu31y5kN8LzK1egY6oPq9-27BG-lJQF5w5ncrTp2CSbyNi1Uar6o','Monic',1),(124,'noviaardila11@gmail.com','085217307722',0,'$2y$10$1lZhmcJ3miFrOTYNGn3zkOvKwknwOKlbZVj4EkD51eVKaEA8VE4w6','Novia Ardila-2024-07-24-06:36.jpg','fQkHfo7ATW-3gmEA28BeUY:APA91bHhYvAZ36CfJ_BU839siAitt-ApVycIJIja1UdmIIzjNTI5dMzInQrfOjnHpL8qXJXa_EVhzi6TXmOHdTixbdanG8Z0eUfHg-X4rejd6T0nx4Qaoi8Fv37vjZvuCMzoI-si1PvI','Novia Ardila',0),(125,'mellyagstn30@gmail.com','085378315900',0,'$2y$10$/mqMevvh5EHB1hVzR0VgAe7BOp5Sh6tROadkRHWYCPr4AjQCRw5Gi','Melly Agustina-2024-07-24-06:46.jpg','dFDWGYSfRHOsTEps6-WDC4:APA91bEtCXX960bSbB_AXolE00CArbOPM5YYfmrTl52V3VfGnqA2Yu7TWUiGfYqaNDM_9DIeZCMrsFP3AJIPm9jg8u9DJ6ED90eneo0EnrPPIikWCnFlE039137A6zmz5ae383ypglPC','Melly Agustina',1),(126,'anitarahma2626@gmail.com','081373220725',0,'$2y$10$DY4Nk5sCC9m9lz66x7IGV.ub/dlXtRD..jTHC2X5MlQcNQIQLgvw.','Anita Rahma-2024-07-24-06:52.jpg','frx8xmFbSjWH8bWnKynqPI:APA91bFFlwke2dZykGTgbMdszZHpw2VjfB86awyPoxiPh1dvvcsJThfPi-Dx2jRIXElDapapinES4EHAIp14f2tKg8GXLZ5Jn3oby_ZzadPDV06t7S9YMpWwAz4fEhxscTgKNUIemjnm','Anita Rahma',1),(127,'nadiahkristina@gmail.com','081274222554',0,'$2y$10$n96csJAmjHBFyuPIkq5pMeJv08kpeUPuaejam4qyGcpjnuD2hWqfK','nadia-2024-07-24-06:53.jpg','dQ8xW5n1TSqT6Kx-M5B2q5:APA91bFftY7KGVp1vXsu7id1_ay3zmsOQSy3UxCT2_YgsgfGPKBogl2XtvjHBJFCKuB7mu9M9KsCf0QNswDaPs4t2XdjA6YmKUX5MQQfuNMnKomiraij9GzF_f_4x6ZiqKuhHDbONTX9','nadia',1),(128,'indryokta3012@gmail.com','085242311704',0,'$2y$10$p8TLMmZ8OML5cIVIJUHOE.y8m2g6NNwFs1.BbWvO8aem1ujIkxslG','indry octa saputry-2024-07-24-07:33.jpg','dY1DmywTT4GarPwTw_o7_I:APA91bF1y88FcjsFPdzFBYLwGInhBUWgYeXVlgQhjtgWQvzMvThflEZuLUeuO03HZR1FJrvWbR150zzb04rrOk1KE3PBqyl-zjcNM0GJ50z9RsHTmQ63FXH6XzmFRh5pfGbNSdBSzoLE','indry octa saputry',1),(129,'wahyuananda503@gmail.com','083173738324',0,'$2y$10$OCnSiazzuPNjszmOMMh7CueLmhSiUTddghQh/Vcpf1hYnQctwym0C','wahyu-2024-07-24-07:55.jpg','eNW939KzQiyeLnt7haRdSb:APA91bFcF0xtI-ta9dRQN-gvmdtILjVDItOhD2iN4XmhG016kaJMQsZw52uDyqdLORY7gRlwwJnyDnHGz8oNu7cSgBOH6mNJJ085vSCysnIl-9UMiD6djDn-2vnvczccfDNth-AbQ5sj','wahyu',1),(130,'semendesattra@gmail.com','85380707187',0,'$2y$10$2EF5XFxpSlAnOKU5Y97nwuhCyOFXG0nZUPuXSerr/mF4qZzm.PQbO','Sattra-2024-07-24-08:23.jpg','cFugBt3YRruyyMMIOj-ZLG:APA91bHKjtQSyBUGvZ5_NBePfY8U8adyg8_y6NsURjlVAO9mEaHU_3jQ1WEpqX8es7uP-0VDfSlSJMM0WXETZ51DsSlgJiLd8H1637YHEi_9NFevi7VSvq1o8y-pl1sl8Xv7DVY6I8sm','Sattra',1),(131,'ikchapalupy@gmail.com','085711152607',0,'$2y$10$RC.SJy0eqcisqcAKOg.C6uFxt68lD3LbrT7eHkmJQ0EN8goQCDedW','ikha PJ -2024-07-24-08:58.jpg','fj8ZKkg7TpqzOJ93YhLCNY:APA91bE5DR4aHs3nYmcuNIEySVpqlUEtbWSRE41RUK5f51FmNP3LZaeLKKduJpg1ycOsp85k8cnzLBbV0r6jAxE3JYMJxLHHJQcoPCYxrp6BBwjZYTTYQPSynvtFRH4LVAG31rS0qe9T','ikha PJ ',0),(132,'ikapalupy66@gmail.com','083176098287',0,'$2y$10$heEb4uolCjrLYEAYln9ZdeWXk02N1DwNibYoYXsblxysuaHsl0m9a','Ika Palupy-2024-07-24-09:06.jpg','fj8ZKkg7TpqzOJ93YhLCNY:APA91bE5DR4aHs3nYmcuNIEySVpqlUEtbWSRE41RUK5f51FmNP3LZaeLKKduJpg1ycOsp85k8cnzLBbV0r6jAxE3JYMJxLHHJQcoPCYxrp6BBwjZYTTYQPSynvtFRH4LVAG31rS0qe9T','Ika Palupy',1),(133,'f12jrbal05@gmail.com','081297900480',0,'$2y$10$g0pRASVFac3vc7QvonEwo.Dy2VH8/Iox6DcV8vra5GZYqmArXchZK','JrbalXx-2024-07-24-09:06.jpg','el2lI9pITVSfmPy68tJpwn:APA91bH6frjaWyVENWy7-hreuXGeHHMx53854apsAxdHLSPH-zXuEnsQi2KXtGkOR_KSHJV-bO1BqZwUOmvyIsVCfPSSC7juxsfnCeKfUvC5qHuTyTFCbJKVro5yN_SUNV9yMJ9FoZSD','JrbalXx',1),(134,'andrepice83@gmail.com','085758722141',0,'$2y$10$epjXjo1qZ007lVAIPv/jNOfcSrwqo0fmGgU5vlK/.OFz7p1T14U4i','andre-2024-07-24-09:18.jpg','flmzO1BzTgGXX3L1ckZwXQ:APA91bFosA6H05Sbm_sUeynEhrY-BF_mrRLJMgrlGdGg9WLJInOWo4IGFKVgcCUJg8-jPMmdl9N4OVMwnlJYwbg-nJKvZi87A6xnINObE2P07x9M43MXXMDcKjN5K7067QH_FrslH34B','andre',1),(135,'naylafitri84@gmail.com','082311450736',0,'$2y$10$m/1m679MODTrO8EG8xHHzu3vWUyrR3iqDXcCpTLzJymBGpvDlw.eW','Nayla -2024-07-24-09:23.jpg','dU2MSWL-RVaSj2-pUcMmFQ:APA91bFByn_X2iKrUmJdCp5At6npZWDpXxnxEF_ZAIIiJK2EB-EiCq3b693HT9gV9UXeXNlHnI1wkPd23wcuPWMXtNOFrSFl5D0DkTAeFsSCZk3EHzZ0mPzF0rDJvTFCoGZisW4RqzRL','Nayla ',1),(136,'zaheraera53@gmail.com','085368179396',0,'$2y$10$U5EqdMQa1AB0Qa4iIV.ReuadGm.OY3FVvMxag1L5gBwkovrWEsmMi','zahera-2024-07-24-09:28.jpg','fc9-vWT6SwSc6TXD3K_MXo:APA91bFr4rz44qoYSJIftjKBR7cC8S1vPeziqW-eGwrWEVExUj11PhUy92Lwzgb7SkBHyKQVNpasecLHgRhTNUJxHCnSAcMok3gO1yyomWoer9A_LalYg3iBSJzJWy3m6tLHvKRyGWCY','zahera',1),(137,'afitalfiqisyahputra@gmail.com','081377755056',0,'$2y$10$CWNh1dGcriPY84Ro69ONkuE/RrDmYTJPbsLmP/MZK4a/HKMhpwy5m','fikii-2024-07-24-09:29.jpg','eUCsPz8CQjWq4nWXVZs1fK:APA91bHsIc-0zKF-OM1BiXSe49ehXehfiA2VftT78Q4leqzZOHSSbWwzpt3Gwa-hrnxEfAfNXd6Jv-l-0TLT0cV6k_5uJankFrRxM-wwTONsVaQo-omXF-qam15e5NOmlnECaw1EkMVZ','fikii',1),(138,'zarkiazarkia4@gmail.com','085783496113',0,'$2y$10$TKGTkHQGZKLi2fkeVSfCc.t14vDiyAb3LPhtgGrUJpiPiE1o75EnC','kia-2024-07-24-09:30.jpg','cqHoaO7wTe-ky9cDqeZmOZ:APA91bG2vYAAhqOUagHPSAmTaHTb81bEHh41-yptg_FcsYWzlBRKUU2p8CcMR0-xWxLU535JbtxMsrpawzLATi2S_CTUcR1fXoXDcsXPRahV1wPeVjHoTtaiz-EpceGE2ZdotM2OkXaY','kia',1),(139,'ahmadapril76651@gmail.com','083116408558',0,'$2y$10$e9SdNaVOFysPvt.yaHmNn.G0Yqw/Z5yZl.CvfRP0p9DhbeuSjHp62','Ahmad April-2024-07-24-09:31.jpg','f_zjYJ-ySAuYlERX7GdOdu:APA91bGxcCl9L3WE16S6P5jfI14ek8af6EkBwKSfSQ9KtkCerjKQMgXYA48dJaYIacpYfbGxipOPnavOo31c9J2l-pEKGLY1uCXjt2ggCD_OHu38gbQKDjhLyoqAqv-cBRQQbtcbpjAU','Ahmad April',1),(140,'irialdinata@gmail.com','085789797736',0,'$2y$10$0iRkpx3mGdEmRskAxpRb4eOQfBcWL4VxHLcL.KvYtXCp5XG7i8kza','irsyat azizi-2024-07-24-09:32.jpg','cudaCRqxTFuUUU0aVlRwhO:APA91bHxnmhRTqlSUr1d4ITPB6sJagFTeAckEaVcu9LD7JX-p6q8aksFxfklyEZxUQBJrAaDPc_n_PRFdkvbf3KNaF8fIlMJPV3CUH4_KJP7pBUa3Cb47fKWPSZXrsIVCKv_HOnq8j-b','irsyat azizi',1),(141,'albacahyadi@gmail.com','082213092419',0,'$2y$10$CoLzTPNNJ43zlvV1azvc0e6NJvA//ZrLqEdWBPOfpZtCnDKDZ8fVS','alba-2024-07-24-09:32.jpg','e5mWADY9TKWSrT8niQMgqt:APA91bHkDN1h_VwyN86eu-K6LhQgilameSWVPwY9aQmRq5J4aPJIjwxZ4veq-07UC4UE8MstfOkshyZ76NyoeWQh-tCsJc2WZvWXaa4rPH2KMPbbYudsUj4HivbkwZCYs3_Y_LBBhlra','alba',1),(142,'dianaanjeni42@gmail.com','082246043806',0,'$2y$10$aXn4SzNiJdFa615GLdTtKeGB0XfWTPCQD6xcoj/bUkVdcCg5zk59u','Diana-2024-07-24-09:33.jpg','dThlqvdBQYGuWvvuru5dYx:APA91bHOMGgkntS9kPzWCdTlr9ZtQ71PXzOsH0re7NMAF2aohr025cv5TUuZsMzZybH80b-532JA8rxW5KOnIVzbVG1jSjPXrEyWS1UNKRgqQHH_cxiK1AOiGvdxANR2kycvyThWk0E_','Diana',0),(143,'abellherman44@gmail.com','081360987656',0,'$2y$10$Vwwll0M/joiGPwohEnwbM.UoGtl.VIV8oV2TQTDXX4GdU4WDG4.Eq','Abell Herman-2024-07-24-09:34.jpg','cTeQkqpURmuDGefSgL_Ovk:APA91bGpKb4Xm3n8rlyjSqm-egZvR4THus8XeCTkPEK5tqOtcOw9-VAqOEdaCDWUvxF6Sy0XjEYacHHLbZJNiKot4AMzKHAsEnmSlrpPZmFRBDt5gpv3MR2Cpzz0wqg20veR_o4v4LHv','Abell Herman',1),(144,'windaapri952@gmail.com','082246073806',0,'$2y$10$a7piW6afAKbBR390iNdGse1yI32duClGqWID67RrBlfXNSefNEkp6','Diana-2024-07-24-09:34.jpg','dThlqvdBQYGuWvvuru5dYx:APA91bHOMGgkntS9kPzWCdTlr9ZtQ71PXzOsH0re7NMAF2aohr025cv5TUuZsMzZybH80b-532JA8rxW5KOnIVzbVG1jSjPXrEyWS1UNKRgqQHH_cxiK1AOiGvdxANR2kycvyThWk0E_','Diana',1),(145,'hafizpadil8@gmail.com','085874070523',0,'$2y$10$EUbgO0MStvN.W5pFXMpBN.MITjA/mzsrudQr2grh3xYOWzUAUXO5K','Fadil-2024-07-24-09:35.jpg','f9NQ5iepTwSDm8aZPRuse_:APA91bE2QVvTFfsZ2Cvmne-w2HvkxilrZwiiIABZsc7cm5m25CbIDJ86wPEPUxy61cxJylTv3zuTle4jJOol8LQh0en96ZtLLIIP5xqGhScSSdalBBgKONLsL3YH3wHJFkYQY3pZCwGS','Fadil',1),(146,'ahsanomen@gmail.com','082181005191',0,'$2y$10$kPHpoGAg3R3kXP15s4q4bu5BFofSWTwdySJcergagyxuwntM3Ls8e','Adhe Rifky-2024-07-24-09:37.jpg','efhuRBBfR8GeWduYc6Bxwy:APA91bGmePbd7ITXW1HLSNv1ih0YzqNqVXpIDqzSj07wKTQYLI5i7gDmHj8krlOGSTb0Xhi00riJPzn9UUY-vACu8S8pRyaD-Ka4fpkzm3-FioUaXfraaEPl0C5liGsGLd7ETVbaVuOk','Adhe Rifky',0),(147,'dendrioktriyansaputra@gmail.com','085369643360',0,'$2y$10$M265IHsIR7cmpe4QqrP.BuPWFPxev3uU0WeNmNan6PM0/tky09Sz6','Dendry Oktriyan -2024-07-24-09:38.jpg','dBBzb-e3Tl2nqHtLoFs0Zp:APA91bG7GeHzPZjWh-STEiqDuKFUBP2QOVEdThpb1hmOm_JzYA39kXILonYUXcBIpvYDnorUIHZ0_pA2Bmb2Kp1siNoFfdbfxC8ifNGt18leAmfTjurhOxLS-dZjxLI7ZaXGYS2UGPUu','Dendry Oktriyan ',1),(148,'indahanggraini999@gmail.com','088274238961',0,'$2y$10$g6RCCAZtqD0U/Epqy.SnvevJObWaHjlaeQIg.Z1RD7UVsJjlAzOlC','Indah Angraini-2024-07-24-09:38.jpg','f9REFefdRyC_D6TDVC_Qpp:APA91bGLxGae2O2lo_M9-H2DFhsVWSrMJ-vuAg9sFGHUpj3oJzUGpgoipLWSH6MwbY4EoOeFeqvQg6aDtsj30nR6453pT_550b4sb9QDd49QztOHtkiDRYk7eUR7plobEKvZw6Da63OB','Indah Angraini',1),(149,'pikakomalasari17@gmail.com','082269731805',0,'$2y$10$WgxAuL5syr/tQoAq24xS4.frRBjtxPPDTE6BWUzGqiYjyjXABFmou','pika-2024-07-24-09:39.jpg','eLdkShGwTI-fQ8ud-qJPXW:APA91bH21mkubqeOk5UVXbT4zh6c-iAwgru5kC1MWtAE19yp65MZkLQONdwzfzUoF_JPiUjTzG3YqUlA5licFQrpQvA9Yo3oWoJh5tvw1Vvx9gqpSzI9nXNCUROugzDJXSYBAO_rdk_X','pika',1),(150,'ekijuniansyah6@gmail.com','082184493141',0,'$2y$10$YRxd27Ctbu/GWHa2k6UE8OTCbUtUYPP8LGmT8dZ1ZopferSoSjnUi','Eki Juniansyah-2024-07-24-09:39.jpg','eR0iMipiQcW1iu-OFrPw4F:APA91bFrRLPF0mA-Hh4BCjhmWN7BZY5Ll8iXa6hxjYMLORYEv7t0Qkd9MBwbUZyVLh4E3ie9_h9YjsHVdQ-w2rHhwExx8B18o9pVzkysfbKXMo5eVr7b6SBb44uUEVDZ_xB1CEZIl3iq','Eki Juniansyah',1),(151,'yusendimzzz@gmail.com','088268372685',0,'$2y$10$90OAj6UL/IZfiVZx4LsLBei0x.O8XZiUIUUHHXpNJuq8Ip4x9nT1.','beye-2024-07-24-09:39.jpg','dXDXVSSoSSKkKpop4CUnHs:APA91bEXDfZCdiwP7G2GaAUhu3xRns8KapgPhPnBJHEM_hSA4oW4TIdsJVS-RPMtVfUV7RyPqh8kwpPFQ3CILcFPTy4aghewFhcMft59JZ9SbfAbpn7RRGAvbN7crhldGVkPsCfl9DnR','beye',1),(152,'nismi062@gmail.com','088269207909',0,'$2y$10$NPRRuR.VX4nvypyXD/SlAOMl86ZUbmIkBgpwFQ68rlQJiyf2pyoIy','Ismi Nurul -2024-07-24-09:40.jpg','c40fgTo7RqC1TuTBFozg7w:APA91bHbBrlRLHJs4FQjT86YICHc_Zoohsz7CZy_22DynB8wzXBwKDcUPzhSjWbDEJc0ZQp_wladVFu6T50TD9NXvUVDtNwqcVpmc0NQrfw-0JDGsvN5H1s9CysjT4DnIXBpm4lABkMa','Ismi Nurul ',1),(153,'abdurrahmandwi4@gmail.com','083178910456',0,'$2y$10$knbWkO5AuVJRWV8J6uYIvOa9fkemb4RdDocr5QV2zQzpmnQv9TK3a','Abdurrahman Dwi-2024-07-24-09:42.jpg','e_zSHfGoSbO0JyYUAPTgoC:APA91bF4OBXnn84ubCbyhbfrL1XPQddOYiXH_pLyq91vDaxHsek4Zp-7iMlZob7XQjo3QgvTqVlAdA1u7Mv0kxjxlGJIai1XnWc1aM5KIwbohAagoJ4CgT93mPEPrAyWaiT00shOfcXs','Abdurrahman Dwi',1),(154,'abdurrahmanqolbunjr93@gmail.com','083169106740',0,'$2y$10$jlPMKXQBVkCxgbBsAOZn5.P3.54RDf.0NPk1bCrE06zks73o3edSq','ABDURRAHMAN QOLBUN SALIM-2024-07-24-09:43.jpg','fJMzszIFTXKQWOv65ysJhJ:APA91bHfkFtiXgai59K7ttjlPujVp3LUV-oMCOwzTtYJqJnSHwfFEqcKw4dlUdS3so5P3CfbjGRF7Uz15q8a2yKo-87iXvigNgkcf-po3lmAvMCkXrCz0x6J-3fk_6Lw4-MgsaKa_R55','ABDURRAHMAN QOLBUN SALIM',1),(155,'lindawati0115@gmail.com','085357111006',0,'$2y$10$oCXJdkEc09iv2o8Lv/WJXOWKV0vVThe77NaMt4Il7OD5xInq1TeRy','Linda-2024-07-24-09:43.jpg','ehzja1IwRD-CjuSXFya8hq:APA91bEA0GqHS-L1Vs44_I8kg00UTBYTIWFhnJiwUbXPFD9xXr9aOzsWhgbK0D5GeJ1fuEQjNZ7PpHUwNzRj_P5yQ5FPz2puhD_A7vB2uSG1Rt5mu-UkMLWy30ibyoOwNeg5jwri0Wly','Linda',1),(156,'danugrah1010@gmail.com','83178419676',0,'$2y$10$WcNUmXVtZmgvAQd73zpOju9s/oNIlm2BX48SkAjO7A/Ul/57gNuuS','Dimas Anugrah-2024-07-24-09:43.jpg','f0mU4ZzzR5qMS_mqRab8tz:APA91bHrfvKyZ2QGJrXhWwZVkxalmws081a0uCquoiuv9jUlTY1mxkIbhzzVWa0mqAXhQ0z3mi0xmZ0eWDW_CcWD0NeXGkR37r9DAZT8LOzXa-7-lHEbOSH1UnTXRnxSkGQyszI5nBck','Dimas Anugrah',1),(157,'rifqimuflih06@gmail.com','082269636506',0,'$2y$10$7fFVGljyTUEaTCIqZ6Z6u.sWKeWF33mTfVt1IqcQK38c1vRyDAvMy','Rifqi muflih -2024-07-24-09:44.jpg','e6bbxC4kRROLFHTE8cVxeB:APA91bHWdZoTvAb_OSisQT0JWhteYp-Krh_C_venqgSvC8LgMLVtdUUfJB4dMJqqLe2-Qje8XR9lZu6QuOr2xwkap_D1NllmJ_370L-X7LAw9XcxFSJtI_1tk4MHxuorcBEi5u-mxHRS','Rifqi muflih ',1),(158,'puttrayogis@gmail.com','081366378137',0,'$2y$10$1JMnvHQk6PrBkeI/.Rqn/uV3Z0A4k/h.YtYH2M8eKdxmo5qbVAEpq','Putra Yo-2024-07-24-09:44.jpg','eSDCv13lSmG5Mm6msgeHuG:APA91bGs2frY8uxTSC1ZF0SxVR7UsFN7uwQgMvStILK6WjCz31ZpJspPuT5sPpDq3SsgolOV3rOgfVia99s3qGRUdUG6Ft2EJmunMz88pUJ6baJFL85CNXo7S5QGzX222Ng2bBvMwoMs','Putra Yo',1),(159,'nazirazikri2@gmail.com','085788822257',0,'$2y$10$KAm7ZDGOxTqLI.eM3EgJZO635dVRXY80wUZOHxEHxgI2MwqYBvGZq','naziraa-2024-07-24-09:45.jpg','enBzYEVbRvKxiTcqX4FKpf:APA91bFIdsEEF4gmrVBnrBQBKRMN9ubO6FPlia9igtGESCwloMK0L_S-obwXDX60UVIkSlW4J2WRGWWGGrnPWD7ZybEUH8eYaKrHVdGCTlJ5kja7zv9vejbjRiS2rHSiP-LCi6oMNCOR','naziraa',1),(160,'firdhamaharani95@gmail.com','082179973483',0,'$2y$10$5mrf7iji3fF2MrivaV6kQu1sWUGDOvP5l/jcqKjahgJw/aO1yFLY.','Firdha Andi-2024-07-24-09:47.jpg','dTDZuC8eQq2OS72_l12U9j:APA91bFVwYVKL4DFMUU5fFJ-Ej8VllQbpr6PB6eXq1ZfBsHSWZc5R4xTjcp_IZcx5y-5zYiriC739uCuqCblK07T8HCVSJPbyJE-JxdB31ArCwUUKXj0rFWzcyy0VfhSaL0-n5lcqMMO','Firdha Andi',1),(161,'octapraqusa@gmail.com','082181005220',0,'$2y$10$hhw2gBu/yxd5XKzqpwhssOGhYYhoDuwPP3HphIDx26l1og0LZ/aHu','octa gacesa-2024-07-24-09:50.jpg','fM0vpsaJQcG9dd2zW-VWq2:APA91bE97xSwdhe7cmwIxYVgJ8wmvstJJsujtJNTqya8h4oGneEeHsA2abFHndPwI08tmkMyizpQgAK7_daCj66qHUtfIYJ_13HWEG2n4Lr7tYYqUnB57VtyHmnu-EXcX6NAFxnqLR0C','octa gacesa',1),(162,'meizain9902@gmail.com','088276757307',0,'$2y$10$31h1EBlNoVsDzEfWWqr1KuXVIam4MHTgs.a.4mtjffyeJKsudcp5q','Mei ILK - 2024-07-24-09:55.jpg','ekTWko3lQNa3gefSgTsDT7:APA91bEpopWQPpMsDlXu_u1rhcvypdpl57URRYLu_gzNm-b0I6epv52EkyPMzBDjpzjowBWEsxYSNiWf1IWlWIFONQahsfnCx_51dNP9y4yTRqtk94vH6VwlgODD_e9eAX-4mBXSKBQl','Mei ILK',1),(163,'beatindo7@gmail.com','088274172269',0,'$2y$10$RTa8AA0d2xzJhPZM7FbJFe55zWMLXQjuir8y8aTcqKQAfK8OasBW2','kelvin-2024-07-24-09:56.jpg','fAxJADvVRteNOZZ4M75pJ0:APA91bHyK3mrwXXA00aXjx8qCO2hnRXzOpPnET0c5xl1TcdWXZXT4MSb4OD-gcAoDD30lZ1-rxBdAsVX8zfKIOw2FsEFPfvCDTvOIZ-0po-WdgtjVe9KnrnFSlUpf65OHh0wmoghKltc','kelvin',1),(164,'reskiadipramanakk@gmail.com','83875162248',0,'$2y$10$m6w/BUSHQIE8lH.mu0qKYuMhfwZvaY7imvVkFdhKW5Nr35H2c.jYK','iky-2024-07-24-09:58.jpg','eH-EHwpISZ-Xq1nil9USh9:APA91bGmB3mIANbWwanzRJQbIhqG0Y3dDOh4zDZcbTXxgxO3YyQz1s1MXJ5Sirrfy4VV3wTzD6L0cmmUxG6uD0QieDTXyl611ScHSsGidLlojSTFVM0Cmht3Vg_YA-yYcKzbB45MiEE6','iky',1),(165,'margen173@gmail.com','082296633580',0,'$2y$10$oQ.j7P9OUTGZBnfxU7QQueLEaKMGHlplrXrqT3Ni1Aqy7X.AvOw7O','Egen-2024-07-24-09:58.jpg','fqliZEAlQ6Gu6myJIUFDBP:APA91bHR00XANDW0sPnUF9hAiuo8a6V9F-1N3LCqrcBpnbmI7F2ECithc9XO17dM_vmmzgxCKBuEpZGr0kqD-jXgCZnV9i8j22HvZszSNuT-_puvMlG-AC8YTPJ7UkfaUBWGW4P55rEP','Egen',1),(166,'sopikanopalina04@gmail.com','083177185410',0,'$2y$10$F629HLjAX9XEMLtZgJlbUekKbMJzR5OdOaDsj5XFUkEFkbrHt.6iq','Pika-2024-07-24-09:59.jpg','d8u0BbS0R7KPljFmgPwNTe:APA91bHgQA0fVD2SvYFVNaLeUd5kLWE2jYzrG9VTb0mbl04ytFkEP9B39biOYc34_2FzEa2d3vEA3HlCym1auKELRiGpeEUm79O57GHf4M5SoUu8ETAW5Mmk-MvLBw5PSkoF0ec9ZfnO','Pika',1),(167,'salsabilaaqnes2@gmail.com','083831696147',0,'$2y$10$X3ZO2Xptgi00ufzE2hxAg.llRTt7NXSrGUd7SU0IJp74xKZ.t/Wti','Aqnes Salsabila-2024-07-24-10:00.jpg','fnE0vd05QWWU-0ZwM1HJyE:APA91bFjZgu2pAa-XfIz1LIlr3-NhqWgB2DVeaQgyF-mGt3PwBtA2wgJH5QD5h_gvAyDaZhiKGGkxF29rrWnqyi0j2wABA0R28bHz9yrRpNpt30A4LkbIqur8-EOWOe1TIw-TtHu42R9','Aqnes Salsabila',1),(168,'seftianiamel2@gmail.com','085758217660',0,'$2y$10$JDRIPpCscUOxaAhnWpxNtudHSLVckejX8DC0nXtgVoX/w9N/btEde','amelseftianii -2024-07-24-10:02.jpg','dT9hKSSETSisOEGqS4iOVZ:APA91bF7lpRysGmWpTsVElhU4m-2gVHQkmyG8xFWtdKWFTp0S3WzURLwJMW2ygbfHN87U-hJjW3RbeFHE9smLuDbyGNUBmAd1FCzBWzxy_rv1hQXY5drEIaEwxBlj6UUmxwndHulpQHw','amelseftianii ',1),(169,'tika18905@gmail.com','088287763895',0,'$2y$10$d1FjnL0hG9Z5Xaw1d6M.ouM6cXgU9ycEjNce1E.G7yQBUtIzvwSt.','Santika-2024-07-24-10:04.jpg','eHq3pEngRf6M1Qf3wWAVMG:APA91bElwAJPFOjBdGGRHkHWfcuF93HOpHAUp7yKqI9YaFHwEr0mc24Ga10rV4N62qWdAqQcl9BsvdtA6Gkw-6FVsvxvZ1vB2BZ6l7bFjR5nS4EPTcTxhliYb3IxObTjeU0aJ46hs13O','Santika',1),(170,'bizarh05@gmail.com','081373200781',0,'$2y$10$3hf8/iZS9.gwY95N544MQ.pi/qsfV/yPojQ9h5YRtlhjRlrUA0qOe','meisy monica-2024-07-24-10:05.jpg','fZ0ALxusQoi1XYmAuWH3cU:APA91bEeJzQmjsiB5LILnppmbSCsg9d1VXltsj6zco8VFipWU8FjglfTeJ2cJxFk2wDfVnRAOwk91vYcmmoDekstNG_EkpByFe4SWLAbXBlU6QOC1iRzsZBFyi-sHBK6iPTJTVT0pOxS','meisy monica',1),(171,'shalimaadisa@gmail.com','081273622127',0,'$2y$10$8o1PJUoWguSXnZiKM.Rx5ulb.85wy3p4MPFMrldYrnmNEiPwC0.MW','shalima adisa-2024-07-24-10:09.jpg','fvDweZaLRe6ZnqnpGrkx1b:APA91bHDTZpWkIlY9OLHMyRx7LXBn7r5U-FuEXCboW04h2gCEhRDUk_Ze2NILw8Toq73NvkGOs86RkYSXlZk4Y9kXjo1ZfkzysxvCUYunf4alhx9Fn4Jxrik6pkgO3ZjW-YlCo_gpVay','shalima adisa',1),(172,'andreandavisaputra@gmail.com','083867055093',0,'$2y$10$pxfAwjuU59skqM7CUGh4ue6sXcbZm1q5jt2zk1p9/UqL46r8m1WTC','Andrean davi Saputra-2024-07-24-10:10.jpg','fYC0SiusRSG8TWL5wuvF5g:APA91bFPD6gucM5G5tLcvIEr0TF3EPU7QeURebRcnmd3gDp9ucjz_ybvKamQACJB6Bz-5gFKN6eST4xI_TYoiY3OoVJVRcGFoPE5ii2eTgaGwPq8yhHLu2ZULMhRHDsH_YduLT1dp2Je','Andrean davi Saputra',1),(173,'mustakinpraja3gmail.com','085369741302',0,'$2y$10$VawIeD48fhkhJlwIdErcPO6qXNmPI6jsJRt7OhfpqsxINr6lXlmA6','mustakin-2024-07-24-10:18.jpg','fe-zpXiyR9i8KaAQKsbggt:APA91bHloQScweyUogZJctfQqIvhaK_bY0mNeyTPn8Axgedzx6BZ3uGqTlxzxTDY2Ca7tMZR8g9JJawgXZROzeo73ueQJojtQCREt6A3xC6gNJfhvLLCUah5Ia7aiq0rp-rsnplpZsmg','mustakin',1),(174,'antidamari65@gmail.com','088279775776',0,'$2y$10$LOiGXJypTBYxVGSNCKRrB.19ctG85ZT6c/YvxpDIfq9h.pc7CnjJ6','ria-2024-07-24-10:19.jpg','cYA9RiSoQROOYlgJaW9Sdx:APA91bF3ogyPTtMcSKxpLGmAX0YRyNHbD8HwkzIYizLlwWPcxrdKb7--wx-kn14ekUHASr4R34pfVW05qRl42vbIFTkboCTmLEyfcaDd0cFosV6oXo0RzkeQAaI_rDX_QHg5sAVZkFZS','ria',0),(175,'kgsmuhammadzubair@gmail.com','089513153842',0,'$2y$10$LdSy1RVBhzwISYII0kJEV.0pqEouRL2OVFhyGUBZ2e3zZ4j8TRAZm','Muhammad Fajri-2024-07-24-10:19.jpg','d7iEmQOIQt6sqbpIUysG4T:APA91bGwZsWmQMGpc4XTmMoEbr3FOyZ3rHUw7JjH67KpQFPouPvqvAgzZ3heY1kXWqd8-e-cGkZOVC89SCJ0Iubeim_vH8R0rzKMktekjH84E_PCCjgNdSDooCQAe1fkwOIuTOwU_iFL','Muhammad Fajri',1),(176,'sylvyadamayanti09@gmail.com','088286348469',0,'$2y$10$bGqQiaFIdKwBASkPFe.deO85iuOCFtAZwowtAd/OAoPcktDbS2BW2','Sylvya Damayanti - 2024-07-24-10:23.jpg','dME-QzrJQwCJ9QF_GV6wgD:APA91bEIAkSbvJdsSm80V3n9ngwg6wrTBGvdtfwfLEqxPtNFKcWIL8a6Z8m4ub8ScBGSI9vgd5yLilgyAPQvl_p_p1AReo_LdLSbgVy1amFbQ-IZRHZidTDrcLLBY0FCEk64WA5akZFk','Sylvya Damayanti',1),(177,'sintiaapriyani52@gmail.com','083157901973',0,'$2y$10$kAt3L4x1F6oraKvpPdWpLONK6Zg/MKer/qLSqxhDwXWZ6xsslXdy2','sintiaapriyani-2024-07-24-10:22.jpg','e3pn_I6eTruR8XZChPGC8k:APA91bH5RgB11U-B6IA7C72asL7Tbt6WdKzI-iNf8iuNRPlxHBy_kpFNzR9JVdSERK8TJnxRRyyI_-FoZ5a7fgmzhAnWqcs-cXeXFLPTLZJU1QlI8UL5FzWIbme2PqIV4A7yDCdggBTm','sintiaapriyani',1),(178,'shellamartina24@gmail.com','082386006887',0,'$2y$10$BOivAdKJ.dlZ6a2dwsy97eL/oR7F751L2No4nBxyIs5NgKU33nzBS','sela martina -2024-07-24-10:23.jpg','dNIzaKaPRNaPmkR5GZlKIl:APA91bEvpm4MICLiTCk7k2g1Z9t3IJMIaRITfpx3eg80qO8Gn09Dk4fRWNwOhS2ScTtPZEunrDsCnqtC3KUtAccURvHXb_Wp92vHedUjgUH6yq9Iiav-acCA4xuIlGP01sUZG5AFDJil','sela martina ',0),(179,'lisajusan@gmail.com','082278342809',0,'$2y$10$EJyMfPiPyjnkRgwvwihh4.papzXZfitWEGdQ0kmDPJDzhgOSbX/rG','Teje-2024-07-24-10:24.jpg','c8pe_FC6R4OTQNAztp24GD:APA91bGAoOwEF4cwbJMXAEv56rIkROcw-7HLuygHqgFpgxWZSQ2sdVqYd3iDPGKgF_1y-51pEIyLxSqdzPw_GROCO23Te3Gaf8FjPhgZhzta2UVXkD071HLUItz2ZCFY_ouTKi5xBRWe','Teje',1),(180,'ikhsangelcy24@gmail.com','085838563712',0,'$2y$10$YIRFEMga12b.QP6CL1SO1O/4htxuqOYGHpWId3gNyCnlCUvT2DQiy','ikhsan-2024-07-24-10:24.jpg','dE-aXojnT8KGlW0xJAJK57:APA91bEPfdPcV3j_1Wr4I9ML6Sx0Jcxhz0LHIeCWK57Qo84F0pOg6cWl81QVAMHqB247hJbnL0dFOd36AYmJoYcRI3d9deCuKhKe9_SS4wppgl__iDzsF6ilKoa_afYpfewfNh8AdMSY','ikhsan',1),(181,'rezawrdana69@gmail.com','081273646116',0,'$2y$10$AxZOq0Cdo7ED8YDcmMeJZ.H6QOr.yqMHbRQZITiFEb2TzEfyZ/GRC','Reza Wardana-2024-07-24-10:25.jpg','fNoSK-jHTjO5phrBhBVyyV:APA91bGx-jnii6njfswUpGgMKdtWOll50Jyw9j2aQtUVlgli-0AQXPQyRpy7eqIyWQKWKTl0_ZY4JHRHdfczgfsyexh9Kx2_6bYphN7tR4r6_64-Zh8aHYYK8e4Oe1Il47iQ2QWBP_gS','Reza Wardana',1),(182,'ljoko0864@gmail.com','088276775776',0,'$2y$10$ZCxNHO.3dJNN3vi48WOqm.WlLenvcvgBNOW7b2NfVHm4W1PF9lrSO','ria-2024-07-24-10:25.jpg','cYA9RiSoQROOYlgJaW9Sdx:APA91bF3ogyPTtMcSKxpLGmAX0YRyNHbD8HwkzIYizLlwWPcxrdKb7--wx-kn14ekUHASr4R34pfVW05qRl42vbIFTkboCTmLEyfcaDd0cFosV6oXo0RzkeQAaI_rDX_QHg5sAVZkFZS','ria',1),(183,'suyadibae242@gmail.com','088286597575',0,'$2y$10$fbPfKjkgzk72SNpzLrub4OVd9hBI9k6DrrylY0UHl8HKbw1upTEse','Galuh Yuliadi Setiawan-2024-07-24-10:26.jpg','eywec4prRdCDj_9R3q45V3:APA91bH0NaZoYXfD99EenDPay_n9dwgFzv4saBt8KwR8YVsIOUw85RsHLk52U8_To6KVDTElTtWrbmre49MFzz6uOfwcKkRLl9K0s1JYH1EnGy63JfYWUjzf10CKlb3jbFe_AuaN6j9e','Galuh Yuliadi Setiawan',1),(184,'ridhofamily9@gmail.com','85841968248',0,'$2y$10$qaobaOgYuGfO7GMlKlXtXuZ1ryba5KEIh6TjjXMZwldG9VpIpB8IC','ridho-2024-07-24-10:26.jpg','dEBm8avhQgO85CBFvGmNJI:APA91bGEgAzGrzcgBD7uD7oCS0GIHoq3a6vKBsbvX1UDW48o19ehvNcL_16PXYd_8mQncxVzUxlCsONUo9BBNsIigdyim5FN9_OlvJKS3Acw90t1R3IYdQo3zDLMl8motB6VD1k42609','ridho',1),(185,'pujatrikana74@gmail.com','085841216319',0,'$2y$10$EMbEwQp7tzkEa.N/1DGUX.LhQw1XO5Ao0IgH.lsqpUGhZNlao/ggC','Puja Trikana-2024-07-24-10:26.jpg','cw_4LmCfRQKJ3_z-IfJTf3:APA91bGhVszfcYqmMTgZdeN9RJTZMyP32XHIaxHyvPNwj7GnfTl5QIuJN7wWXpCOW2uieK7e4vAyfky_JQT8qPQyZ9wGIEb7J6olHmT-UN4PQfe2DNC1JNt23TX52s4tinOEykmufSJj','Puja Trikana',0),(186,'asnaputrirahayu@gmail.com','085768307350',0,'$2y$10$Wc.pe5nAgpSmB2F7H9acq.jbQmhGalKYKruaW2zzlZQTtRubb2ZZ.','Asna-2024-07-24-10:28.jpg','dckRecOxS2WQGIKLHpnZEv:APA91bFvh5vB1-Uh5BXAQzatkSot_CSalYnwNuT7XoQAPx5fSylIWcJcQ5Hw26ebBBmNoGWPXp5KSuH9QXkWwF9_EFYfebENX3MXRb5CEMPOVb2MxHRti0ma5dufjb_7eNQEhSWz10Ln','Asna',0),(188,'hadissyaadis@gmail.com','88276479648',0,'$2y$10$xT7J6fL5HaVIBv6KsTr93OmJiq2WPWYYB/pF9dymecf9Znd1tqSjm','Mak pit-2024-07-24-10:29.jpg','dw9QI8G7RQq4WHJE5et8Ha:APA91bGNZM5kNN9jsfyDeodjkpb0oIQYq0BO_m1pay1bCLhJk_N6iA54waA7v_USvuTQdbcYhwLxPNXYvmSuiClKb_ZurDG17kc89qhgQIkMtneQONmPG5b-aFvOHkqjRwAs6g62xde7','Mak pit',1),(190,'oktasaphira8@gmail.com','088276798629',0,'$2y$10$v1N9/TlIXhV.30fVfh3cnu.bEM4waiUbFk1fzBIpVMc4TzVNCdMxa','okta saphira-2024-07-24-10:30.jpg','c_T9Vux9Q_GM8DwmXK9dik:APA91bGFXZDBlnQ2lVQmrvZwESS0yTw0i1uD6Rlu96-ekk25Cq3oAh5FwwSBWnY5gUh6DxsRcQeNIjX_p3hWg0Gmt-PfyMTliEf8RLcuh2RT-HbQg_TZzszRcpCFbHiKr87s8B1q0yG_','okta saphira',1),(191,'argasaputra2215@gmail.com','083863363235',0,'$2y$10$w0oQ5iirmfu3Y2gnJeUEre/fpkzQqhdaZBvW1M00Zq5cHnw4mlsim','Arga -2024-07-24-10:31.jpg','dY8cja2HQtuyQed9vcfhnl:APA91bHYKi5UK2YWKE9ATI-0gP9ZlIy7jfsCKRAcqaTzRRM9DMgWRtZh6e6fXMQKrtSd5hHdOQqSBa1juXA2c1o7N6ZLfZoYC__JxLgPixuBwqGNnmWi06b7BRqDYx0i__O5jAo5Fp1J','Arga ',1),(192,'elsyafriska10@gmail.com','083157901048',0,'$2y$10$trXNxCiUamuUKHygbQy8tuUuIsLyKlnqwtxSkziWzaBS1QwDlthA.','friska-2024-07-24-10:33.jpg','dr-GFEp4Sx65f4BxzMOskO:APA91bGyBlDAqDQBJ-83MpxgSqJM6xROmypfvjElkBx-fsOHCohpEPDII5Y2KWJILC3darhedKAX-umXdGjSPMAQUh6PluoKPAgfTxKwCwSJRDRRlZSExZou6DT7Oj2P-YqFmsWCO-ol','friska',1),(193,'novitasarlina23@gmail.com','081278006002',0,'$2y$10$pt0ZFgnUXzjD3IR.A.HRNuEoEvXlkZXnH6xw7OaUH0IPo7R8yDr6a','Novita Sarlina-2024-07-24-10:33.jpg','c7J8JDM1S9OA7gq8DMYjvI:APA91bH3W8fi6jL_DCiAHmxx8TH1RgxLUSaxH3-Q9Js1NeSiB_LpwbivV4yJ23tCObOAjrtBosW5xm0cKwdjsFBpKzWX6R0jWts0qx3CqRcBCVE7V3LPBaVgBPsktkNuCFbSgE6wGZi4','Novita Sarlina',1),(194,'gmaabdiii@gmail.com','08896659129',0,'$2y$10$4ZHjUlpnIquYjg3hebaV0.YNxQRodBsu0kIeu11Ya3AzZUVWWsUiu','GAMA -2024-07-24-10:36.jpg','eALH8rImSNWKJ8sJBj6FaR:APA91bEKz0na3mKAxw9SPd8lbc1PKcoRfBuQL4dQchnvoFveD1cXXE5BWX4_meaz7bnifte2H0DRWt-WTfSYCatgqmflFyUgtTX-SHj6MedF4vhiRuSad6_LF1rn-rc6lo9bVYSFtxk7','GAMA ',1),(196,'kopikap2200@gmail.com','083163738121',0,'$2y$10$30lcjuqNRi.V6qAVwRQ45ukzXujMiPn5ws9qd5rOoJOzPMrAaTugq','alba-2024-07-24-10:38.jpg','cksnYrXfSk6Q2KngglkbJu:APA91bE2LNGHeXCvGRavERNRqtxv4ylW6IYuNaqzWelQbEgMotJe3tMQfEOSm33VJaX0YM_U-9o4CKDfz2Wo-ZCOmcHQINW9MhUTH0mxJiPIh6nBe4MW0i2J-n6vAVzHrokUL3AWO3Y_','alba',1),(197,'wulandarif005@gmail.com','081271267006',0,'$2y$10$wtY8H3g62s4qktVXPULAuuhV9SJXWy.V6tgaqgmIebipqH19PSdqa','Fitri Wulandari-2024-07-24-10:38.jpg','d-vNDnChSmyt4q1EBVhnCM:APA91bFuXqDQ1XuWlZds-Kuy6Lg034B0VKni6Rl-QPfdRR3TnCAtAa8a95NJSQqxOLTk9b4GpmSFrLqUP-wlTxNabHc6bWSExMkCSmI8FZOPUzj4Qc1XaIQnL3XCP5xWdkl80DdGu69Z','Fitri Wulandari',1),(198,'arjunesrex@gmail.com','082269630475',0,'$2y$10$M3UcB6rRtQFuUJ.AFfoGxuFsEWBL6OFkvRM3KCMK4g.gD51m2V0Vq','Romi Pad-2024-07-24-10:39.jpg','dMpxvOJZTguSzx3_CmI0c3:APA91bEQHlRE4Wuw6N2lM9NyrcF0zXe156A6dPqzT-6mOIVDH64uEZfqtaAOimGNc4tWnquBjm2nxTXi2Fgk5ZUCr1YKS4Ytv2B6IO1McByPHtAhOAVRVKvWkK_ySmcZeVhHq8KXAjXF','Romi Pad',1),(199,'febradiansah@gmail.com','081379400451',0,'$2y$10$05k9J2j9w7DlN91m0GKSQuFALgGLLbgXO5wi26IScrSd6CBIMNsrO','Andi Akbar -2024-07-24-10:41.jpg','dVIo3DgtTz2KIS2OY67PlW:APA91bH91Ph-gBrcihszG8Qcl8OTu9puiv7kz3qHq3EkSEwtoZgak8SFPtq7V-KuR-3a1PADqS4icIpduTvNfaZv67En9jWnGMc1Wl7GxpXYz3y768pL4pxgedEVTGJEBcwJx3rWD0W7','Andi Akbar ',1),(200,'rafenalestari@gmail.com','082376360749',0,'$2y$10$oSbHNPqMo4WQeh0cglKgaeu3WA0NPYoXK63e.0DPi4K/dd4t.utKi','Rafena Ayu Lestari-2024-07-24-10:42.jpg','cOMb5GJxTfqW_Wc0daHZ62:APA91bFQ3sJOtHKsJIdK0Y5rDhHHin2fQ4dx3-JqsNTeRg1fKH90_xD6flohB9gLmZWQ8OFFS-bsdHWt-D0AcHoi_m9Qc9XRVQcOz8DxVZ9O6MhPlAafV7GLOOQ5PHlOmEqyuetIjm8a','Rafena Ayu Lestari',1),(201,'hederkumbing@gmail.com','088274356252',0,'$2y$10$BAV.zqBv.VNfUpQ3/s7VQON.TZ9AhchLsPY8qq3C.MBvRq0HiTzi2','alsukron-2024-07-24-10:42.jpg','dekuO-KnSYSL273ucTOyNR:APA91bF0LvWKyofB78rJU9SFHwCKFComerTXv0-lpgB9AUzOXDGN_AvRSU-E6QGxBxvmI3cN3jdLprm4Qjw7a2lvZXJwT3ryEtoGfQUfWvbV-FNIqb5abZzJblvnUOzDhk0ZhdYp1GH-','alsukron',1),(202,'syalirorohma05@gmail.com','081226503903',0,'$2y$10$b4duXDnvDwyPOIdVg9.ayOH8upzZh/Se9f75vnJPEl1m0qfGe3Ol.','Syaliro Rohma-2024-07-24-10:42.jpg','eUOcSOASRQ2v_CBdaETWGi:APA91bHNRwccjusyB5AYR-ottpN9z8DVVwaMiTr_0mEtakoo69lzxm2XDaTkDkC4lYtVLIGSxFoj-WdEgRjiZOUfi6-WiFvtL0xPDD6iLNN0SE-Bxh6N9-1c8ew2GMvlJhgBmovumplA','Syaliro Rohma',0),(203,'phoki962@gmail.com','+6281368376039',0,'$2y$10$2oMw5ZFrJFt3hZ4lHg3lQ.yKXJysMxPv3zaFXVN5Y7OFTdc/IOmuu','habib birohman-2024-07-24-10:45.jpg','d5uZgKkbRz6oPZyI9S8rNA:APA91bE2KLIERuzq4smLzwv_ReVvjYD0wHZ_zeomsIKoIanimJD7k9FAohToSddYY5PlhvEY4wuIGEVnRg8gQzszU9hfi1AJ__bNaqjrIb-j-LM9j0Qq2k8b6xAo6dMnHH3bFog_KwQT','habib birohman',1),(204,'arimaster112@gmail.com','089636939829',0,'$2y$10$XPM9GwKY2zA5.MkrxWy2XeDMhJ4eOuQLoKRFH4j3WlkY5HCk0Yhtq','Ahmad Azhari-2024-07-24-10:46.jpg','dDOL4AX8RwiQ59DAg11Wve:APA91bFP1-gG4rjD97zpe2x89PjMTNzRRUUfBELIWNt_KqvD3aIYeJh7hACIY-ihb-Y1EYRDLCLExt8OWBmTUuB1dNpY1wRwSsQjCZa4EscdIToN2VZVMabAjOya1Xl_icDhuY37qd39','Ahmad Azhari',1),(205,'jeniferemelia1@gmail.com','085266118375',0,'$2y$10$ZQuy4bma.8uiO.WI/rw9/Ojq.tW4YSbNTlTAtUZk226MvglDcKcmy','Jennifer Emelia-2024-07-24-10:46.jpg','fCWPVRZLTdmuxMY9bz05yo:APA91bH5I1D97rRy-ZXcCdI3vJ6y7VPnQEkM6r2V7HbvyYHAkwtH260utwa-1Xz-whetliLyzam6e4nOZdwo09LZtJ3OQ85iVau92JBq2aRrXjObDedoJ5MaPIn_kmdihlCZieQp730p','Jennifer Emelia',1),(206,'rudiy7093@gmail.com','081379172295',0,'$2y$10$bIYrBTDPXYc.9h6uSlvNm.dqe9W/3UoAyJnZcvRVnbNtGUPYg8kwu','Rudi saputra-2024-07-24-10:47.jpg','f7tvyWBVSbWiKivIZLRdgB:APA91bEIc1dpUcbr2UfEmfCUt0_6EQ4EUQIz13MR4xWmVKG-3sAztBRpeVwVIwLoCY9_aDuXIaBFajhLnDc4tBpyr0SL5ubZTOe9DaN51iVM_3RaNmYjPcoVRDE_n3uokFK-6sVJ_cUr','Rudi saputra',1),(207,'arikandoko35@gmail.com','+628876527389',0,'$2y$10$W1tKkf0iof0C5DCnOCBKEuKs7ims33rwMtxwswZIOZtDa1dqgYV2i','arikk-2024-07-24-10:48.jpg','d_rpMUyeRwiccoDF9cMY-k:APA91bFFtjMM-BhRkzPeb9kNPE5LfO3pIk5YtaTWPxpgyVgcx0H9skhuXu_tosN5HtpAn1huHuCYbQAOIHuLv-XmKZ8yS0ttsM5ijnLM27iZjhnAxsaEILeVmOW9iVmo110rRIL9XT4f','arikk',1),(208,'sitialifah585@gmail.com','085839201665',0,'$2y$10$/4DLd7z4Z9KEhIv76URaXuI28YTDzhLweBeC0sqhOrqqj1K73C8xK','Siti Alifah-2024-07-24-10:48.jpg','cA_V45H7RtGwYQ0j8oCsdz:APA91bEajIc4jcI00cWA985G0pecRcOxCTJkrKziCKYxd3JenVRfKHs8YzUWOB9E7UAHAaHsod8JWBASbbMtFg7y-sAVEwSjxGI2_32N97n7l1KSlqaGLSRFDX0LvtnN9eUUOmtiAbXr','Siti Alifah',1),(209,'arikandoko1@gmail.com','085212128694',0,'$2y$10$uiPZAmClLtvnmBu3xow5AOemHNlkFmtXWElTMYXBNjQmJFhVzZ5HC','arikk-2024-07-24-10:48.jpg','d_rpMUyeRwiccoDF9cMY-k:APA91bFFtjMM-BhRkzPeb9kNPE5LfO3pIk5YtaTWPxpgyVgcx0H9skhuXu_tosN5HtpAn1huHuCYbQAOIHuLv-XmKZ8yS0ttsM5ijnLM27iZjhnAxsaEILeVmOW9iVmo110rRIL9XT4f','arikk',0),(210,'winda544358@gmail.com','083192595482',0,'$2y$10$6p5M/bNpsFsnHm2xUyXXEuXrZeWgGKiOJSH2qhYyGSfk/Bs3SVAxO','Winda-2024-07-24-10:50.jpg','eIfOtCv7QECZxumeEAEq-q:APA91bG8LT5NsMb0dFu7Kpq8rg17RO9kyRARvfqe3R4UNCyhJBOOEnAtKcsgrS1i7V_jA4WFV1a-AYG2SJB7m6OowrTvvy9WoxFlrmD5ZNl3oVpFp1bo-JDS-Ujok_rO8-zjIunsb3h8','Winda',0),(211,'bunga14.ba@gmail.com','082373133742',0,'$2y$10$H4ikRyjDS066sND7M/i.5e8hjEKC/z1EgN/aq2/2lbrqt7NJ0ecYq','Bunga Agustina-2024-07-24-10:52.jpg','cAlJaiw6QtaY0Ry8xEfhuW:APA91bHqyS_o6qRm__WZ_RZVeKDBBSLvdUHPOJ4iXmMS0_fakJ_oV8yn-vz5NWBBTJW60g7hN0J_FYxX8k6jW1u2CsTB1q-vgymv0HDGaiFU9Ao6QCSwX5yLTp2rLTrqsqlpkTf6ZkOO','Bunga Agustina',1),(212,'erinnnaaa@gmail.com','082380064377',0,'$2y$10$9bSUcpDaY25dvnK8bGwdj.hI59UIlvE0Ku3vZLyn9LaIpsMFwPoK2','erina piolita-2024-07-24-10:53.jpg','dfgG6dq1SjCZUlV21qfh0_:APA91bFRTJUjIkKB42jQZPTKIjiBGHom-1ROzN92POj5kTLCQ2k-EbbyUq7wpxaUMW5O4RmwQR31AqM0_OsqTN59wr9e0DFbDeWjp3QMNgix8rRjyRxQJiNwyjiE_Ov8bH7G4BM5LzNG','erina piolita',1),(213,'adityapratama301207@gmail.com','082182693792',0,'$2y$10$kyWmZbWk6Zaxwd/i47heQ.zVVOq4D3NO3IflkXgZ0RkBv1tWeu3ym','Tamaa-2024-07-24-10:53.jpg','cDywx3wAQlaMPfoQW1QRrg:APA91bFJoY-jzXlFMLLENUna3JlEKt0FBDjE98RlKxGxzf5mCKSEwmwUiZWjrwTbV84vsUbvLLa_K_kOzSpFOXLDQ8N40C4dl2gHPBh99Ep-VxfFju1rgi_1pHk1avpbVVTsx7ZKAC4M','Tamaa',1),(214,'rorakrisdalena@gmail.com','082182286176',0,'$2y$10$qDHMMLw6AnHB1YArucWC.ejabMpy96zfcFW7g5JMkkLP//0m5aaxm','Rora Jami\'an-2024-07-24-10:55.jpg','eHiZfLKPTrmDpGiZECXN53:APA91bGboxZquzU41A7frxztAAlSqoAdbdwskmk6c1fyJeh6L1mFKilH8SU3XrPZeeXNptgMlz-rn5UuDB3qyUiIzE_SYd-j0TPsCPkVdkvp6kb9XU-bjnfzs0zDzL-X3Cyb-COLEGPi','Rora Jami\'an',1),(215,'milhamjani515@gmail.com','088287596935',0,'$2y$10$5i.LnsqEMFdyXOz3kM.3m.E6LlkZ14a0vj8sKXtj7tetxDq24eKxq','ilham jani-2024-07-24-10:55.jpg','f9R5LvOxTy2Mr6NOHYht8m:APA91bEM_5KenjH1oHm5Y1VevLxpcF3721Erin1PVMkGP5dpAY-xgSvfxyjXBSJ2jjI8d1zJ5dlmKRyeeQFoWm-w5WzppsN964ayDwt9gBozNBjlYSVq2Hpmnl9poXXZxbpiO5Ol4qz4','ilham jani',1),(216,'adelatifah004@gmail.com','082281208044',0,'$2y$10$j8o7zpQYkG/Xnw0XNBb1Buz4pg.COfkJU3Lp42vWoJmPUBkmR63Cq','IFA -2024-07-24-10:57.jpg','fqKvP1SAQLSXUEGyORVRaS:APA91bFeeZVKv9Y_zsQq57FFbX-YQcesCpwdoJvnCk8zvjk-uiXWYA7yd5mcbvQwAhx_KXqg2rhSB4ecNqtRFYnaaRMZOTspPb4dwqO8kbte8F5Z21iuWJ82FqOzr7JUnbDZRKo-CUOO','IFA ',1),(217,'teriyani65@gmail.com','082269096931',0,'$2y$10$Cbia0ddug5qMEohwSTG7yubl.o4aflbyzpUPNKDcgsTAYSccwbPCi','Teri Yani-2024-07-24-10:58.jpg','f-awbF0yTOqZt7pVukV27s:APA91bGWNgSuTGy7ASO2-m0LCGlMQPiEu2CTqlx0VVWjd3zTXFUqdorxBjCkiyhGkl7Cn3jDVpvOFdtpWasWBqW3xip3NlA1zHSNd5St47h5QZ4VQpLM0tsj1B86sZcSX3M6TgMu5wgv','Teri Yani',1),(218,'dimaspratamaaa06@gmail.com','085874070519',0,'$2y$10$WNcyzipzss692vBHS7Mk1eInkECSM5JILTxQWPNtdfGxMypHzgXti','Muhamad Dimas pratama -2024-07-24-10:59.jpg','etgO_DnVTjOL50Gvt2Vx8M:APA91bHQaMlrQ4eg_AuaxS5dPYgDvHx_dTVYISBNpaAQ_RiHIiEyuCsSmzCHzyKmMsefDVw8lt7SM9svrdvThWS_kQcaHMfIDcrbdpc4fGq-KRI0rV0oRqtDTSh98Z5zYo3DgCyuAmi1','Muhamad Dimas pratama ',1),(219,'khaironisyah82@gmail.com','085267334450',0,'$2y$10$Jt9oaV8p3bUfbJiAwHoeneIs0/6FSqkx2oh1aGQaB8NRIaiK0jqly','Reni khaironisyah-2024-07-24-10:59.jpg','c5liiMJsT8Sj-kZZF1P2wi:APA91bEnv8iVKoQsepN2DXwCWvsiFoOmhyEFYfV_wHyujKyL7nXhS8cBtthK9HrTVnv_Tn811KhYXmBP2gUDSGNCCqcDYFKGwGMk8fkNsZXsZfJozLetg5ghdnqaiaONlrB8V0FvGAUN','Reni khaironisyah',1),(220,'endangsturina257@gmail.com','082372887721',0,'$2y$10$hi6IrRlMq8WZiOsr72xkx.v60N2OlWTreTI66eHNx1qmcL9OfOuTm','Endang Ojik-2024-07-24-11:02.jpg','c0DKcwKhQieK2Ldo43lZIk:APA91bE1_2Eh76HFTKDzcGYM5X1mLRa6c80qw_P1n9-g_52bjMPMaFtqP6d-38vq1qHqI-eq-aeLNWu6a3TdAvAQ8E69ZlRRKJUlHgBHtK79eTkhjYU78vJ_9FfvcVaPzzqliDmaMaFm','Endang Ojik',1),(221,'ekkymefrinza@gamil.com','081271575403',0,'$2y$10$JVv6hm3N1fVCYOVOK.ggB.EsQtCPlgytktYa2EQXZA/1ehJNYaIF6','ekky-2024-07-24-11:04.jpg','du8aAZbuQ5y4zAcyBR44kU:APA91bH50WX8dAmPM1C7CNzKP0k_nBz34C_cS-jrt9Jgwbnj8Sfo15WXjF6TC79JQYLrIwZc123SwjQ8K_K50Y7oHYOVQTxgIsIse-iLi_Nais4KURS8s714zBudVLSZBZNoefe4opD6','ekky',1),(222,'ramayantik@gmail.com','081995123116',0,'$2y$10$.rsd3aTzsX0Ga41yAzlW2OkD6o1Du37rbHk9H6pMiJw7Izw1RfIo.','ramayanti kusuma-2024-07-24-11:06.jpg','fvyHWx4lQx2zRmlT4mq1O5:APA91bGqBlPvKPh2YjeFeUe3Wj_lXru9fawgxBuVptMF31SHZk8VugocI1NCrwvyZ-JlES9-HnYZ5ZOGg1Q5rmXzYB14IhBQMMdifuqRiqn9VICMQt_SjSRN8AdJwxKWrpMvDcB-7YlA','ramayanti kusuma',1),(223,'feriyan3512@gmail.com','88272182783',0,'$2y$10$TQu07CvWw4hFYTQLx244ou9OSxDXEAti0YPvT1UuRRLx02Yfgjvcu','Feri-2024-07-24-11:06.jpg','efDSoPwHSaasbOFQjMm85E:APA91bEwkSipUd_00JYtAi2SJy7S_FLuXwt_J7-7VjQZtcpiHm3MFqUHhdo-sJEnvH03B6WWVwBwbzQD0IVnoBdKzV7lPGN7NUhEPKsiGJs6WTDZ_0Ln1ePfKfqc_udbtIBRI5hHWWFX','Feri',1),(224,'pajarsurya221@gmail.com','+6282177075517',0,'$2y$10$USBjzCqVpZ7H/Ox6T6coLONgaHpzltEkE5YydA2y4gzEj0SZpd.ZO','pajar-2024-07-24-11:07.jpg','fGfg2PWpRNav_lF6qYzYCV:APA91bHeEVMGkDodwq0p3NaVaY1dis8gQZ3RFLh94Vg8lh3UJV7fgkFchm9PGe7ccLAWBCSf-B2eeW_MzLk8J0JfrQ8aWA_KevVUSPsyP77lTa11CSQOVAu19krBG6pxsIgzMLgxKU78','pajar',1),(225,'tataanithiya01@gmail.com','083176052681',0,'$2y$10$a.n/LrAB3gwNaydI2f/fNu7OMbnGKUIyuHcU0PvDLoH5hxBvLafUS','Itak-2024-07-24-11:08.jpg','dSj69GsTRSCXsodeKsz2EG:APA91bF6JCF4gcimEH9e2ZibXwpsPGsBDEqalbMMy2oDu3xA9O0PQ_3mbAOnJPEqwKzgGBCDgoWTN3tVpQDtAUJUEpgSkKghwZFBR027vpxpFahFArLB6oKBta8DNZFksHuC_WLQZfa3','Itak',1),(226,'aldif6452@gmail.com','083163852463',0,'$2y$10$f.F/.vo690omP7PvCmONuucxu4n2BlgrlglkyNJMijMfHYe88PQ1i','Aldi Firmansyah -2024-07-24-11:09.jpg','cL0veUo7SruAeEIbm41GzQ:APA91bFhreGpxzaPWbH59d33iuwnW7EyHq5BMYXkRYzJ2fWXhWCI3CnBKXyuLhcfhrnPO8X57E-TRZ3W6RQimsM6m5MZoYeqsJRd7mTLBaj-Sl1QQD_CIot6luWPrjr9inzpWjd1WQnV','Aldi Firmansyah ',1),(227,'primabusiness37@gmail.com','085769644633',0,'$2y$10$Wf/feGlo/mapLhbKIdnlpeDstNLPGa.YHsjvygyGArmw0pXERUtR2','primadini_a-2024-07-24-11:09.jpg','cvn2hruQQjGhrOy_GaLQ1H:APA91bFJaAFxmR88F447xnk-QUlsFcATlsduHA16MLC-ZIoCRsqJGI9hfPZnwYg66QQ5NdU6wngHhKn0UxJSxQAnZTGdh3Cz0Xe3UA3LfwAqppLJntqZiq_eurHY0otmhNevhXgPt5Kl','primadini_a',0),(228,'siskadekasulistiya10@gmail.com','88269781767',0,'$2y$10$zWTzMhw9r.S8tJ41bA2Lr.kBREB9rvf.ulwpORqF5q/1YBb3Oa7pe','siska deka sulistiya-2024-07-24-11:16.jpg','dNItIlj8Riy6oyzBUelWdw:APA91bFL17TI7db22A7lmlSmA-aDnQRltpY7yDqnT6zysZ9fQByRA4_25mHLr4n30sSjGvSpRKx34WohjEf1pGvpQKT3jVlJ4p24zIY3YXBBfY-brcSw7DAtRiO4SsN7ukMnelay2Rc1','siska deka sulistiya',1),(229,'posel.khotamar@gmail.com','082180655656',0,'$2y$10$xzxxokkbbi7MNmbVFcrPF./jeuhy6lMw5uy3uNlC3qGUvdh1nSwVi','Khotamar-2024-07-24-11:17.jpg','cu8WQjUUQmaxMk6g4efMVJ:APA91bFdWYxTwC4AcoeGOb1ws0EPAHbs4X48l9lwsCtIJKjYSHRjtinapTfU9AqfB5Ku6AFyglrGfju_Gle0a8sHAljE_Yr9bSlt-DVkSYA0VObuWKpCnUQA-fYXQDmZWxG6Y_o2mbuc','Khotamar',1),(230,'andripradinata27@gmail.com','087844138886',0,'$2y$10$0phsVNQAfsX10nF0HtPyKeShHU/uI5odS2UYHH12TZLj1zC.4A616','andri pradinata-2024-07-24-11:18.jpg','e1yW3v4BSA2VsbMkS_JqFA:APA91bEUQUvBeT0F89c-MuaucJD-TKFrcKAgzzFhJa2vhAvPUrddWA5BIjxU_PvwcRcQF3VY8OlVTu2IhxDOwuDfnv2Pf4M4kN04fC8-hs7B5AbODIK9kclDFEtAPkZ3Ki2lChz6DnEx','andri pradinata',1),(231,'hani.ni6785@gmail.com','083168972268',0,'$2y$10$k8szz1FJlyDeJVOwnoB6MuwdeO8U52RIrMHcA4UORGPo1FCKo3acq','DANNI HIDAYAT -2024-07-24-11:19.jpg','d-h8GJ7JQ5S1ll7hwuCR2t:APA91bFQ3twfRoiEAOP85zrRwJXA-pwdp0M7nIgZewlIGj_cjAdAXI0hXq7ToZh7ggWhIbs5NBf45FMendEW9oQmmqFJwT6nWiY5JcCecMA4wYpG-sDhZkyICNYWLhB20UB1PXajDuFl','DANNI HIDAYAT ',1),(232,'shaka_fitri@yahoo.com','082183619594',0,'$2y$10$ttf.x7KzGBc7AUY550LmRepm9nIAxJyDXZoVQHMSBD2U/SU1.gZ6a','fitrishaka-2024-07-24-11:21.jpg','frN7l9l6TJSX-aXCQ8iHpt:APA91bGIm4jrkUuJ641CFSVAY_CVsjOaTDBcT5nfMdmegwImCSRrMcl8-1L3nGh2dsuc5kox99iPpLVGm-Um-5zHxTgk0vKharn14mm7ZQ2sVwj8rh-kHtPIgcYlba_W4IO5BV5ZWLh3','fitrishaka',1),(233,'rahmadilak@gmail.com','085776028958',0,'$2y$10$fPCkW.K43qYIGzO34.GKuedICOoXGSBeZmfq3RXOQRfdyeIZmU8NG','Kurnia Rahma dila-2024-07-24-11:23.jpg','f7imjf5jSXGd4b_uhb0FSI:APA91bFa4oZ1HxSr6iM_vg3j9SEoN1o5rwGAmcbMAbytfPNLvYdOR9ZrM55znPvRUWdjy8ylZnS_r-vB7CjFmKifDFiLRD3MulKB5bGlsuSwd0J_sdIxwMt9IDOmlm-eQ1TLyNA7fSa1','Kurnia Rahma dila',1),(234,'srid65149@gmail.com','088276631163',0,'$2y$10$iJucuPmvtsrOWQQRoxjRM.KHqVWXSQ2dt0StUP6jzpM3XPAZonzGO','Sri Damayanti-2024-07-24-11:23.jpg','dbduvbUbTyS-11Hp8ELhyJ:APA91bF_WDyiDk06KNtW1NyPR8mPQflFi0OemydIMcgpvw9QdXWP_cbf7Bies1Sevyhot9mtJ8rS-IGlCXP57OSk79NK9_QG_JqWonSdQ2TJpPdsN3PR3rOzNIRCvUn9TV2LoSqiFaxg','Sri Damayanti',1),(235,'septiiryani920@gmail.com','088287920736',0,'$2y$10$IEpiIgZa1s3Tz8b597VUkOFA3IhmDEbQ/1BWJUzcPnLIqhEjiYec6','septi-2024-07-24-11:23.jpg','fxf0vMjrTi2Ia7x-zL5_bx:APA91bECjgQgghq4576aaLZSYmvZBPD2394SQENIaV-u0FJYk0dKxFLwkRjbtWXT3eis_JJySQGPP8a_35V4rC8iJ-ISJmMuXvtRrQN--1lrR6sm_WQg30lvV7Yg0NrvwgJjbso2Sker','septi',1),(236,'oldakun51@gmail.com','08578822396',0,'$2y$10$9kGHlNPcJBMHDbtkPGQb4OhbeieNpSOykfSHYFxL4DiZKtjfcbPCi','oldakun -2024-07-24-11:23.jpg','cR3g_0uoQU2DQ2cJzyJJB4:APA91bFauKY0x4nWEqPxSfqjBQJRMdhJe0Qs_wsKKqEgP9Pqim64Yo9OqxwypluMbcwKmmPTUqUWvyXd5hFaJeBQ_kex-A7dr-_rg1Utqrob_0B04S6w37Kkj_sHVrWGdRHgL-q2CuGN','oldakun ',0),(237,'fatmaulanamalik@gmail.com','085788822396',0,'$2y$10$93/ZGqwSo8PbKLypfpNZIu8uNzzpk20s9VEaAPl47CzVol.M.nNzK','oldakun -2024-07-24-11:25.jpg','cR3g_0uoQU2DQ2cJzyJJB4:APA91bFauKY0x4nWEqPxSfqjBQJRMdhJe0Qs_wsKKqEgP9Pqim64Yo9OqxwypluMbcwKmmPTUqUWvyXd5hFaJeBQ_kex-A7dr-_rg1Utqrob_0B04S6w37Kkj_sHVrWGdRHgL-q2CuGN','oldakun ',1),(238,'liyacassa@gmail.com','085609355352',0,'$2y$10$yT0XA6mzDhLGvA.xINKH9ei7cAc//rEeAJTvWNzbOtaMvHTvJxmKm','Raffi-2024-07-24-11:29.jpg','c6Hyu-V1T6q5JI-3obIIBL:APA91bFswuACOtzushpQkC3AgmW-KqsZdOigtnzHd8nQMSNuTBa3JUX6EN0d7nG5kY7ME5mrHCBQdnuJ37KEWkoous4tXRUuf9uVTZx0a4KWtfMNwBx8W9j9LId8fIgUXtLcdeMHkITC','Raffi',1),(239,'trhee.tri@gmail.com','087789742854',0,'$2y$10$NioMmRc77I2GUClZMzooyeAkHJmfYxaeNWGuAxYQYKoSddpTpd/Gq','Indah Tri -2024-07-24-11:31.jpg','dt_BBEXKSA-CQuD43mwr90:APA91bGram5cm7u11RoWARtPwmDF45d5jXnzQEdXqAv5EhCgMf07LXauYxra0Yk2WJciffImmccJoWouJ0raq7eRfYOMXAidpdO5B3euuLpglyLFhBEJYZQYVSg4kBTRzhFyedRIu1z5','Indah Tri ',1),(240,'kandarikhe@gmail.com','082184492752',0,'$2y$10$1N4.DMPfBAKlOAlR1TK4l.8.vFfUNC9Ekgv8NsoV7/nwwdgyPRDse','Irsya pratama-2024-07-24-11:33.jpg','dbB6IhwYTJuBKFjVC2PDwT:APA91bGnWe4z7zFfb6rga3yKbp2UB1fDtNX4JzMmFt5UpGLbyoY5qNRFfzCgnlp1KP1XE7uDiOO5Hd9rxxIJc1pbZ8oBl1OGd61spyxX-zafDiGveSeGu1cj0LwDFlcp1-9INBL5bfQL','Irsya pratama',1),(241,'mhdfhryy5p@gmail.com','083165967551',0,'$2y$10$vPHQGtdBtJRV7EweMvBdkOdlZ7Y30aEt9ped3LBx16wvZWs8shk1m','fahri akbar-2024-07-24-11:36.jpg','dLkYjxfAQ4CdDvuT2RMOxq:APA91bFFloH6y8Ej0yYjx-co-S7_oFxSclDEqsQeyILYYy18P3Rt_4L0k-J_7mYUjS4b__K7kRd_2d_ePJ48Xf1KtJQ86jLYl--BzRvbVGk_vtScTHM_NpWwIVtlCWJNANktI4jKrezi','fahri akbar',1),(242,'dzakiyyahaliilahzahra@gmail.com','088286057639',0,'$2y$10$drbAclmyGlOl1rmm45dkOu5.PO2sG7MBqJdXWhKvRt1SFkmObqT/m','Dzakiyyah - 2024-07-24-12:03.jpg','cYBMcET_TiKBVzspTgFoHB:APA91bEqlLSLPOTX8Kq86vTpbEe5lSX_Ny-FbZAOsTfAEC5joWSNEHyn1Bb_38_tbiQHA9dn1yooPzVJh0yvEZGNfC7aeywLf_HzsKcSUQopBj0ERWrXoSHg7RmAf2ZV4q8fale1Clxn','Dzakiyyah',1),(243,'hendrafp71@gmail.com','081274611062',0,'$2y$10$ShLtNyzCiFVvrTGtJGiRiuwa8J7MRE6tV22VWLC0kypvTOITomBWm','Hendra-2024-07-24-11:42.jpg','fSIUQ3q_RFigt6p61N3Azu:APA91bEoMvmTY547gD_QJsC8NOi0x2pKWhQjGXvFxbJprQsMrStpLV-dVDV-vUTmkM6odtCV2VJ4sGpSPLlmB8SlqPUstZ_mmOFndboV51Z3dVcKuBzORxsIQDbJczikx-UzFdJzRqqw','Hendra',1),(244,'distaapriliana5@gmail.com','083839341536',0,'$2y$10$ec6xBm9euIzaF1smSo6vmu1..OnteFTIFpECqqrujZqIafMgIf1A2','dista-2024-07-24-11:42.jpg','cqoSQiB3RqWARY-8jWFuJJ:APA91bGNVMTXgBb4H7YV1sD8IuJFJUtDwrMSDe_OZEJHm5puNUj0JbSpLyKE_LPXFMAuUtt4Me60jm_07xVXAs0s_KGSpAOzSbzFmhpaXE6JnWgBiS84PMA0p17G7JO8FpEQuua6PCaC','dista',1),(245,'yotubepremium52@gmail.com','082178735796',0,'$2y$10$ZDBIH.5fPGkRZ9Nuw71Tw.8bH7K.ITzmdOtSuiLoF452U1xAAThfW','M.Miftah Al ghifari - 2024-07-24-11:45.jpg','dp8qQLqNQYSd7u_LKNeq-j:APA91bGvmZXJG4W2vhibKTcIHAvbK53EljjR8wpxrNk19L6S-twbnbSTvzc4uJTC2-wKiRPMj6r8uZcnWybArk_9r76h9OGDkFcMsT5p1PWOZjGZdt6gAdcWDBf7z107N5r-IGnPBxTn','M.Miftah Al ghifari',1),(246,'ayutrianaa@gmail.com','082179900337',0,'$2y$10$ZPlBsAHU4ChokhJRNBUI7u.OYc366jakqmGLWHcIA1rkaM5qsnOOK','ayu triana-2024-07-24-11:45.jpg','cLSvvStSSLKE1enIPwpCJz:APA91bEtxw1A_J4K7UZjUPXr8fYM9dyDvDzjjp5_9z-Afg9gEGWmK3IHFD6ipl82p5f1NPtuDrpNdZSLCqeZQ2CEE59O5Gf3YBWTUIdhe4B7-obnjDDqxeqE2q5BtWy_RUvJwbSQWt7a','ayu triana',1),(247,'septiana20glb@gmail.com','085273429197',0,'$2y$10$WnoKd/lAluPuduYYXM3CqugAd34vKZV4FypxHagqNG6NcodRGQqhm','seftiana-2024-07-24-11:47.jpg','cIbm1WczTdC5OS5krYU3_y:APA91bHf1-HxNbpPUK4cBYJVo0nGRtyXqrS7CU2saaW-UYfIjSIRQfdikBfYGCG8zjiQ9irDY8SSuMacDuFu1CYNMVDu7d4cJcFc0NUoELQKjBapF45oBJxHoMP4ujevTi0XF0igpMk4','seftiana',0),(248,'irmaselviana15@gmail.com','085789588321',0,'$2y$10$T/roWwrBU1byz22GiVt6o.oFQlHx6HKZgz.m0w7pZ6tv/6cPh.cd.','Irma Selviana-2024-07-24-11:47.jpg','cwPfOYF9Rem-I8ddRr64Nc:APA91bHvAWZ4WBkMrv2C82N07teWDQlCWbe7LJ5miwPbcwrp_0tkdQvS9kZVLwKo3_oQUgUkAgtIE1iEECj2GxcqOVo9jezG0wRw4Dbb6eBafdcDp-ivUo8rt0ulD_DLsiEYCzvLqZyE','Irma Selviana',0),(249,'fergaberlian@gmail.com','085839720427',0,'$2y$10$vIlRGRKnIW1AWzlGDWtLh.Yg21Hz4xWGV9gwGkcvHYavATagkgcZO','badol-2024-07-24-11:48.jpg','ewlK3deYS7CW0ekuBIG8K1:APA91bEAv8Jh-jxuwGvPbmAySn4Xrl6lnXI2okEyerHTJH-t69AHJKJsLac1Jc-eN9BhJliL7GvWSB-d3NlO9zCV32F9xvm8zcpbX31SC8KdI7aAkXqeB0AgORa9KbBARuqw9caaQvKD','badol',1),(250,'chrisyasa664@gmail.com','081440010998',0,'$2y$10$6niX8RC3VjS.rCeYWpnwLeucHqMtX3CWm8wx5Uuvl6USM8P4um4je','chrisya-2024-07-24-11:50.jpg','efjJEfJGTredUYcLoZVTJR:APA91bH7ozgO32BLH2CJSJLFEGY-jfBltI2hBDDZwxQvo_nofpGwERewjcG953GvxStkshLhr652g2o06UUvFAbBMYLWOb6HWJ6q0D6ENbgbtEonwJHH1Z9yK1Q-tdr47XRHIAZwtgE6','chrisya',1),(251,'pramnda10@gmail.com','083802755131',0,'$2y$10$dHqikIauDu/Dy3q3PwDgkuhv36yBVW4L3iEIWDgYYJY.NLIfRStJG','Pramudia -2024-07-24-11:51.jpg','coEEXrH1RpypatlsUghChv:APA91bGo3Uh1j77oVLSfHgZYkJCPMUKU_3sA7UK1AAnG0X2lhCUUmQG7k0BYcJB8R4KO0unyJ8Y_d_FsxnpzaQTo4dClSkYdIJ_wwt1M-e16EZ6JlpBlebmlsYqjtda1PrEW5mJXZr6U','Pramudia ',1),(252,'rohati07567@gmail.com','083838077680',0,'$2y$10$PzIjC1uU7n3594Erz.tAFeyijBXNFtfNfGls/Gr9HXn/0T0BjUepm','gacorselalu-2024-07-24-11:51.jpg','eF0kDRTjQcqtZQx1HaDuT4:APA91bHcCoLn1YHBaXajuUK-NA8StJk9zXhFnKRbkBK4QRwEIuwZyKzJLvo007fvjX6AUjx4GJjCkAa-Pv7x5ZV4VHuJke4qb2udfuXb-5cUE_c2Hq14x0Ob6tiLPJ9QNJvcBRl8MmqB','gacorselalu',1),(253,'natasya01g@gmail.com','082179986088',0,'$2y$10$OogXSyvq1pNg0BhpsnAhiuKZTIivZOv3cZX0YkN27thSATa9xRcLa','natasya-2024-07-24-11:52.jpg','ek5plVOcReSSWsu9cT1Fqe:APA91bEpjY43t-ufpT7xatCRudh8WzY79QXi8G1hEqg-4uhHp2dgM8kxBlnE__-KAZW4g19_547DtAgMlwBS1GGohgv_DK_R1IMgFZ5Nr55r761xPwpjkPFkQhImP9LlnzdAM-gyxjy_','natasya',1),(254,'reniantika85@gmail.com','083133910879',0,'$2y$10$h3Lg55nW3XXOopWuVJ.7xeizeILpb6qdqfZvdowsKi4K5.CqiHPn6','Lucky Tornando-2024-07-24-11:56.jpg','cOS_rvrFQxy2ppj0BvI8Bz:APA91bHj6_oD39s_84CkrY-W1lOEyo2ZEFUaZ9SKE7bcctbfD7LQNNoylYm77LbfCkBRwxL6VFrC_A01YwUH7kzSmx32N_aVFq2pECJpLzytopGQ_UsNNxodKsW4aoS_tlnccr6WXxkc','Lucky Tornando',1),(255,'sausan270207@gmail.com','083164801462',0,'$2y$10$9XNMg1TvEnmRBMFHdoaQUOHdGtyc8mn9/drfn9InDceiNaC5.hoge','Sausan Ulayya-2024-07-24-11:56.jpg','eMqw-l5rRtGClQ9pJAPMlx:APA91bGkVGOCWN9SwCipL69Z1PxaOCHBdiy9WZweuQ-hVT0nO2fIoC2dOTwzdKlYTTuCB5-3wvk7L3PCEDbk3hOrhg9Dx3deoPRCySIaynlrN2S6lymyUvFdNexeiWFHLDMvj3j-yXVb','Sausan Ulayya',1),(256,'kartinysftryy@gmail.com','087795287105',0,'$2y$10$qv9Z9R8as4Am/8sRrkYJPOZmcCHxbRlx2pbAmXNhCFR8TTn57beWa','kartini-2024-07-24-11:57.jpg','djsqb2hmQJeWoOPPnM2aRW:APA91bEpnOkJpps6C9wU8hG-v8akNWkK3v9WrnMnZ7mylh5o-HQC7OzBhMTqzBBv5dR8bzYoS27_wErWjWMMBaSU9I3PqdUv_8Kh9xmcWX8K06PyGsFKY-SNw_lSP-KFybE-kCSkhO_Q','kartini',1),(257,'wipaqhaj@gmail.com','083166150443',0,'$2y$10$u.SKZjC7BABWaSBYlZA4S.XFOA..CiuB6wCMaY9dDX343tgke2XAq','Youu-2024-07-24-11:58.jpg','eg7K9ND9RzyINOyda-XNtI:APA91bGA0Uy88CL8b1PrdtJAxGcfyUh-a0R498iwovS8F47SRvyI6sGyotvH8rO_HSqpU7hcE314XvdEljWfD2VP-XcO7KOt2Fcu8EjNsw5THM9spI5D4TqoM7Ha-3WfM7g8Hj5PHy1T','Youu',1),(258,'evapatmalasari3@gmail.com','083826185983',0,'$2y$10$9sakQJskZcP.bJDQLNUFEeSmhxP8elWvcAODlu803jjOBFe8u5lXa','Eva -2024-07-24-12:00.jpg','din49upJRTyJjeLCBEKfRo:APA91bF41dzw6C_A8sQhzOUPVA4FhDqrd3ZHrP-FpiVc_bCBofiC1H82uBa4O3EBLVcP1lzTNSbwQCIsJuOYZMAydNB-vsJgo8ko91WiJ5ltfi1BR5kFPiD-xheeVbBXVUeo4hdwEAJt','Eva ',1),(259,'fitriadwiindriani3@gmail.com','082179845203',0,'$2y$10$zjuSCf3Mx.yCuDY5Z257hOyujBI4nZUuejhbvq8mDXcYb9UQlWwqi','Fitria Dwi indriani-2024-07-24-12:00.jpg','cXEj0DnbQO6zGoj8tXHtMm:APA91bHi-bUO7k4mNKZIm-2VMzmFo-MAQYj1j8DgfXMorvl_EjmFu6vN1KPu_Vr_4lIXcHpmRKl3WmlvpZIYWM4ZRgRdp_eP_8TjbOJrFtDKEcP_DNtpKgPk4zD6D9WdfK97D_kaNzJ6','Fitria Dwi indriani',1),(260,'unapurna29@gmail.com','088706878008',0,'$2y$10$tt/DVpeN7N5bgkE3XcGOIuLFplVr5iINhsmxJvICqsWkZAFIETgZi','Sukma Purna-2024-07-24-12:00.jpg','forJ2GqUQW2uvDxZleko5-:APA91bGtE2wp46jXz2X81425LcsyUSjqSTfiPNkrTb2dRIAksCpPA3MYQ3qOYQw09J-xSScWsT3VM56QVh2pRUuFAImhvTM4iN5xD3AkeZUtoqqGgGlC8A2Y789opXuX26sMU0Qxm9TC','Sukma Purna',1),(261,'rapispenda@gmail.com','082177800238',0,'$2y$10$/3QBbAoslisjaLkqjxEmkehtzK.SqvjOzSrAYVhc7NNpm5mes1iKu','rapispenda-2024-07-24-12:01.jpg','dzzXmZnUQlCxADnpksiyZ8:APA91bH5iprDTYCg782Zd4OVh0oArrzbLjGqTF9PsN-L4jtSeu7-mBCeQXsm-vNPxQuxfsEFx-Xm1W-KcJ8lXv155u1ydqPjWZzsN_RsOLmtvX9gkai4JIl9LVj_B9kDQHlRE7Qk1fgZ','rapispenda',1),(262,'puspita02062000@gmail.com','082185571984',0,'$2y$10$dIuOg3uIRs1iG7FfZr0fBuZZ2qE/2V2Z7kYXSALJ21p/sq46.wjGy','Puspita Rini-2024-07-24-12:01.jpg','cVW5hAf9Ta-gutAw8Q4MD6:APA91bHP22yX7BuSh28dOQ1CushVOsoo7AllTquaw6hBQ6SFT2wecc7HpZmnmrt6XrKJ5DHkFh-QdQZgBZ4U__mSEXCKN89LUU5vC2lljsQwZGYej1JcSu-xFwla8jvzD0JUL1rHy9LB','Puspita Rini',1),(263,'dwisupranata@gmail.com','081279918234',0,'$2y$10$px5R1TgCQ53u0pvzJDqj2.yWzZsW3IPPx0Ywzq1V5DD.8NriCfL3q','Dwi Supranata - 2024-07-24-12:06.jpg','fcLqQesBRnC_IBXvINtabJ:APA91bGTg64xFnyWI4r5Dj2T49gaEoN-rOujP-H8A8M7e3BpbEV6APfVhQS0qksJuFOaH6pg8le91wD9MVb3ChGkouqN3sLigdkF16eFGUAX1IGMV5DOwh_OUFuhPJXED8FCMc33GsC2','Dwi Supranata',1),(264,'nurlaili050685@gmail.com','085783375447',0,'$2y$10$rvxEhqpectUWzuxVliw8nuJI/02O.s0aq/5WdP.PSZe6bkJzwy0RK','neza kue-2024-07-24-12:05.jpg','e_9N6UX3Qrae5a6p0RP9y3:APA91bFFrIOHLZevpJRT-fK_-4_QuEEXeF_Tpp5FsVGUcJWxDhjTiDRDEZY-xBJcYikfpM6bR9ZSxmq2agou99FVzxL8S8Sp853XVnLhrFyE7gq18TlO_jwMC0A9Ymef-ITutiY7Rqcl','neza kue',0),(265,'excel2343@gmail.com','083830505402',0,'$2y$10$lZtT5E/tlxPYejzt.Wlza.Bw.WjFIMKB5B73TCSnEuCqXLEE0VmEW','excel-2024-07-24-12:05.jpg','fFv477lpQCO_wvWTAvkhL9:APA91bFvSMq0UYTzlGhjo3INxINFyGy3EZC7-jFw6-zQb7V8NSk9aXIUgvS_i8RacvRqCu2JgK3qAeZv4GeHOl2tNmf5sBNoLjN7js8Obs-DGfgwJ-QMCuv_nCrRYoQlVq0Ug4deXQE0','excel',1),(266,'enayfranita@gmail.com','082176633887',0,'$2y$10$XQpBs2kAgrxxxAyO6dAi0uHFS5g9UWC/f7OfJufY2iZi4LOJAB.4O','eni-2024-07-24-12:06.jpg','dFTdibMhRuimynxMEKCwpT:APA91bEd-e5yOsiW3VWGC0BLkqs9s8ozjwkC-e62RouXmlC67omXlOCmW_K9PBTg8iGyBeNpe6DAov42Yt4qqZAdWvsG9lJYuUvUXa_cPwHLC_3j0bi5qvpb3G35hLIYXbC9630NYnap','eni',1),(267,'shafiyahpipit@gmail.com','085896640610',0,'$2y$10$zLi48o8o1tefq5NQ6vJPeOSjvTlWl9HKkjzwCE/0Us17lsIaUzBau','Fitri Kurnia-2024-07-24-12:09.jpg','ddF71I7aR7yRRhAilG_jgz:APA91bGkjNV0CnEeJRIpLFJ4iPZ9VCOfpTIAIQUpowEN0oJjvawdpRHNCdeqY0YCIzA0wyJm_gAcBvSY7fSSR25DSqi4U_ANJSj4X3nIDeAXsVxrN7dQDLrsDzGLV8EZKxpZkjySSa7F','Fitri Kurnia',1);
/*!40000 ALTER TABLE `tb_pengguna` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_restaurant`
--

DROP TABLE IF EXISTS `tb_restaurant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_restaurant` (
  `id_restaurant` int NOT NULL AUTO_INCREMENT,
  `restaurant_name` varchar(255) NOT NULL,
  `restaurant_location` varchar(255) NOT NULL,
  `latitude_restaurant` varchar(255) NOT NULL,
  `longitude_restaurant` varchar(255) NOT NULL,
  `id_harikerja` json NOT NULL,
  `open_restaurant` int NOT NULL,
  `close_restaurant` int NOT NULL,
  `is_open` varchar(225) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `is_active` enum('false','true') NOT NULL,
  `restaurant_image` varchar(255) NOT NULL,
  `user_email_mitra` varchar(225) NOT NULL,
  `restaurant_rating` int NOT NULL,
  PRIMARY KEY (`id_restaurant`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_restaurant`
--

LOCK TABLES `tb_restaurant` WRITE;
/*!40000 ALTER TABLE `tb_restaurant` DISABLE KEYS */;
INSERT INTO `tb_restaurant` VALUES (50,'Kedai Up To You ','Desa karang Endah (Samping Indomaret Simpang Bacang)','-3.3089825 ','104.3966586','[\"1\", \"2\", \"3\", \"4\", \"5\", \"6\", \"7\"]',9,23,'true','true','Kedai Up To You  - 2024-06-28-14:53.jpg','monalisa.recruitment@gmail.com',0),(52,'LCGC','gelumbang ','-3.2353715','104.4413798','[\"1\", \"2\", \"3\", \"4\", \"5\", \"6\", \"7\"]',23,10,'false','false','LCGC - 2024-07-03-09:58.jpg','maraffi314@gmail.com',0),(53,'Ceritanya angkringan Van java','karang Endah,simpang embacang','-3.3090108','104.39735','[\"2\", \"3\", \"4\", \"5\", \"6\", \"7\"]',14,23,'true','true','Ceritanya angkringan Van java - 2024-07-03-21:02.jpeg','wulandarinova229@gmail.com',0),(58,'Tester Mitra','Karang endah','-3.2513529096883995','104.6557022748655','[\"1\", \"2\", \"3\", \"4\", \"5\", \"6\", \"7\"]',8,0,'true','true','Tester Mitra - 2024-07-04-22:02.jpg','testermitra@gmail.com',0),(61,'Seblakglb','Kampung 2 gelumbang, lorong ema','-3.2412115','104.438524','[\"1\", \"2\", \"3\", \"4\", \"5\", \"6\", \"7\"]',10,18,'true','true','Seblakglb - 2024-07-19-13:43.jpg','nurbaity.go@gmail.com',0),(62,'Bakso \"Three & One\"','Kampung 2 Gelumbang','-3.24013','104.4374667','[\"1\", \"2\", \"3\", \"4\", \"5\", \"6\", \"7\"]',9,22,'true','true','Baks Three & One - 2024-07-19-14:32.jpg','okisriwahyuni962000@gmail.com',0),(63,'Mie Pangsit Ria Sari','Jl. Prabumulih, Simpang mbacang, Karang Endah','-3.308678','104.3968667','[\"1\", \"2\", \"3\", \"4\", \"5\", \"6\", \"7\"]',10,22,'true','true','Mie Pangsit Ria Sari - 2024-07-19-16:00.jpg','lmualimin57@gmail.com',0),(67,'Warung Model Bunda Wilda','Perlintasan Stasiun karangendah','-3.3030583','104.3952983','[\"1\", \"2\", \"3\", \"4\", \"5\", \"6\", \"7\"]',10,18,'true','true','Warung Model Bunda Wilda - 2024-07-19-17:48.jpg','arfiwulandari283@gmail.com',0),(68,'Angkringan Iban Begesah','Desa Suka Menang','-3.23426','104.4416067','[\"1\", \"2\", \"3\", \"4\", \"5\", \"6\", \"7\"]',16,23,'true','true','Angkringan Iban Begesah - 2024-07-19-22:11.jpg','noviyantidwi908@gmail.com',0),(69,'Hollytea ice & Cbezt Friedchicken','samping Indomaret 3 Gelumbang','-3.246754','104.4332423','[\"1\", \"2\", \"3\", \"4\", \"5\", \"6\", \"7\"]',9,22,'true','true','Hollytea ice  Cbezt Friedchicken - 2024-07-20-10:55.jpg','arinavirahman04@gmail.com',0),(70,'pempek cek sumi','jalan raya kampung 2 Gelumbang ','-3.239116','104.4372625','[\"1\", \"2\", \"3\", \"4\", \"5\", \"6\", \"7\"]',9,9,'false','false','pempek cek sumi - 2024-07-20-14:17.jpg','octaliamonika9@gmail.com',0),(77,'Warung Bakso Mamak Jeni','Desa Suka Menang','-3.2319906','104.4418155','[\"1\", \"2\", \"3\", \"4\", \"5\", \"6\", \"7\"]',10,18,'true','true','669f728093b60.jpg','bariareni45@gmail.com',0),(80,'pecel lele sri rizki ','jlan Prabumulih depan lepi son','-3.2399298','104.435377','[\"1\", \"2\", \"3\", \"4\", \"5\", \"6\", \"7\"]',10,22,'true','true','669fc0fe37ba4.jpg','rizki220122@gmail.com',0),(81,'sarapan pagi sahabat','depan sdn 021 sukamenang ','-3.2334983','104.444225','[\"1\", \"2\", \"3\", \"4\", \"5\", \"6\"]',5,12,'true','true','66a06dfd5c95f.jpg','jayantiekayana@gmail.com',0),(82,'fried chicken dan ayam geprek aish alif','samping bank BRI / apotek Rizki gelumbang','-3.2361075','104.4403524','[\"1\", \"2\", \"3\", \"4\", \"5\", \"6\"]',9,17,'true','true','66a084d5ba68c.jpg','hidayatiy15@gmail.com',0);
/*!40000 ALTER TABLE `tb_restaurant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_review`
--

DROP TABLE IF EXISTS `tb_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_review` (
  `id_review` int NOT NULL AUTO_INCREMENT,
  `id_restaurant` int NOT NULL,
  `id_user` int NOT NULL,
  `rating` int NOT NULL,
  `review_user` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id_review`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_review`
--

LOCK TABLES `tb_review` WRITE;
/*!40000 ALTER TABLE `tb_review` DISABLE KEYS */;
INSERT INTO `tb_review` VALUES (4,8,27,5,'makanannya enak','Rahmat');
/*!40000 ALTER TABLE `tb_review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_transaction`
--

DROP TABLE IF EXISTS `tb_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_transaction` (
  `id_topup` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type_user` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_Id` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `to_id` int DEFAULT NULL,
  `type_transaction` enum('top_up','transfer') COLLATE utf8mb4_unicode_ci NOT NULL,
  `gross_amount` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_time` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_date` varchar(225) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_type` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `settlement_time` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fraud_status` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_status` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `signature_key` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id_topup`)
) ENGINE=InnoDB AUTO_INCREMENT=189 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_transaction`
--

LOCK TABLES `tb_transaction` WRITE;
/*!40000 ALTER TABLE `tb_transaction` DISABLE KEYS */;
INSERT INTO `tb_transaction` VALUES (176,'47','0','55757',NULL,'top_up','40000','10:20:35','2024-07-24','admin','2024-07-24 10:20:35','accept','settlement',NULL),(177,'42','0','18460',NULL,'top_up','40000','10:20:49','2024-07-24','admin','2024-07-24 10:20:49','accept','settlement',NULL),(178,'38','0','59549',NULL,'top_up','40000','10:21:00','2024-07-24','admin','2024-07-24 10:21:00','accept','settlement',NULL),(179,'39','0','86487',NULL,'top_up','40000','10:21:09','2024-07-24','admin','2024-07-24 10:21:09','accept','settlement',NULL),(180,'43','0','51470',NULL,'top_up','40000','10:21:19','2024-07-24','admin','2024-07-24 10:21:19','accept','settlement',NULL),(181,'48','0','70295',NULL,'top_up','40000','10:21:32','2024-07-24','admin','2024-07-24 10:21:32','accept','settlement',NULL),(182,'47','0','635',NULL,'top_up','500','11:03:15','2024-07-24','expenditure','2024-07-24 11:03:15','accept','pending',NULL),(183,'49','0','106324924',NULL,'top_up','10000','11:06:07','2024-07-24','top_up','2024-07-24 11:06:07','accept','pending',NULL),(184,'45','0','42782',NULL,'top_up','40000','11:11:14','2024-07-24','admin','2024-07-24 11:11:14','accept','settlement',NULL),(185,'47','0','755',NULL,'top_up','500','11:24:18','2024-07-24','expenditure','2024-07-24 11:24:18','accept','pending',NULL),(186,'38','0','750',NULL,'top_up','500','11:46:25','2024-07-24','expenditure','2024-07-24 11:46:25','accept','pending',NULL),(187,'139','1','GAS-1-5578',NULL,'top_up','52500.00','2024-07-24','11:54:24','gopay','2024-07-24 11:54:26','accept','pending','23968fa99fd3adf17bebdc1fe2743391d562b6702a8a6d654ac04dfd1e5f02a04860acedd1be8c6a601b89639449cd52a23a29ea93618e5e26b4dc6743511ca1'),(188,'139','1','GAS-1-5745',NULL,'top_up','52500.00','2024-07-24','11:54:33','gopay','2024-07-24 11:54:34','accept','pending','dc597c8d0dd9ead48735e675d58150f809f0c92ee2e4a9550602281218424a587ce8d356c4b4bb3099f21a333b4b9c8a2d979c9fd712f989bde357cbe1933b9b');
/*!40000 ALTER TABLE `tb_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `reset_hash` varchar(255) DEFAULT NULL,
  `reset_at` datetime DEFAULT NULL,
  `reset_expires` datetime DEFAULT NULL,
  `activate_hash` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `status_message` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `force_pass_reset` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `image` varchar(3000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (6,'admin@gmail.com','Sandi Maulidika','$2y$10$zNivuMrhbphlZfx0Gx1Udegzi5aB6EFcyrLs/89B85E9MQv5jbUjy',NULL,NULL,NULL,NULL,NULL,NULL,1,0,'2024-03-25 02:33:28','2024-07-12 23:33:10',NULL,'1720801963_976c645df5dec70f14da.jpg'),(9,'Rahmatdev09@gmail.com','Rahmatullah','$2y$10$F/UXYGhCkX55aNCdFQmn9eRWwukiiu4pFp3qAHzQHAmJNKPiRD6rG',NULL,NULL,NULL,NULL,NULL,NULL,1,0,'2024-05-31 06:24:06','2024-06-01 20:12:33',NULL,'1717290753_94698e07ef46a215517d.jpg');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_verify`
--

DROP TABLE IF EXISTS `users_verify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_verify` (
  `id_verify` int NOT NULL AUTO_INCREMENT,
  `email` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `expired` datetime NOT NULL,
  PRIMARY KEY (`id_verify`)
) ENGINE=InnoDB AUTO_INCREMENT=298 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_verify`
--

LOCK TABLES `users_verify` WRITE;
/*!40000 ALTER TABLE `users_verify` DISABLE KEYS */;
INSERT INTO `users_verify` VALUES (107,'mdianursaja@gmail.com','730158','2024-07-23 12:25:03','0000-00-00 00:00:00'),(119,'intanvm055@gmail.com','695156','2024-07-23 22:34:04','0000-00-00 00:00:00'),(127,'noviaardila11@gmail.com','300235','2024-07-24 06:42:21','0000-00-00 00:00:00'),(139,'ikchapalupy@gmail.com','217654','2024-07-24 09:05:12','0000-00-00 00:00:00'),(150,'dianaanjeni42@gmail.com','532332','2024-07-24 09:33:23','0000-00-00 00:00:00'),(157,'ahsanomen@gmail.com','766174','2024-07-24 09:38:29','0000-00-00 00:00:00'),(192,'antidamari65@gmail.com','369401','2024-07-24 10:23:02','0000-00-00 00:00:00'),(193,'shellamartina24@gmail.com','973459','2024-07-24 10:23:04','0000-00-00 00:00:00'),(200,'pujatrikana74@gmail.com','591916','2024-07-24 10:26:59','0000-00-00 00:00:00'),(231,'arikandoko1@gmail.com','652915','2024-07-24 10:48:46','0000-00-00 00:00:00'),(232,'winda544358@gmail.com','615423','2024-07-24 10:50:02','0000-00-00 00:00:00'),(233,'syalirorohma05@gmail.com','255123','2024-07-24 10:50:15','0000-00-00 00:00:00'),(257,'primabusiness37@gmail.com','236147','2024-07-24 11:18:53','0000-00-00 00:00:00'),(263,'oldakun51@gmail.com','835838','2024-07-24 11:23:32','0000-00-00 00:00:00'),(268,'asnaputrirahayu@gmail.com','464621','2024-07-24 11:36:02','0000-00-00 00:00:00'),(276,'irmaselviana15@gmail.com','342622','2024-07-24 11:47:50','0000-00-00 00:00:00'),(278,'septiana20glb@gmail.com','105322','2024-07-24 11:49:47','0000-00-00 00:00:00'),(296,'nurlaili050685@gmail.com','372957','2024-07-24 12:07:14','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `users_verify` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-24 12:10:54
